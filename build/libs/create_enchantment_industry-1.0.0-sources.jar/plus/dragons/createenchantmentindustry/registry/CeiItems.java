package plus.dragons.createenchantmentindustry.registry;

import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideItem;

/** Item registration for Create: Enchantment Industry. */
public class CeiItems {
	public static final EnchantingGuideItem ENCHANTING_GUIDE = registerEnchantingGuide();
	public static final net.minecraft.class_1755 INK_BUCKET = registerInkBucket();

	private static EnchantingGuideItem registerEnchantingGuide() {
		class_2960 id = EnchantmentIndustry.genRL("enchanting_guide");
		class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);
		class_1792.class_1793 props = new class_1792.class_1793().method_7889(1).method_63686(key);
		EnchantingGuideItem item = new EnchantingGuideItem(props);
		class_2378.method_39197(class_7923.field_41178, key, item);
		return item;
	}

	private static net.minecraft.class_1755 registerInkBucket() {
		// A standard filled bucket for Ink: holds the still Ink fluid, stacks to 1, and leaves an
		// empty bucket behind when used. Wired into the FluidEntry so Create's fluid handling knows
		// the bucket form (lets you bucket Ink in/out of tanks and shows it in JEI / creative).
		class_2960 id = EnchantmentIndustry.genRL("ink_bucket");
		class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);
		class_1792.class_1793 props = new class_1792.class_1793()
			.method_7896(net.minecraft.class_1802.field_8550)
			.method_7889(1)
			.method_63686(key);
		net.minecraft.class_1755 bucket =
			new net.minecraft.class_1755(CeiFluids.INK.still, props);
		class_2378.method_39197(class_7923.field_41178, key, bucket);
		CeiFluids.INK.bucket = bucket;
		return bucket;
	}

	public static void register() {
		// Class-load triggers the static initializer above.
	}
}
