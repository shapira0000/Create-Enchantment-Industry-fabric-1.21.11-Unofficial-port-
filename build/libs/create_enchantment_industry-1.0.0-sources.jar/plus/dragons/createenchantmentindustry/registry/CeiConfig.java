package plus.dragons.createenchantmentindustry.registry;

import plus.dragons.createenchantmentindustry.EnchantmentIndustry;

/**
 * Configuration values for Create: Enchantment Industry.
 *
 * <p>The original mod used Create's full config framework. For now these are constants;
 * a proper config file can be wired in later without changing call sites.</p>
 */
public class CeiConfig {
	/** Disenchanter internal tank capacity, in mB (matches the original default of 1500 mB). */
	private static final int DISENCHANTER_TANK_CAPACITY_MB = 1500;

	/** Capacity in Create Fly fluid units (mB * 81). */
	public static int disenchanterTankCapacityUnits() {
		return DISENCHANTER_TANK_CAPACITY_MB * EnchantmentIndustry.UNIT_PER_MB;
	}

	/** Blaze Enchanter internal tank capacity, in mB (matches the original default of 2000 mB). */
	private static final int BLAZE_ENCHANTER_TANK_CAPACITY_MB = 2000;

	public static int blazeEnchanterTankCapacityUnits() {
		return BLAZE_ENCHANTER_TANK_CAPACITY_MB * EnchantmentIndustry.UNIT_PER_MB;
	}
}
