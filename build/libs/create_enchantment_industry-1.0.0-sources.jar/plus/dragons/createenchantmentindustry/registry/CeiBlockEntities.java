package plus.dragons.createenchantmentindustry.registry;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.disenchanter.DisenchanterBlockEntity;
import plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlockEntity;

/**
 * Block-entity-type registration.
 *
 * <p>Uses Fabric API's public {@link FabricBlockEntityTypeBuilder}, the intended way for
 * add-ons to create block-entity types without touching vanilla's package-private
 * {@code BlockEntityType} constructor. No access widener needed for this.</p>
 */
public class CeiBlockEntities {
	public static final class_2591<DisenchanterBlockEntity> DISENCHANTER = register("disenchanter");
	public static final class_2591<BlazeEnchanterBlockEntity> BLAZE_ENCHANTER = registerBlazeEnchanter();

	private static class_2591<DisenchanterBlockEntity> register(String id) {
		class_2960 rl = EnchantmentIndustry.genRL(id);
		// The lambda is only invoked later (when a block entity is created in-world), by which
		// point DISENCHANTER is fully assigned, so referencing it here is safe.
		class_2591<DisenchanterBlockEntity> type = FabricBlockEntityTypeBuilder
			.create((pos, state) -> new DisenchanterBlockEntity(CeiBlockEntities.DISENCHANTER, pos, state), CeiBlocks.DISENCHANTER)
			.build();
		return class_2378.method_10230(class_7923.field_41181, rl, type);
	}

	private static class_2591<BlazeEnchanterBlockEntity> registerBlazeEnchanter() {
		class_2960 rl = EnchantmentIndustry.genRL("blaze_enchanter");
		class_2591<BlazeEnchanterBlockEntity> type = FabricBlockEntityTypeBuilder
			.create((pos, state) -> new BlazeEnchanterBlockEntity(CeiBlockEntities.BLAZE_ENCHANTER, pos, state), CeiBlocks.BLAZE_ENCHANTER)
			.build();
		return class_2378.method_10230(class_7923.field_41181, rl, type);
	}

	public static void register() {
		// Class-load triggers the static initializer above.
	}
}
