package plus.dragons.createenchantmentindustry.registry;

import com.mojang.serialization.Codec;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;

import java.util.function.UnaryOperator;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9331;

/**
 * Custom data components stored on an Enchanting Guide.
 *
 * <p>The guide remembers the WHOLE book it was loaded from ({@link #TARGET}) plus the index of
 * the chosen enchantment within that book ({@link #INDEX}). The chosen enchantment is always
 * resolved by reading the index against the enchantments of that stored book - the same
 * ItemStack on every side - so the choice can never drift out of sync regardless of how an
 * enchantment map happens to iterate. This mirrors the original CEI design (NBT "target" + "index").</p>
 */
public class CeiDataComponents {

	/** The book (an enchanted book / any item carrying enchantments) the guide was loaded from. */
	public static final class_9331<class_1799> TARGET = register(
		"target",
		builder -> builder.method_57881(class_1799.field_24671).method_57882(class_1799.field_49268)
	);

	/** The index of the selected enchantment within {@link #TARGET}'s enchantment list. */
	public static final class_9331<Integer> INDEX = register(
		"index",
		builder -> builder.method_57881(Codec.INT).method_57882(class_9135.field_48550)
	);

	private static <T> class_9331<T> register(String id, UnaryOperator<class_9331.class_9332<T>> op) {
		return class_2378.method_10230(
			class_7923.field_49658,
			EnchantmentIndustry.genRL(id),
			op.apply(class_9331.method_57873()).method_57880()
		);
	}

	/** Force class-load so the static fields register. Call from the main initializer. */
	public static void register() {
	}
}
