package plus.dragons.createenchantmentindustry.registry;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlockEntity;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideEditPacket;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideItem;

/**
 * Networking. The Enchanting Guide screen sends one edit packet on close, carrying the chosen
 * index and the book that was in the ghost slot. The server stores BOTH the book and the index
 * on the guide (as {@link CeiDataComponents#TARGET} / {@link CeiDataComponents#INDEX}); the actual
 * enchantment is always resolved later from that stored book, so client and server never disagree.
 */
public class CeiPackets {

	public static void registerCommon() {
		PayloadTypeRegistry.playC2S().register(EnchantingGuideEditPacket.TYPE, EnchantingGuideEditPacket.STREAM_CODEC);
	}

	public static void registerServerReceivers() {
		ServerPlayNetworking.registerGlobalReceiver(EnchantingGuideEditPacket.TYPE, (payload, context) -> {
			class_1799 book = payload.book();
			int index = payload.index();

			if (payload.blockPos() != null) {
				// Opened from a placed Blaze Enchanter: store onto the block's guide.
				class_2586 be = context.player().method_51469().method_8321(payload.blockPos());
				if (be instanceof BlazeEnchanterBlockEntity bee && !bee.targetItem.method_7960()) {
					class_1799 guide = bee.targetItem.method_7972();
					EnchantingGuideItem.store(guide, book, index);
					bee.setTargetItem(guide);
					bee.notifyUpdate();
				}
			} else {
				// Held guide.
				class_1799 guide = context.player().method_6047();
				if (guide.method_7909() instanceof EnchantingGuideItem) {
					EnchantingGuideItem.store(guide, book, index);
				}
			}
		});
	}
}
