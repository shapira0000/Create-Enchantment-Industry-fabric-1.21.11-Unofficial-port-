package plus.dragons.createenchantmentindustry.registry;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.disenchanter.DisenchanterBlock;
import plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlock;

/**
 * Block (and block-item) registration, following Create Fly's {@code AllBlocks}/{@code AllItems}
 * pattern: build a {@link class_5321}, attach it to the block {@link class_4970.class_2251}
 * via {@code setId}, register the block, then register a matching {@link class_1747}.
 */
public class CeiBlocks {
	public static final DisenchanterBlock DISENCHANTER = registerDisenchanter();
	public static final BlazeEnchanterBlock BLAZE_ENCHANTER = registerBlazeEnchanter();

	private static DisenchanterBlock registerDisenchanter() {
		class_2960 id = EnchantmentIndustry.genRL("disenchanter");
		class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, id);
		// Andesite-casing-like stone properties (explicit, to avoid base-block ambiguity).
		class_4970.class_2251 props = class_4970.class_2251.method_9637()
			.method_31710(class_3620.field_16023)
			.method_9629(1.5F, 6.0F)
			.method_9626(class_2498.field_11544)
			.method_22488()
			.method_63500(blockKey);
		DisenchanterBlock block = new DisenchanterBlock(props);
		class_2378.method_39197(class_7923.field_41175, blockKey, block);

		// Matching block item.
		class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, id);
		class_1792.class_1793 itemProps = new class_1792.class_1793().method_63685().method_63686(itemKey);
		class_2378.method_39197(class_7923.field_41178, itemKey, new class_1747(block, itemProps));

		return block;
	}

	private static BlazeEnchanterBlock registerBlazeEnchanter() {
		class_2960 id = EnchantmentIndustry.genRL("blaze_enchanter");
		class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, id);
		class_4970.class_2251 props = class_4970.class_2251.method_9637()
			.method_31710(class_3620.field_16023)
			.method_9629(1.5F, 6.0F)
			.method_9626(class_2498.field_11544)
			.method_9631(s -> 0)
			.method_22488()
			.method_63500(blockKey);
		BlazeEnchanterBlock block = new BlazeEnchanterBlock(props);
		class_2378.method_39197(class_7923.field_41175, blockKey, block);
		// No BlockItem: the Blaze Enchanter cannot be obtained or placed directly.
		// It only exists by right-clicking a Blaze Burner with an Enchanting Guide,
		// and reverts to a Blaze Burner when broken (see its loot table).
		return block;
	}

	public static void register() {
		// Class-load triggers the static initializers above.
	}
}
