package plus.dragons.createenchantmentindustry.registry;

import com.zurrtum.create.infrastructure.fluids.FlowableFluid;
import com.zurrtum.create.infrastructure.fluids.FluidEntry;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.fluids.experience.ExperienceFluid;
import plus.dragons.createenchantmentindustry.content.fluids.experience.HyperExperienceFluid;

/**
 * Fluid registration, mirroring Create Fly's {@code com.zurrtum.create.AllFluids}:
 * each fluid is backed by a {@link FluidEntry} holding a still + flowing instance,
 * both registered into the vanilla fluid registry.
 */
public class CeiFluids {
	public static final FluidEntry EXPERIENCE = registerExperience();
	public static final FluidEntry HYPER_EXPERIENCE = registerHyperExperience();
	public static final FluidEntry INK = registerInk();

	private static FluidEntry registerInk() {
		// Ink is a plain Create fluid (like Create Fly's MILK / HONEY): a still + flowing pair
		// registered into the vanilla fluid registry. Because it uses the same FlowableFluid base
		// as every other Create fluid, it works in all Create tanks, pipes and pumps automatically.
		class_2960 id = EnchantmentIndustry.genRL("ink");
		class_2960 flowingId = EnchantmentIndustry.genRL("flowing_ink");
		class_5321<class_3611> stillKey = class_5321.method_29179(class_7924.field_41270, id);
		class_5321<class_3611> flowingKey = class_5321.method_29179(class_7924.field_41270, flowingId);
		FluidEntry entry = new FluidEntry();
		entry.still = new FlowableFluid.Still(entry);
		entry.flowing = new FlowableFluid.Flowing(entry);
		class_2378.method_39197(class_7923.field_41173, stillKey, entry.still);
		class_2378.method_39197(class_7923.field_41173, flowingKey, entry.flowing);

		// The placed liquid block. A FluidBlock is what a bucket actually places in the world, and
		// what FlowableFluid.getBlockState() resolves to - without it, the Ink Bucket can't place
		// anything. Mirrors Create Fly's Honey / Chocolate fluid blocks (water-like properties).
		class_2960 blockId = EnchantmentIndustry.genRL("ink");
		class_5321<net.minecraft.class_2248> blockKey =
			class_5321.method_29179(class_7924.field_41254, blockId);
		net.minecraft.class_4970.class_2251 blockProps =
			net.minecraft.class_4970.class_2251
				.method_9630(net.minecraft.class_2246.field_10382)
				.method_31710(net.minecraft.class_3620.field_16009)
				.method_63500(blockKey);
		com.zurrtum.create.infrastructure.fluids.FluidBlock inkBlock =
			new com.zurrtum.create.infrastructure.fluids.FluidBlock(entry.still, blockProps);
		class_2378.method_39197(class_7923.field_41175, blockKey, inkBlock);
		entry.block = inkBlock;

		return entry;
	}

	private static FluidEntry registerExperience() {
		class_2960 id = EnchantmentIndustry.genRL("experience");
		class_2960 flowingId = EnchantmentIndustry.genRL("flowing_experience");
		class_5321<class_3611> stillKey = class_5321.method_29179(class_7924.field_41270, id);
		class_5321<class_3611> flowingKey = class_5321.method_29179(class_7924.field_41270, flowingId);
		FluidEntry entry = new FluidEntry();
		entry.still = new ExperienceFluid(entry, 1);
		entry.flowing = new FlowableFluid.Flowing(entry);
		class_2378.method_39197(class_7923.field_41173, stillKey, entry.still);
		class_2378.method_39197(class_7923.field_41173, flowingKey, entry.flowing);
		return entry;
	}

	private static FluidEntry registerHyperExperience() {
		class_2960 id = EnchantmentIndustry.genRL("hyper_experience");
		class_2960 flowingId = EnchantmentIndustry.genRL("flowing_hyper_experience");
		class_5321<class_3611> stillKey = class_5321.method_29179(class_7924.field_41270, id);
		class_5321<class_3611> flowingKey = class_5321.method_29179(class_7924.field_41270, flowingId);
		FluidEntry entry = new FluidEntry();
		entry.still = new HyperExperienceFluid(entry);
		entry.flowing = new FlowableFluid.Flowing(entry);
		class_2378.method_39197(class_7923.field_41173, stillKey, entry.still);
		class_2378.method_39197(class_7923.field_41173, flowingKey, entry.flowing);
		return entry;
	}

	public static void register() {
		// Class-load triggers the static field initializers above.
	}
}
