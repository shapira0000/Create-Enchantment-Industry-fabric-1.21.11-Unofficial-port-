package plus.dragons.createenchantmentindustry.client;

import com.zurrtum.create.catnip.math.VecHelper;
import com.zurrtum.create.client.catnip.render.FluidRenderHelper;
import com.zurrtum.create.client.flywheel.lib.transform.PoseTransformStack;
import com.zurrtum.create.client.flywheel.lib.transform.TransformStack;
import com.zurrtum.create.client.foundation.blockEntity.renderer.SmartBlockEntityRenderer;
import com.zurrtum.create.content.kinetics.belt.BeltHelper;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3611;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_811;
import net.minecraft.class_9326;
import org.jetbrains.annotations.Nullable;
import plus.dragons.createenchantmentindustry.content.disenchanter.Disenchanting;
import plus.dragons.createenchantmentindustry.content.disenchanter.DisenchanterBlockEntity;

/**
 * Renders the Disenchanter, faithfully reproducing the original 1.20.1 visuals on the new
 * 1.21.11 render-state pipeline. Extends Create Fly's {@link SmartBlockEntityRenderer} (so the
 * base render-state extraction, goggle/link overlays, etc. are handled), and adds: a fluid level
 * inside the casing, the held item moving across an internal belt and spinning while processed,
 * and a swelling experience box around the item during processing. Mirrors Create Fly's own
 * {@code ItemDrainRenderer}.
 */
@Environment(EnvType.CLIENT)
public class DisenchanterRenderer
	extends SmartBlockEntityRenderer<DisenchanterBlockEntity, DisenchanterRenderer.DisenchanterRenderState> {

	public DisenchanterRenderer(class_5614.class_5615 context) {
		super(context);
	}

	@Override
	public DisenchanterRenderState method_74335() {
		return new DisenchanterRenderState();
	}

	@Override
	public void extractRenderState(DisenchanterBlockEntity be, DisenchanterRenderState state, float partialTicks, class_243 cameraPos, @Nullable class_11683.class_11792 crumblingOverlay) {
		super.extractRenderState(be, state, partialTicks, cameraPos, crumblingOverlay);
		updateFluidRenderState(be, state, partialTicks);
		updateItemRenderState(be, state, partialTicks);
	}

	@Override
	public void submit(DisenchanterRenderState state, class_4587 matrices, class_11659 queue, class_12075 cameraState) {
		super.submit(state, matrices, queue, cameraState);
		if (state.process != null) {
			queue.method_73483(matrices, state.process.layer, state.process);
		}
		if (state.item != null) {
			state.item.render(matrices, queue, state.field_62676);
		}
		if (state.fluid != null) {
			matrices.method_46416(0.0F, state.fluid.offset, 0.0F);
			queue.method_73483(matrices, state.fluid.layer, state.fluid);
		}
	}

	private void updateFluidRenderState(DisenchanterBlockEntity be, DisenchanterRenderState state, float partialTicks) {
		SmartFluidTankBehaviour tank = be.internalTank;
		if (tank == null) {
			return;
		}
		SmartFluidTankBehaviour.TankSegment primaryTank = tank.getPrimaryTank();
		FluidStack fluidStack = primaryTank.getRenderedFluid();
		if (!fluidStack.isEmpty()) {
			float level = primaryTank.getFluidLevel().getValue(partialTicks);
			if (level != 0.0F) {
				float yMax = 0.3125F;
				float min = 0.125F;
				float max = min + 0.75F;
				float yOffset = 0.4375F * level;
				float yMin = yMax - yOffset;
				state.fluid = new FluidRenderState(
					class_12249.method_75977(), fluidStack.getFluid(), fluidStack.getComponentChanges(),
					min, max, yMin, yMax, yOffset, state.field_62676
				);
			}
		}

		class_1799 heldItemStack = be.getHeldItemStack();
		if (!heldItemStack.method_7960() && be.processingTicks != 0) {
			Disenchanting.Result result = Disenchanting.disenchantResult(heldItemStack, be.method_10997());
			if (result != null && !result.experience().isEmpty()) {
				FluidStack xp = result.experience();
				float processingPT = (float) be.processingTicks - partialTicks;
				float processingProgress = class_3532.method_15363(1.0F - (processingPT - 5.0F) / 10.0F, 0.0F, 1.0F);
				float radius = (float) (Math.pow(2.0F * processingProgress - 1.0F, 2.0) - 1.0);
				class_238 box = new class_238(0.5, 1.0, 0.5, 0.5, 0.25, 0.5).method_1014(radius / 32.0F);
				state.process = new ProcessRenderState(
					class_12249.method_75977(), xp.getFluid(), xp.getComponentChanges(), box, state.field_62676
				);
			}
		}
	}

	private void updateItemRenderState(DisenchanterBlockEntity be, DisenchanterRenderState state, float partialTicks) {
		TransportedItemStack transported = be.heldItem;
		if (transported == null) {
			return;
		}
		class_2350 insertedFrom = transported.insertedFrom;
		HeldItemRenderState item = state.item = new HeldItemRenderState();
		item.itemPosition = VecHelper.getCenterOf(state.field_62673);
		boolean horizontal = insertedFrom.method_10166().method_10179();
		float offset = horizontal ? class_3532.method_16439(partialTicks, transported.prevBeltPosition, transported.beltPosition) : 0.5F;
		item.offsetVec = class_243.method_24954(insertedFrom.method_10153().method_62675()).method_1021(0.5F - offset);
		if (horizontal) {
			float sideOffset = class_3532.method_16439(partialTicks, transported.prevSideOffset, transported.sideOffset);
			boolean alongX = insertedFrom.method_10170().method_10166() == class_2350.class_2351.field_11048;
			if (!alongX) {
				sideOffset *= -1.0F;
			}
			item.translate = item.offsetVec.method_1031(alongX ? sideOffset : 0.0, 0.0, alongX ? 0.0 : sideOffset);
		} else {
			// Vertical (right-click) insertion: keep the item centered, no side shift.
			item.translate = item.offsetVec;
		}
		class_1799 itemStack = transported.stack;
		item.count = class_3532.method_15386(itemStack.method_7947()) / 2;
		item.upright = BeltHelper.isItemUpright(itemStack);
		item.axis = insertedFrom.method_10166();
		int positive = insertedFrom.method_10171().method_10181();
		item.verticalAngle = (float) positive * offset * 360.0F;

		float processingProgress = switch (be.processingTicks) {
			case 0, 10 -> 0.0F;
			default -> class_3532.method_15363(((float) be.processingTicks - partialTicks) / 10.0F, 0.0F, 1.0F);
		};
		item.spin = processingProgress * 360.0F;

		class_10444 renderState = item.state = new class_10444();
		this.itemModelManager.method_65598(renderState, itemStack, class_811.field_4319, be.method_10997(), null, 0);
	}

	@Environment(EnvType.CLIENT)
	public static class DisenchanterRenderState extends SmartBlockEntityRenderer.SmartRenderState {
		public FluidRenderState fluid;
		public ProcessRenderState process;
		public HeldItemRenderState item;
	}

	@Environment(EnvType.CLIENT)
	public record FluidRenderState(
		class_1921 layer, class_3611 fluid, class_9326 changes,
		float min, float max, float yMin, float yMax, float offset, int light
	) implements class_11659.class_11660 {
		@Override
		public void render(class_4587.class_4665 matricesEntry, class_4588 vertexConsumer) {
			FluidRenderHelper.renderFluidBox(
				fluid, changes, min, yMin, min, max, yMax, max, vertexConsumer, matricesEntry, light, false, false
			);
		}
	}

	@Environment(EnvType.CLIENT)
	public record ProcessRenderState(class_1921 layer, class_3611 fluid, class_9326 changes, class_238 box, int light)
		implements class_11659.class_11660 {
		@Override
		public void render(class_4587.class_4665 matricesEntry, class_4588 vertexConsumer) {
			FluidRenderHelper.renderFluidBox(
				fluid, changes,
				(float) box.field_1323, (float) box.field_1322, (float) box.field_1321,
				(float) box.field_1320, (float) box.field_1325, (float) box.field_1324,
				vertexConsumer, matricesEntry, light, true, false
			);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class HeldItemRenderState {
		public class_10444 state;
		public class_243 itemPosition;
		public class_243 translate;
		public class_243 offsetVec;
		public int count;
		public boolean upright;
		public class_2350.class_2351 axis;
		public float verticalAngle;
		public float spin;

		public void render(class_4587 matrices, class_11659 queue, int light) {
			PoseTransformStack msr = TransformStack.of(matrices);
			matrices.method_22903();
			matrices.method_46416(0.5F, 0.8125F, 0.5F);
			msr.nudge(0);
			matrices.method_61958(translate);

			if (axis != class_2350.class_2351.field_11048) {
				msr.rotateXDegrees(verticalAngle);
			}
			if (axis != class_2350.class_2351.field_11051) {
				msr.rotateZDegrees(-verticalAngle);
			}
			msr.rotateYDegrees(spin);

			Random r = new Random(0L);
			boolean blockItem = state.method_65608();

			for (int i = 0; i <= count; i++) {
				matrices.method_22903();
				if (blockItem) {
					matrices.method_46416(r.nextFloat() * 0.0625F * i, 0.0F, r.nextFloat() * 0.0625F * i);
				}
				matrices.method_22905(0.5F, 0.5F, 0.5F);
				if (!blockItem) {
					msr.rotateXDegrees(90.0F);
				}
				state.method_65604(matrices, queue, light, class_4608.field_21444, 0);
				matrices.method_22909();
				if (!blockItem) {
					msr.rotateYDegrees(10.0F);
				}
				matrices.method_22904(0.0, blockItem ? 0.015625 : 0.0625, 0.0);
			}
			matrices.method_22909();
		}
	}
}
