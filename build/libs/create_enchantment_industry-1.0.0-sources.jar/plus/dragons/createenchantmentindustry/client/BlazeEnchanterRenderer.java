package plus.dragons.createenchantmentindustry.client;

import com.zurrtum.create.catnip.math.AngleHelper;
import com.zurrtum.create.client.AllPartialModels;
import com.zurrtum.create.client.catnip.animation.AnimationTickHolder;
import com.zurrtum.create.client.catnip.render.CachedBuffers;
import com.zurrtum.create.client.catnip.render.SuperByteBuffer;
import com.zurrtum.create.client.flywheel.lib.model.baked.PartialModel;
import com.zurrtum.create.client.foundation.blockEntity.renderer.SmartBlockEntityRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_557;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlockEntity;

/**
 * Renders the Blaze Enchanter: the blaze cage + blaze head (reusing Create's Blaze Burner partial
 * models), plus the real vanilla BookModel floating above the cage, textured with the special
 * blaze_enchanter_book texture, with page-flip animation. The head looks toward the player and the
 * book rotates with it, matching the original 1-to-1.
 */
@Environment(EnvType.CLIENT)
public class BlazeEnchanterRenderer
	extends SmartBlockEntityRenderer<BlazeEnchanterBlockEntity, BlazeEnchanterRenderer.BlazeEnchanterRenderState> {

	// The special book texture (full path under textures/).
	public static final class_2960 BOOK_TEXTURE =
		class_2960.method_60655("create_enchantment_industry", "textures/block/blaze_enchanter_book.png");
	// Render layer bound to that texture (entitySolid is what the vanilla BookModel uses).
	public static final class_1921 BOOK_LAYER = class_12249.method_75982(BOOK_TEXTURE);

	private final class_557 bookModel;

	public BlazeEnchanterRenderer(class_5614.class_5615 context) {
		super(context);
		// Bake the book layer ourselves from BookModel.createBodyLayer() - no ModelLayers lookup needed.
		class_630 root = class_557.method_31986().method_32109();
		this.bookModel = new class_557(root);
	}

	@Override
	public BlazeEnchanterRenderState createRenderState() {
		return new BlazeEnchanterRenderState();
	}

	@Override
	public void extractRenderState(
		BlazeEnchanterBlockEntity be, BlazeEnchanterRenderState state, float partialTicks, class_243 cameraPos,
		@Nullable class_11683.class_11792 crumblingOverlay
	) {
		super.extractRenderState(be, state, partialTicks, cameraPos, crumblingOverlay);

		class_2680 blockState = be.method_11010();
		float animation = be.headAnimation.getValue(partialTicks) * 0.175F;
		float time = AnimationTickHolder.getRenderTime(be.method_10997());
		float headAngleRad = AngleHelper.rad(be.headAngle.getValue(partialTicks));

		boolean active = !be.getInternalTank().getPrimaryHandler().getFluid().isEmpty();

		// SLOW bob when heated (divide by 64 like the Blaze Burner), normal (16) when not.
		float renderTick = time / 16.0F + (be.hashCode() % 13);
		float offsetMult = active ? 64.0F : 16.0F;
		float offset = class_3532.method_15374(renderTick % ((float) Math.PI * 2.0F)) / offsetMult;
		float offset1 = class_3532.method_15374((renderTick + (float) Math.PI) % ((float) Math.PI * 2.0F)) / offsetMult;
		float offset2 = class_3532.method_15374((renderTick + (float) (Math.PI / 2.0)) % ((float) Math.PI * 2.0F)) / offsetMult;

		// Head lift (heated a touch higher). The rods use their OWN smaller lift so the arms
		// sit half-in / half-out of the block like the original (not flying above it).
		float HEAD_LIFT = active ? 0.25F : 0.25F;

		// The head - SAME working setup that shows the eyes (translucentMovingBlock).
		PartialModel blazeModel = active ? AllPartialModels.BLAZE_IDLE : AllPartialModels.BLAZE_INERT;
		BlazeRenderState blaze = new BlazeRenderState();
		blaze.layer = class_12249.method_75977();
		blaze.buffer = CachedBuffers.partial(blazeModel, blockState);
		blaze.translateY = HEAD_LIFT + offset - animation * -0.80F;
		blaze.angle = headAngleRad;
		state.blaze = blaze;

		// Cage uses cutoutMovingBlock so the book stays visible through the sides.
		BlazeRenderState cage = new BlazeRenderState();
		cage.layer = class_12249.method_75972();
		cage.buffer = CachedBuffers.partial(AllPartialModels.BLAZE_CAGE, blockState);
		cage.translateY = 0.0F;
		cage.angle = 0.0F;
		state.cage = cage;

		// Heated: add the two rod rings (the "arms"), each its own state, same render path as
		// the head. Slow movement (offsets already divided by 64).
		if (active) {
			BlazeRenderState rods = new BlazeRenderState();
			rods.layer = class_12249.method_75977();
			rods.buffer = CachedBuffers.partial(AllPartialModels.BLAZE_BURNER_RODS, blockState);
			rods.translateY = HEAD_LIFT + offset1 + animation + 0.125F;
			rods.angle = 0.0F;
			state.rods = rods;

			BlazeRenderState rods2 = new BlazeRenderState();
			rods2.layer = class_12249.method_75977();
			rods2.buffer = CachedBuffers.partial(AllPartialModels.BLAZE_BURNER_RODS_2, blockState);
			rods2.translateY = HEAD_LIFT + offset2 + animation - 0.1875F;
			rods2.angle = 0.0F;
			state.rods2 = rods2;
		}


		// The floating open book. Rotates with the head; bobs on a sine wave; pages flutter.
		BookRenderState book = new BookRenderState();
		book.model = this.bookModel;
		book.layer = BOOK_LAYER;
		book.angle = headAngleRad;
		book.bob = 0.9F + offset;
		book.light = state.lightCoords;
		book.animationPos = time;
		book.pageFlip1 = (class_3532.method_15374(time * 0.1F) + 1.0F) * 0.5F;
		book.pageFlip2 = (class_3532.method_15362(time * 0.1F) + 1.0F) * 0.5F;
		book.open = 1.0F;
		state.book = book;

		// The item being enchanted, riding up over the block and spinning while processed.
		updateHeldItemRenderState(be, state, partialTicks);
	}

	private void updateHeldItemRenderState(BlazeEnchanterBlockEntity be, BlazeEnchanterRenderState state, float partialTicks) {
		TransportedItemStack transported = be.heldItem;
		if (transported == null) {
			return;
		}
		HeldItemRenderState item = state.item = new HeldItemRenderState();

		float beltPos = class_3532.method_16439(partialTicks, transported.prevBeltPosition, transported.beltPosition);

		// Vertical bob: rises toward the middle (peak at 0.5) plus a gentle idle wobble.
		float time = AnimationTickHolder.getRenderTime(be.method_10997());
		float renderTick = time / 16.0F + (be.hashCode() % 13);
		boolean active = !be.getInternalTank().getPrimaryHandler().getFluid().isEmpty();
		float offsetMult = active ? 64.0F : 16.0F;
		float sineOffset = class_3532.method_15374(renderTick % ((float) Math.PI * 2.0F)) / offsetMult;
		float lift = class_3532.method_15374((0.5F - Math.abs(0.5F - beltPos)) * (float) Math.PI / 2.0F);
		item.bob = lift * 0.75F + sineOffset * 0.75F;

		class_2350 insertedFrom = transported.insertedFrom;
		boolean horizontal = insertedFrom.method_10166().method_10179();
		class_243 along = class_243.method_24954(insertedFrom.method_10153().method_62675()).method_1021(0.5F - beltPos);
		item.travel = horizontal ? along : class_243.field_1353;

		float twoPi = (float) Math.PI * 2.0F;
		boolean enchanting = be.processingTicks > 0;

		if (be.waitingForXp) {
			// PARKED, waiting for experience: sit in place and spin around the X axis (rolling
			// over and over on itself), indefinitely, until experience arrives. No tumble, no
			// travel - it just stays put and rotates on X.
			float spin = (renderTick / 16.0F) % twoPi;
			item.angleX = spin;
			item.angleY = 0.0F;
			item.angleZ = 0.0F;
		} else if (enchanting) {
			// ENCHANTING: a real multi-axis tumble. Which side-axis it rolls on depends on the
			// insertion direction (matches the original), and it always also turns on Y, so the
			// item visibly moves through several orientations rather than flipping on one spot.
			// getClockWise() is only valid for horizontal directions; a hand-inserted item comes
			// from UP, so default it to rolling on the X axis.
			float spin = ((be.processingTicks - partialTicks) / 16.0F) % twoPi;
			boolean rollX = !insertedFrom.method_10166().method_10179()
				|| insertedFrom.method_10170().method_10166() == class_2350.class_2351.field_11048;
			item.angleX = rollX ? spin : 0.0F;
			item.angleZ = rollX ? 0.0F : spin;
			item.angleY = spin * 0.5F + (transported.angle % 360) / 360.0F * (float) Math.PI;
		} else {
			// Passthrough (riding across, not enchantable): a gentle idle spin on Y.
			float spin = (renderTick / 16.0F) % twoPi;
			item.angleX = 0.0F;
			item.angleY = spin;
			item.angleZ = 0.0F;
		}

		class_1799 itemStack = transported.stack;
		class_10444 renderState = item.state = new class_10444();
		this.itemModelManager.method_65598(renderState, itemStack, class_811.field_4319, be.method_10997(), null, 0);
	}

	@Override
	public void submit(
		BlazeEnchanterRenderState state, class_4587 matrices, class_11659 queue, class_12075 cameraState
	) {
		super.submit(state, matrices, queue, cameraState);
		// Book first, then the blaze head, then the cage.
		if (state.book != null) {
			queue.method_73483(matrices, state.book.layer, state.book);
		}
		if (state.item != null) {
			state.item.render(matrices, queue, state.lightCoords);
		}
		if (state.blaze != null) {
			queue.method_73483(matrices, state.blaze.layer, state.blaze);
		}
		if (state.rods != null) {
			queue.method_73483(matrices, state.rods.layer, state.rods);
		}
		if (state.rods2 != null) {
			queue.method_73483(matrices, state.rods2.layer, state.rods2);
		}
		if (state.cage != null) {
			queue.method_73483(matrices, state.cage.layer, state.cage);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class BlazeEnchanterRenderState extends SmartRenderState {
		public BlazeRenderState blaze;
		public BlazeRenderState cage;
		public BlazeRenderState rods;
		public BlazeRenderState rods2;
		public BookRenderState book;
		public HeldItemRenderState item;
	}

	@Environment(EnvType.CLIENT)
	public static class BlazeRenderState implements class_11659.class_11660 {
		public class_1921 layer;
		public SuperByteBuffer buffer;
		public float translateY;
		public float angle;

		@Override
		public void render(class_4587.class_4665 matricesEntry, class_4588 vertexConsumer) {
			buffer.translate(0.0F, translateY, 0.0F);
			buffer.rotateCentered(angle, class_2350.field_11036);
			buffer.light(15728880);
			buffer.renderInto(matricesEntry, vertexConsumer);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class BookRenderState implements class_11659.class_11660 {
		public class_557 model;
		public class_1921 layer;
		public float angle;
		public float bob;
		public int light;
		public float animationPos;
		public float pageFlip1;
		public float pageFlip2;
		public float open;

		@Override
		public void render(class_4587.class_4665 matricesEntry, class_4588 vertexConsumer) {
			// Reconstruct a PoseStack carrying the supplied pose so the entity model can render.
			class_4587 ms = new class_4587();
			ms.method_23760().method_23761().set(matricesEntry.method_23761());
			ms.method_23760().method_23762().set(matricesEntry.method_23762());

			// XP(90) lays it flat; the extra YP(90) turns the spine so BOTH covers open UPWARD
			// into a proper open-book V (without it, one cover goes up and the other down).
			// Face the player (track the head), then orient as an open book tilted like an
			// enchanting-table lectern (not flat): a partial backward tilt instead of full 90.
			ms.method_46416(0.5F, 0.4F, 0.5F);
			ms.method_22907(class_7833.field_40716.rotation(angle));
			ms.method_22907(class_7833.field_40714.rotationDegrees(75.0F));
			ms.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
			ms.method_22905(1.0F, 1.0F, 1.0F);

			model.method_17073(new class_557.class_11650(animationPos, pageFlip1, pageFlip2, open));
			model.method_60879(ms, vertexConsumer, light, class_4608.field_21444);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class HeldItemRenderState {
		public class_10444 state;
		public class_243 travel;
		public float bob;
		public float angleX;
		public float angleY;
		public float angleZ;

		public void render(class_4587 matrices, class_11659 queue, int light) {
			matrices.method_22903();
			matrices.method_46416(0.5F, 1.05F + bob, 0.5F);
			matrices.method_22904(travel.field_1352, travel.field_1351, travel.field_1350);
			// Apply the tumble. Y is the upright spin; X/Z roll it over while enchanting.
			matrices.method_22907(class_7833.field_40716.rotation(angleY));
			matrices.method_22907(class_7833.field_40714.rotation(angleX));
			matrices.method_22907(class_7833.field_40718.rotation(angleZ));
			matrices.method_22905(0.5F, 0.5F, 0.5F);
			state.method_65604(matrices, queue, light, class_4608.field_21444, 0);
			matrices.method_22909();
		}
	}

}
