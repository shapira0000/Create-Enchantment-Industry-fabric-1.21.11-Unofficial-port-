package plus.dragons.createenchantmentindustry.client.gui;

import com.zurrtum.create.client.catnip.gui.element.GuiGameElement;
import com.zurrtum.create.client.catnip.gui.element.RenderElement;
import com.zurrtum.create.client.foundation.gui.AllGuiTextures;
import com.zurrtum.create.client.foundation.gui.menu.AbstractSimiContainerScreen;
import com.zurrtum.create.client.foundation.gui.widget.Label;
import com.zurrtum.create.client.foundation.gui.widget.SelectionScrollInput;
import com.zurrtum.create.foundation.gui.menu.MenuType;
import java.util.Collections;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_768;
import net.minecraft.class_9129;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideEditPacket;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideMenu;

/**
 * Client screen for the Enchanting Guide: shows the ghost book slot, a scroll selector to choose
 * which of the book's enchantments to apply, and a label with the chosen enchantment's name.
 * Each pick sends an {@link EnchantingGuideEditPacket} so the server records the choice and writes
 * it onto the guide when the screen closes.
 */
@Environment(EnvType.CLIENT)
public class EnchantingGuideScreen extends AbstractSimiContainerScreen<EnchantingGuideMenu> {

	private static final class_2960 BACKGROUND =
		class_2960.method_60655("create_enchantment_industry", "textures/gui/enchanting_guide.png");
	private static final int PANEL_WIDTH = 185;
	private static final int PANEL_HEIGHT = 48;

	private List<class_768> extraAreas = Collections.emptyList();
	private SelectionScrollInput scrollInput;
	private Label scrollInputLabel;
	private int index;
	private java.util.List<net.minecraft.class_2561> lastShown;

	public EnchantingGuideScreen(EnchantingGuideMenu menu, class_1661 inv, class_2561 title) {
		super(menu, inv, title);
		this.index = menu.index;
	}

	public static EnchantingGuideScreen create(
		class_310 mc, MenuType<class_1799> type, int syncId, class_1661 inventory, class_2561 title, class_9129 extraData
	) {
		class_1799 guide = getStack(extraData);
		boolean hasBlock = extraData.readBoolean();
		net.minecraft.class_2338 blockPos = hasBlock ? extraData.method_10811() : null;
		EnchantingGuideScreen screen = type.create(EnchantingGuideScreen::new, syncId, inventory, title, guide);
		if (screen != null) {
			screen.field_2797.blockPos = blockPos;
		}
		return screen;
	}

	@Override
	protected void method_25426() {
		setWindowSize(AllGuiTextures.PLAYER_INVENTORY.getWidth(), PANEL_HEIGHT + 6 + AllGuiTextures.PLAYER_INVENTORY.getHeight());
		super.method_25426();

		int x = field_2776;
		int y = field_2800;

		// Guard against a null/empty list so the scroll widget never indexes out of bounds.
		java.util.List<net.minecraft.class_2561> options =
			(field_2797.enchantments == null || field_2797.enchantments.isEmpty())
				? java.util.List.of(EnchantingGuideMenu.NO_ENCHANTMENT)
				: field_2797.enchantments;
		int startIndex = Math.max(0, Math.min(index, options.size() - 1));

		scrollInputLabel = new Label(x + 50, y + 27, class_2561.method_43473()).withShadow();
		scrollInput = (SelectionScrollInput) new SelectionScrollInput(x + 43, y + 22, 116, 18)
			.forOptions(options)
			.writingTo(scrollInputLabel)
			.titled(class_2561.method_43471("create_enchantment_industry.gui.enchanting_guide.search").method_27661())
			.calling(i -> index = i)
			.setState(startIndex);
		scrollInput.onChanged();

		method_37063(scrollInput);
		method_37063(scrollInputLabel);

		extraAreas = Collections.singletonList(new class_768(x + field_2792, y, 56, 56));
	}

	@Override
	protected void method_2389(class_332 graphics, float partialTicks, int mouseX, int mouseY) {
		int x = field_2776;
		int y = field_2800;

		// The enchanting-guide panel (top), then the player inventory (below).
		graphics.method_25290(net.minecraft.class_10799.field_56883, BACKGROUND,
			x, y, 0.0F, 0.0F, PANEL_WIDTH, PANEL_HEIGHT, 256, 256);
		renderPlayerInventory(graphics, x, y + PANEL_HEIGHT + 6);

		graphics.method_51439(field_22793, field_22785, x + 15, y + 4, 0x592424, false);

		class_1799 guide = field_2797.contentHolder;
		RenderElement element = GuiGameElement.of(guide)
			.scale(3.0F)
			.at((float) (x + field_2792 + 6), (float) (y + 20), -200.0F);
		element.render(graphics);
	}

	@Override
	public void method_25432() {
		// Commit on close in a single packet that includes the chosen index AND the book in the
		// ghost slot (so the server doesn't depend on ghost-inventory syncing). Mirrors the
		// original CEI's removed() behaviour.
		if (scrollInput != null) {
			int chosen = scrollInput.getState();
			class_1799 book = field_2797.getGhostBook();
			ClientPlayNetworking.send(new EnchantingGuideEditPacket(chosen, book.method_7972(), field_2797.blockPos));
		}
		super.method_25432();
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
		// Vanilla container screens don't forward scroll to child widgets; do it manually so the
		// enchantment selector scrolls when the cursor is over it.
		return method_19355(mouseX, mouseY)
			.filter(child -> child.method_25401(mouseX, mouseY, scrollX, scrollY))
			.isPresent()
			|| super.method_25401(mouseX, mouseY, scrollX, scrollY);
	}

	@Override
	public List<class_768> getExtraAreas() {
		return extraAreas;
	}

	@Override
	protected void method_37432() {
		super.method_37432();
		// Rebuild from the current book in the ghost slot (client-side). Only refresh the scroll
		// options when the CONTENT actually changed (compare by value, not by reference - the
		// list is a fresh object each tick), and never call onChanged() here (that would re-fire
		// the scroll callback and re-send the packet, causing an off-by-one feedback loop).
		field_2797.updateEnchantments(field_2797.getGhostBook());
		if (field_2797.enchantments != null && !field_2797.enchantments.equals(lastShown)) {
			lastShown = field_2797.enchantments;
			int keep = Math.max(0, Math.min(scrollInput.getState(), field_2797.enchantments.size() - 1));
			scrollInput.forOptions(field_2797.enchantments);
			scrollInput.setState(keep);
		}
		// Keep our tracked index in sync with the widget (the widget is the source of truth).
		index = scrollInput.getState();
	}
}
