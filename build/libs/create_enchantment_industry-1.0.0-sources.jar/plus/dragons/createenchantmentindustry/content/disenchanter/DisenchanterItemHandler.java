package plus.dragons.createenchantmentindustry.content.disenchanter;

import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.infrastructure.items.ItemInventory;
import net.minecraft.class_1799;
import net.minecraft.class_2350;

/**
 * The item-insertion face of the Disenchanter, one per horizontal side.
 *
 * <p>Modelled on Create Fly's {@code ItemDrainItemHandler}: it implements the simple
 * {@link ItemInventory} interface (a single-slot inventory) rather than the heavier
 * transfer-API plumbing the original 1.20.1 mod used. Inserting an item hands it to the
 * block entity as a {@link TransportedItemStack}; the block entity then runs it across
 * its internal "belt" and disenchants it at the halfway point.</p>
 */
public class DisenchanterItemHandler implements ItemInventory {
	private final DisenchanterBlockEntity blockEntity;
	private final class_2350 side;

	public DisenchanterItemHandler(DisenchanterBlockEntity be, class_2350 side) {
		this.blockEntity = be;
		this.side = side.method_10153();
	}

	@Override
	public int method_5439() {
		return 1;
	}

	@Override
	public int method_58350(class_1799 stack) {
		return stack.method_7914();
	}

	@Override
	public boolean method_5437(int slot, class_1799 stack) {
		return blockEntity.getHeldItemStack().method_7960();
	}

	@Override
	public class_1799 method_5438(int slot) {
		return slot > 1 ? class_1799.field_8037 : blockEntity.getHeldItemStack();
	}

	@Override
	public void method_5447(int slot, class_1799 stack) {
		if (slot <= 1) {
			if (stack.method_7960()) {
				blockEntity.heldItem = null;
			} else {
				TransportedItemStack heldItem = new TransportedItemStack(stack);
				heldItem.prevBeltPosition = 0.0F;
				blockEntity.setHeldItem(heldItem, side);
			}
		}
	}

	@Override
	public void method_5431() {
		blockEntity.notifyUpdate();
	}
}
