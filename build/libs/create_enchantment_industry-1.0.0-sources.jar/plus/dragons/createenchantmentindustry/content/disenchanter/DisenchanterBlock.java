package plus.dragons.createenchantmentindustry.content.disenchanter;

import com.zurrtum.create.AllShapes;
import com.zurrtum.create.content.equipment.wrench.IWrenchable;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.foundation.block.IBE;
import com.zurrtum.create.foundation.blockEntity.ComparatorUtil;
import com.zurrtum.create.infrastructure.fluids.FluidInventory;
import com.zurrtum.create.infrastructure.fluids.FluidInventoryProvider;
import com.zurrtum.create.infrastructure.items.ItemInventoryProvider;
import net.minecraft.class_10;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import plus.dragons.createenchantmentindustry.registry.CeiBlockEntities;

/**
 * The Disenchanter block. Built on Create Fly's {@code ItemDrainBlock}: {@link IWrenchable}
 * for wrench pickup, {@link IBE} binding to {@link DisenchanterBlockEntity}, and the
 * inventory provider hooks so Create's belts and fluid pipes can interact with it.
 */
public class DisenchanterBlock extends class_2248
	implements IWrenchable,
	IBE<DisenchanterBlockEntity>,
	ItemInventoryProvider<DisenchanterBlockEntity>,
	FluidInventoryProvider<DisenchanterBlockEntity> {

	public DisenchanterBlock(class_2251 properties) {
		super(properties);
	}

	@Override
	public class_1263 getInventory(class_1936 world, class_2338 pos, class_2680 state, DisenchanterBlockEntity be, class_2350 context) {
		return context != null && context.method_10166().method_10179() ? be.itemHandlers.get(context) : null;
	}

	@Override
	public FluidInventory getFluidInventory(class_1936 world, class_2338 pos, class_2680 state, DisenchanterBlockEntity be, class_2350 context) {
		return be.internalTank.getCapability();
	}

	@Override
	protected class_1269 method_55765(
		class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
	) {
		if (hand == class_1268.field_5810) {
			return class_1269.field_5811;
		}
		if (stack.method_7960()) {
			return onBlockEntityUseItemOn(level, pos, be -> {
				if (be.getHeldItemStack().method_7960()) {
					return class_1269.field_5811;
				}
				if (!level.method_8608()) {
					player.method_6122(hand, be.heldItem.stack);
					be.heldItem = null;
					be.notifyUpdate();
				}
				return class_1269.field_5812;
			});
		}
		if (hitResult.method_17780() != class_2350.field_11036) {
			return class_1269.field_5811;
		}
		return onBlockEntityUseItemOn(level, pos, be -> {
			if (!be.getHeldItemStack().method_7960()) {
				return class_1269.field_5811;
			}
			class_1799 insert = stack.method_7972();
			insert.method_7939(1);
			// Experience Nugget / Block convert instantly and only via belt insertion -
			// they must not be insertable by hand (matches the original CEI).
			if (Disenchanting.instantConversionUnitsPerItem(insert) > 0) {
				return class_1269.field_5811;
			}
			if (Disenchanting.disenchantResult(insert, level) == null) {
				return class_1269.field_5811;
			}
			if (!level.method_8608()) {
				be.heldItem = new TransportedItemStack(insert);
				be.notifyUpdate();
				stack.method_7934(1);
			}
			return class_1269.field_5812;
		});
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
		return AllShapes.CASING_13PX.get(class_2350.field_11036);
	}

	@Override
	public Class<DisenchanterBlockEntity> getBlockEntityClass() {
		return DisenchanterBlockEntity.class;
	}

	@Override
	public class_2591<? extends DisenchanterBlockEntity> getBlockEntityType() {
		return CeiBlockEntities.DISENCHANTER;
	}

	@Override
	public boolean method_9498(class_2680 state) {
		return true;
	}

	@Override
	public int method_9572(class_2680 state, class_1937 level, class_2338 pos, class_2350 direction) {
		return ComparatorUtil.levelOfSmartFluidTank(level, pos);
	}

	@Override
	protected boolean method_9516(class_2680 state, class_10 type) {
		return false;
	}
}
