package plus.dragons.createenchantmentindustry.content.disenchanter;

import com.zurrtum.create.AllItems;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9636;
import org.jetbrains.annotations.Nullable;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;

/**
 * Core disenchanting logic: turning an enchanted item into Liquid Experience and a
 * cleaned-up item, ported to the 1.21.11 enchantment API.
 *
 * <h2>What changed from the original 1.20.1 implementation</h2>
 * The original CEI stored enchantments as NBT tags and used now-removed APIs
 * ({@code EnchantmentHelper.getEnchantments} returning a {@code Map}, {@code Enchantment#isCurse}).
 * In 1.21.11 enchantments live in {@link class_9334#field_49633} /
 * {@link class_9334#field_49643} as an {@link class_9304} component whose
 * keys are {@link class_6880}&lt;{@link class_1887}&gt;, and "curse" is the tag
 * {@link class_9636#field_51551} rather than a method. This class is rewritten around that.
 *
 * <h2>Fluid amounts</h2>
 * Amounts are in Create Fly fluid units; {@link EnchantmentIndustry#UNIT_PER_MB} (81) units
 * equal one experience point, matching the original ratio.
 */
public class Disenchanting {

	/**
	 * Compute the result of disenchanting an item, or {@code null} if it can't be disenchanted.
	 *
	 * @return a pair of (experience fluid produced, resulting cleaned item), or {@code null}
	 */
	@Nullable
	public static Result disenchantResult(class_1799 itemStack, class_1937 level) {
		// Special "experience" inputs that the original CEI handles via disenchanting recipes.
		// Amounts mirror the original recipe JSONs (in mB; multiplied by UNIT_PER_MB for fluid units).
		Result special = specialDisenchantResult(itemStack);
		if (special != null) {
			return special;
		}

		class_9304 enchantments = getEnchantments(itemStack);
		// Only proceed if the item carries at least one non-curse enchantment.
		boolean hasRemovable = enchantments.method_57534().stream().anyMatch(holder -> !isCurse(holder));
		if (!hasRemovable) {
			return null;
		}
		int experience = getDisenchantExperience(itemStack);
		class_1799 result = disenchant(itemStack);
		FluidStack xp = new FluidStack(CeiFluids.EXPERIENCE.still, experience);
		return new Result(xp, result);
	}

	/**
	 * Handles the fixed "experience" inputs the original CEI disenchants directly into fluid:
	 * the Experience Nugget (3 mB), Experience Block (27 mB), and Enchanted Golden Apple
	 * (a Golden Apple back + 100 mB). Returns null for anything else.
	 */
	/**
	 * For "experience" items that convert instantly with no leftover (Experience Nugget,
	 * Experience Block): returns the per-item fluid amount in units. Returns 0 otherwise.
	 * The Enchanted Golden Apple is NOT included here because it leaves a Golden Apple behind,
	 * so it goes through the normal animated belt flow.
	 */
	public static int instantConversionUnitsPerItem(class_1799 itemStack) {
		if (itemStack.method_31574(AllItems.EXP_NUGGET)) {
			return 3 * EnchantmentIndustry.UNIT_PER_MB;
		} else if (itemStack.method_31574(AllItems.EXPERIENCE_BLOCK)) {
			return 27 * EnchantmentIndustry.UNIT_PER_MB;
		}
		return 0;
	}

	@Nullable
	private static Result specialDisenchantResult(class_1799 itemStack) {
		int mb = 0;
		class_1799 leftover = class_1799.field_8037;
		if (itemStack.method_31574(AllItems.EXP_NUGGET)) {
			mb = 3;
		} else if (itemStack.method_31574(AllItems.EXPERIENCE_BLOCK)) {
			mb = 27;
		} else if (itemStack.method_31574(class_1802.field_8367)) {
			mb = 100;
			leftover = new class_1799(class_1802.field_8463);
		} else {
			return null;
		}
		FluidStack xp = new FluidStack(CeiFluids.EXPERIENCE.still, mb * EnchantmentIndustry.UNIT_PER_MB);
		return new Result(xp, leftover);
	}

	/**
	 * Produce a copy of the item with all non-curse enchantments stripped.
	 * Curses are deliberately preserved (you can't cleanse a curse by disenchanting).
	 * An enchanted book that ends up with no enchantments becomes a plain book.
	 */
	public static class_1799 disenchant(class_1799 itemStack) {
		class_1799 result = itemStack.method_7972();

		boolean isStored = result.method_57826(class_9334.field_49643);
		class_9304 current = getEnchantments(result);

		// Keep only curses.
		class_9304.class_9305 builder = new class_9304.class_9305(class_9304.field_49385);
		boolean keptAny = false;
		for (class_6880<class_1887> holder : current.method_57534()) {
			if (isCurse(holder)) {
				builder.method_57547(holder, current.method_57536(holder));
				keptAny = true;
			}
		}
		class_9304 remaining = builder.method_57549();

		// An enchanted book with nothing left becomes a normal book.
		if (result.method_31574(class_1802.field_8598) && !keptAny) {
			class_1799 book = new class_1799(class_1802.field_8529);
			book.method_7939(result.method_7947());
			return book;
		}

		if (isStored) {
			result.method_57379(class_9334.field_49643, remaining);
		} else {
			result.method_57379(class_9334.field_49633, remaining);
		}
		// Reset the prior-work penalty so the cleaned item is cheap to use again.
		result.method_57381(class_9334.field_49639);
		return result;
	}

	/**
	 * The experience (in fluid units) yielded by an item's non-curse enchantments.
	 * Mirrors the original formula: sum of each enchantment's minimum cost at its level,
	 * times 0.75 (rounded up), converted to fluid units.
	 */
	public static int getDisenchantExperience(class_1799 itemStack) {
		class_9304 enchantments = getEnchantments(itemStack);
		int xp = 0;
		for (class_6880<class_1887> holder : enchantments.method_57534()) {
			if (isCurse(holder)) {
				continue;
			}
			int level = enchantments.method_57536(holder);
			xp += holder.comp_349().method_8182(level);
		}
		if (xp == 0) {
			return 0;
		}
		return class_3532.method_15384(xp * 0.75) * EnchantmentIndustry.UNIT_PER_MB;
	}

	/** Read whichever enchantment component the item uses (stored for books, normal otherwise). */
	private static class_9304 getEnchantments(class_1799 stack) {
		if (stack.method_57826(class_9334.field_49643)) {
			return stack.method_58694(class_9334.field_49643);
		}
		return class_1890.method_57532(stack);
	}

	/** A curse in 1.21.11 is any enchantment tagged {@link class_9636#field_51551}. */
	private static boolean isCurse(class_6880<class_1887> holder) {
		return holder.method_40220(class_9636.field_51551);
	}

	/** Result of a disenchant operation: the experience fluid and the cleaned item. */
	public record Result(FluidStack experience, class_1799 item) {
	}
}
