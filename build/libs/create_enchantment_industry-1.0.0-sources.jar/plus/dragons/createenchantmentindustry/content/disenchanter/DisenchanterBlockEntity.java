package plus.dragons.createenchantmentindustry.content.disenchanter;

import com.zurrtum.create.api.behaviour.BlockEntityBehaviour;
import com.zurrtum.create.catnip.data.Iterate;
import com.zurrtum.create.catnip.math.VecHelper;
import com.zurrtum.create.content.kinetics.belt.behaviour.DirectBeltInputBehaviour;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.foundation.blockEntity.SmartBlockEntity;
import com.zurrtum.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.zurrtum.create.foundation.utility.BlockHelper;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1264;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import plus.dragons.createenchantmentindustry.content.fluids.experience.ExperienceFluid;
import plus.dragons.createenchantmentindustry.registry.CeiConfig;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;

/**
 * The Disenchanter's block entity.
 *
 * <p>Structurally modelled on Create Fly's {@code ItemDrainBlockEntity}: an item is inserted,
 * carried across an internal "belt", and processed at the halfway point. Where Item Drain
 * empties a fluid item into its tank, the Disenchanter strips an item's enchantments (see
 * {@link Disenchanting}) and fills its internal tank with the resulting Liquid Experience.</p>
 *
 * <p>Clean core. Deferred for later: absorbing XP from nearby players, advancements, goggle info.</p>
 */
public class DisenchanterBlockEntity extends SmartBlockEntity {
	public static final int DISENCHANTER_TIME = 10;

	public SmartFluidTankBehaviour internalTank;
	public TransportedItemStack heldItem;
	public int processingTicks;
	protected class_238 absorbArea;
	public Map<class_2350, DisenchanterItemHandler> itemHandlers = new IdentityHashMap<>();

	public DisenchanterBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		for (class_2350 d : Iterate.horizontalDirections) {
			itemHandlers.put(d, new DisenchanterItemHandler(this, d));
		}
		this.absorbArea = new class_238(pos.method_10084());
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour<?>> behaviours) {
		behaviours.add(new DirectBeltInputBehaviour(this).allowingBeltFunnels().setInsertionHandler(this::tryInsertingFromSide));
		int capacity = CeiConfig.disenchanterTankCapacityUnits();
		behaviours.add(
			this.internalTank = SmartFluidTankBehaviour.single(this, capacity).allowExtraction().forbidInsertion()
		);
	}

	@Override
	public void destroy() {
		super.destroy();
		class_1799 heldItemStack = getHeldItemStack();
		if (!heldItemStack.method_7960()) {
			class_1264.method_5449(field_11863, field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(), heldItemStack);
		}
		// Spill any stored experience back into the world as orbs.
		if (field_11863 instanceof class_3218 serverLevel) {
			FluidStack fluid = internalTank.getPrimaryHandler().getFluid();
			if (fluid.getFluid() instanceof ExperienceFluid expFluid && !fluid.isEmpty()) {
				expFluid.drop(serverLevel, VecHelper.getCenterOf(field_11867), fluid.getAmount());
			}
		}
	}

	private class_1799 tryInsertingFromSide(TransportedItemStack transportedStack, class_2350 side, boolean simulate) {
		class_1799 inserted = transportedStack.stack;
		class_1799 returned = class_1799.field_8037;
		if (!getHeldItemStack().method_7960()) {
			return inserted;
		}

		// Instant-conversion items (Experience Nugget / Block): convert the WHOLE stack to fluid
		// immediately, with no held-item animation. Faithful to the original CEI behaviour.
		int unitsPerItem = Disenchanting.instantConversionUnitsPerItem(inserted);
		if (unitsPerItem > 0) {
			if (field_11863.method_8608()) {
				return class_1799.field_8037;
			}
			int count = inserted.method_7947();
			int total = unitsPerItem * count;
			FluidStack xp = new FluidStack(CeiFluids.EXPERIENCE.still, total);
			internalTank.allowInsertion();
			int room = internalTank.getPrimaryHandler().countSpace(xp);
			int acceptCount = unitsPerItem > 0 ? Math.min(count, room / unitsPerItem) : 0;
			if (acceptCount <= 0) {
				internalTank.forbidInsertion();
				return inserted; // tank full - reject so the belt holds the item
			}
			if (simulate) {
				internalTank.forbidInsertion();
				return inserted.method_46651(count - acceptCount);
			}
			internalTank.getPrimaryHandler().insert(new FluidStack(CeiFluids.EXPERIENCE.still, unitsPerItem * acceptCount));
			internalTank.forbidInsertion();
			field_11863.method_20290(1042, field_11867, 0);
			method_5431();
			sendData();
			return inserted.method_46651(count - acceptCount);
		}

		if (Disenchanting.disenchantResult(inserted, field_11863) == null) {
			return inserted;
		}
		if (inserted.method_7947() > 1) {
			returned = inserted.method_46651(inserted.method_7947() - 1);
			inserted = inserted.method_46651(1);
		}
		if (simulate) {
			return returned;
		}
		transportedStack = transportedStack.copy();
		transportedStack.stack = inserted.method_7972();
		transportedStack.beltPosition = side.method_10166().method_10178() ? 0.5F : 0.0F;
		transportedStack.prevSideOffset = transportedStack.sideOffset;
		transportedStack.prevBeltPosition = transportedStack.beltPosition;
		setHeldItem(transportedStack, side);
		method_5431();
		sendData();
		return returned;
	}

	public class_1799 getHeldItemStack() {
		return heldItem == null ? class_1799.field_8037 : heldItem.stack;
	}

	@Override
	public void tick() {
		super.tick();
		if (field_11863 instanceof class_3218 serverLevel && field_11863.method_75260() % 10L == 0L) {
			absorbExperienceFromWorld(serverLevel);
		}
		if (heldItem == null) {
			processingTicks = 0;
			return;
		}
		boolean onClient = field_11863.method_8608() && !isVirtual();
		if (processingTicks > 0) {
			heldItem.prevBeltPosition = 0.5F;
			boolean wasAtBeginning = processingTicks == DISENCHANTER_TIME;
			if (!onClient || processingTicks < DISENCHANTER_TIME) {
				processingTicks--;
			}
			if (!continueProcessing()) {
				processingTicks = 0;
				notifyUpdate();
			} else if (wasAtBeginning != (processingTicks == DISENCHANTER_TIME)) {
				sendData();
			}
			return;
		}

		heldItem.prevBeltPosition = heldItem.beltPosition;
		heldItem.prevSideOffset = heldItem.sideOffset;
		heldItem.beltPosition += itemMovementPerTick();

		if (heldItem.beltPosition > 1.0F) {
			heldItem.beltPosition = 1.0F;
			if (!onClient) {
				exportItem();
			}
		} else if (heldItem.prevBeltPosition < 0.5F && heldItem.beltPosition >= 0.5F) {
			if (Disenchanting.disenchantResult(heldItem.stack.method_7972(), field_11863) == null) {
				return;
			}
			heldItem.beltPosition = 0.5F;
			if (onClient) {
				return;
			}
			processingTicks = DISENCHANTER_TIME;
			sendData();
		}
	}

	/** Push the finished item out to the far side, or eject it into the world. */
	private void exportItem() {
		class_2350 side = heldItem.insertedFrom;
		class_1799 tryExport = getBehaviour(DirectBeltInputBehaviour.TYPE)
			.tryExportingToBeltFunnel(heldItem.stack, side.method_10153(), false);
		if (tryExport != null) {
			if (tryExport.method_7947() != heldItem.stack.method_7947()) {
				if (tryExport.method_7960()) {
					heldItem = null;
				} else {
					heldItem.stack = tryExport;
				}
				notifyUpdate();
				return;
			}
			if (!tryExport.method_7960()) {
				return;
			}
		}

		class_2338 nextPosition = field_11867.method_10093(side);
		DirectBeltInputBehaviour next = BlockEntityBehaviour.get(field_11863, nextPosition, DirectBeltInputBehaviour.TYPE);
		if (next == null) {
			if (!BlockHelper.hasBlockSolidSide(field_11863.method_8320(nextPosition), field_11863, nextPosition, side.method_10153())) {
				class_1799 ejected = heldItem.stack;
				class_243 outPos = VecHelper.getCenterOf(field_11867).method_1019(class_243.method_24954(side.method_62675()).method_1021(0.75));
				float speed = itemMovementPerTick();
				class_243 outMotion = class_243.method_24954(side.method_62675()).method_1021(speed).method_1031(0.0, 0.125, 0.0);
				outPos.method_1019(outMotion.method_1029());
				class_1542 entity = new class_1542(field_11863, outPos.field_1352, outPos.field_1351 + 0.375, outPos.field_1350, ejected);
				entity.method_18799(outMotion);
				entity.method_6988();
				field_11863.method_8649(entity);
				heldItem = null;
				notifyUpdate();
			}
		} else if (next.canInsertFromSide(side)) {
			class_1799 returned = next.handleInsertion(heldItem.copy(), side, false);
			if (returned.method_7960()) {
				heldItem = null;
				notifyUpdate();
			} else if (returned.method_7947() != heldItem.stack.method_7947()) {
				heldItem.stack = returned;
				notifyUpdate();
			}
		}
	}

	/** Perform the disenchant mid-belt, filling the internal tank. */
	protected boolean continueProcessing() {
		if (field_11863.method_8608() && !isVirtual()) {
			return true;
		}
		if (processingTicks < 5) {
			return true;
		}
		if (heldItem.stack.method_7947() <= 0) {
			return false;
		}
		Disenchanting.Result result = Disenchanting.disenchantResult(heldItem.stack, field_11863);
		if (result == null) {
			return false;
		}

		int perItem = result.experience().getAmount();
		int total = perItem * heldItem.stack.method_7947();
		FluidStack xp = new FluidStack(result.experience().getFluid(), total);

		if (processingTicks > 5) {
			internalTank.allowInsertion();
			boolean noRoom = internalTank.getPrimaryHandler().countSpace(xp) != total;
			internalTank.forbidInsertion();
			if (noRoom) {
				processingTicks = DISENCHANTER_TIME;
			}
			return true;
		}

		class_1799 resultItem = result.item();
		internalTank.allowInsertion();
		internalTank.getPrimaryHandler().insert(xp);
		internalTank.forbidInsertion();
		field_11863.method_20290(1042, field_11867, 0);
		if (resultItem.method_7960()) {
			// The input was fully consumed (e.g. an experience nugget/block) - nothing to export.
			heldItem = null;
		} else {
			resultItem.method_7939(heldItem.stack.method_7947());
			heldItem.stack = resultItem;
		}
		notifyUpdate();
		return true;
	}

	/**
	 * Pull experience from the player(s) standing on top of the block, and from any
	 * experience orbs in the space above it, converting it into stored Liquid Experience.
	 * Faithful to the original CEI behaviour, using the simpler Create Fly fluid insert API
	 * and the 1.21.11 ExperienceOrb getValue/setValue accessors.
	 */
	protected void absorbExperienceFromWorld(class_3218 serverLevel) {
		ExperienceFluid expFluid = (ExperienceFluid) plus.dragons.createenchantmentindustry.registry.CeiFluids.EXPERIENCE.still;

		// --- Players standing on top ---
		List<class_1657> players = serverLevel.method_8390(class_1657.class, absorbArea, class_1309::method_5805);
		if (!players.isEmpty()) {
			int sum = 0;
			for (class_1657 player : players) {
				int xp = getPlayerExperience(player);
				if (xp >= 100) {
					sum += 100;
				} else if (xp != 0) {
					sum += xp;
				}
			}
			if (sum != 0) {
				FluidStack fluidStack = new FluidStack(expFluid, sum * plus.dragons.createenchantmentindustry.EnchantmentIndustry.UNIT_PER_MB);
				internalTank.allowInsertion();
				int insertedUnits = internalTank.getPrimaryHandler().insert(fluidStack);
				internalTank.forbidInsertion();
				int inserted = insertedUnits / plus.dragons.createenchantmentindustry.EnchantmentIndustry.UNIT_PER_MB;
				if (inserted != 0) {
					for (class_1657 player : players) {
						if (inserted <= 0) {
							break;
						}
						int total = getPlayerExperience(player);
						int take = Math.min(total, Math.min(inserted, 100));
						if (take > 0) {
							player.method_7255(-take);
							inserted -= take;
						}
					}
				}
			}
		}

		// --- Loose experience orbs above the block ---
		List<class_1303> orbs = serverLevel.method_18467(class_1303.class, absorbArea);
		for (class_1303 orb : orbs) {
			int amount = orb.method_5919();
			if (amount <= 0) {
				continue;
			}
			FluidStack fluidStack = new FluidStack(expFluid, amount * plus.dragons.createenchantmentindustry.EnchantmentIndustry.UNIT_PER_MB);
			internalTank.allowInsertion();
			int insertedUnits = internalTank.getPrimaryHandler().insert(fluidStack);
			internalTank.forbidInsertion();
			int inserted = insertedUnits / plus.dragons.createenchantmentindustry.EnchantmentIndustry.UNIT_PER_MB;
			if (inserted >= amount) {
				orb.method_31472();
			} else if (inserted > 0) {
				// Partially absorbed: replace the orb with one holding the remaining value
				// (avoids ExperienceOrb.setValue, which is private).
				double ox = orb.method_23317();
				double oy = orb.method_23318();
				double oz = orb.method_23321();
				orb.method_31472();
				serverLevel.method_8649(new class_1303(serverLevel, ox, oy, oz, amount - inserted));
				break; // tank full after this
			} else {
				break; // tank full
			}
		}
	}

	/** Total experience points a player currently holds (levels + progress bar). */
	private int getPlayerExperience(class_1657 player) {
		int level = player.field_7520;
		if (player.field_7520 == 0 && player.field_7510 == 0.0F) {
			return 0;
		}
		int total = plus.dragons.createenchantmentindustry.content.enchanter.Enchanting.expPointFromLevel(level);
		int bar = (int) (total + player.field_7510 * player.method_7349());
		return Math.max(bar, 1);
	}

		private float itemMovementPerTick() {
		return 0.125F;
	}

	public SmartFluidTankBehaviour getInternalTank() {
		return internalTank;
	}

	public void setHeldItem(TransportedItemStack heldItem, class_2350 insertedFrom) {
		this.heldItem = heldItem;
		this.heldItem.insertedFrom = insertedFrom;
	}

	@Override
	public void write(class_11372 view, boolean clientPacket) {
		view.method_71465("ProcessingTicks", processingTicks);
		if (heldItem != null) {
			view.method_71468("HeldItem", TransportedItemStack.CODEC, heldItem);
		}
		super.write(view, clientPacket);
	}

	@Override
	protected void read(class_11368 view, boolean clientPacket) {
		heldItem = null;
		processingTicks = view.method_71424("ProcessingTicks", 0);
		heldItem = view.method_71426("HeldItem", TransportedItemStack.CODEC).orElse(null);
		super.read(view, clientPacket);
	}
}
