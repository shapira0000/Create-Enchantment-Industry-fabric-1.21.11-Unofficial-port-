package plus.dragons.createenchantmentindustry.content.enchanter;

import com.zurrtum.create.AllBlocks;
import plus.dragons.createenchantmentindustry.registry.CeiBlocks;
import com.zurrtum.create.foundation.gui.menu.MenuProvider;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_9129;
import net.minecraft.class_9334;
import com.zurrtum.create.foundation.gui.menu.MenuBase;


/**
 * The Enchanting Guide. Stage 1 (no GUI yet): right-click an enchanted book in your hand to
 * "load" it into the guide (stored in the {@link class_9334#field_49643} component
 * of the guide itself), then set the guide as the Blaze Enchanter's target via right-click.
 * A later stage adds the screen to pick a specific enchantment + index.
 *
 * <p>Because the guide stores its enchantment in the standard STORED_ENCHANTMENTS component,
 * {@link Enchanting#getTargetEnchantment(class_1799)} reads it the same way it reads a plain book.</p>
 */
public class EnchantingGuideItem extends class_1792 implements MenuProvider {

	public EnchantingGuideItem(class_1793 properties) {
		super(properties);
	}

	/** Returns the enchantment currently stored in this guide (or invalid if none). */

	/**
	 * Store the chosen book + index on a guide. The enchantment itself is resolved later from the
	 * stored book (see {@link Enchanting#getTargetEnchantment}), so it can never drift out of sync.
	 * If the book carries no enchantment, the guide is cleared back to blank.
	 */
	public static void store(class_1799 guide, class_1799 book, int index) {
		java.util.List<net.minecraft.class_6880<net.minecraft.class_1887>> holders =
			Enchanting.enchantmentsOf(book);
		if (book.method_7960() || holders.isEmpty()) {
			guide.method_57381(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.TARGET);
			guide.method_57381(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.INDEX);
			return;
		}
		int clamped = Math.max(0, Math.min(index, holders.size() - 1));
		class_1799 stored = book.method_7972();
		stored.method_7939(1);
		guide.method_57379(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.TARGET, stored);
		guide.method_57379(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.INDEX, clamped);
	}

	public static EnchantmentEntry getEnchantment(class_1799 guide) {
		return Enchanting.getTargetEnchantment(guide);
	}

	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1937 level = context.method_8045();
		class_2338 pos = context.method_8037();
		class_2680 clicked = level.method_8320(pos);
		class_1799 guide = context.method_8041();

		// Shift + right-click a Blaze Burner that HAS a blaze (lit, or actively burning) with a
		// loaded guide -> convert it to a Blaze Enchanter. An empty burner is ignored.
		boolean litBurner = clicked.method_26204() == AllBlocks.LIT_BLAZE_BURNER;
		boolean burningBurner = clicked.method_26204() == AllBlocks.BLAZE_BURNER
			&& clicked.method_28498(com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HEAT_LEVEL)
			&& clicked.method_11654(com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HEAT_LEVEL)
				!= com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HeatLevel.NONE;
		if (litBurner || burningBurner) {
			if (context.method_8036() != null && !context.method_8036().method_5715()) {
				return class_1269.field_5811;
			}
			if (!getEnchantment(guide).valid()) {
				return class_1269.field_5811; // guide must carry an enchantment first
			}
			if (!level.method_8608()) {
				// The lit burner has no facing; face the enchanter toward the player.
				class_2350 facing = context.method_8036() != null
					? context.method_8036().method_5735().method_10153()
					: class_2350.field_11035;
				class_2680 enchanter = CeiBlocks.BLAZE_ENCHANTER.method_9564()
					.method_11657(plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlock.field_11177, facing);
				level.method_8501(pos, enchanter);
				class_2586 be = level.method_8321(pos);
				if (be instanceof BlazeEnchanterBlockEntity bee) {
					class_1799 stored = guide.method_7972();
					stored.method_7939(1);
					bee.setTargetItem(stored);
					bee.notifyUpdate();
				}
				guide.method_7934(1);
			}
			return class_1269.field_5812;
		}
		return class_1269.field_5811;
	}

	@Override
	public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
		// Plain right-click (no shift) in the main hand opens the Enchanting Guide screen, where
		// the player drops in an enchanted book and picks the enchantment to apply.
		if (!player.method_5715() && hand == class_1268.field_5808) {
			if (!level.method_8608() && player instanceof class_3222 serverPlayer) {
				openHandledScreen(serverPlayer);
			}
			return class_1269.field_5812;
		}
		return class_1269.field_5811;
	}

	@Override
	public MenuBase<?> createMenu(int id, class_1661 inv, class_1657 player, class_9129 extraData) {
		class_1799 held = player.method_6047();
		class_1799.field_48349.encode(extraData, held);
		extraData.method_52964(false);
		return new EnchantingGuideMenu(id, inv, held);
	}

	@Override
	public boolean method_7886(class_1799 stack) {
		return getEnchantment(stack).valid();
	}

	@Override
	public void method_67187(
		class_1799 stack,
		net.minecraft.class_1792.class_9635 context,
		net.minecraft.class_10712 tooltipDisplay,
		java.util.function.Consumer<class_2561> tooltip,
		net.minecraft.class_1836 flag
	) {
		super.method_67187(stack, context, tooltipDisplay, tooltip, flag);
		EnchantmentEntry entry = getEnchantment(stack);
		if (entry.valid()) {
			// Show the currently selected enchantment (name + level), resolved from the stored book.
			tooltip.accept(class_2561.method_43471("create_enchantment_industry.gui.enchanting_guide.selected")
				.method_27692(net.minecraft.class_124.field_1080));
			tooltip.accept(class_2561.method_43470(" ")
				.method_10852(class_1887.method_8179(entry.enchantment(), entry.level())));
		} else {
			tooltip.accept(class_2561.method_43471("create_enchantment_industry.gui.enchanting_guide.empty")
				.method_27692(net.minecraft.class_124.field_1063));
		}
	}
}
