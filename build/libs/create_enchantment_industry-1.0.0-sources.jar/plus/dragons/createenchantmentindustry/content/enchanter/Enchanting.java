package plus.dragons.createenchantmentindustry.content.enchanter;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.registry.CeiDataComponents;

/**
 * Enchanting logic for the Blaze Enchanter, the mirror of {@code Disenchanting}.
 *
 * <p>Faithful to the original CEI but rewritten for the 1.21.11 enchantment API (enchantments are
 * {@code Holder<Enchantment>} stored in the {@link class_9334#field_49633} /
 * {@link class_9334#field_49643} components as {@link class_9304}).</p>
 *
 * <p>The target enchantment is taken from a "guide" — for now a plain enchanted book works as the
 * guide (its first enchantment is used), so the feature is testable before the dedicated
 * Enchanting Guide item + GUI is added.</p>
 */
public class Enchanting {

	// ---- XP / level math (unchanged, mirrors vanilla's curve) ----

	public static int expPointFromLevel(int level) {
		if (level > 31) {
			return (int) (4.5 * level * level - 162.5 * level + 2220.0);
		} else if (level > 16) {
			return (int) (2.5 * level * level - 40.5 * level + 360.0);
		} else {
			return level * level + 6 * level;
		}
	}

	public static int expPointForNextLevel(int level) {
		if (level > 30) {
			return 9 * level - 158;
		} else if (level > 15) {
			return 5 * level - 38;
		} else {
			return 2 * level + 7;
		}
	}

	// ---- Guide reading ----

	/**
	 * Reads the desired enchantment from the guide stack. For now the "guide" is simply an
	 * enchanted book (or any item carrying stored enchantments); its first stored enchantment
	 * is used. Returns an invalid entry if the guide carries no enchantment.
	 */
	public static EnchantmentEntry getTargetEnchantment(class_1799 guide) {
		// Preferred path: a loaded Enchanting Guide stores the WHOLE book it was made from
		// (TARGET) plus the chosen INDEX. We resolve the enchantment by indexing into that
		// stored book's own enchantment list - one ItemStack, one ordering, always consistent.
		if (guide.method_57826(CeiDataComponents.TARGET)) {
			class_1799 book = guide.method_58694(CeiDataComponents.TARGET);
			int index = guide.method_58695(CeiDataComponents.INDEX, 0);
			return selectFromBook(book, index);
		}
		// Fallback: a plain enchanted book used directly as a guide -> first stored enchantment.
		return selectFromBook(guide, 0);
	}

	/**
	 * The enchantments of {@code book} that have a positive level, in the book's own iteration
	 * order. Because this is always derived from a single ItemStack, the order is stable for the
	 * caller (the same list the player saw in the GUI when the guide was made from this book).
	 */
	public static List<class_6880<class_1887>> enchantmentsOf(class_1799 book) {
		class_9304 stored = book.method_58695(class_9334.field_49643, class_9304.field_49385);
		if (stored.method_57543()) {
			stored = book.method_58695(class_9334.field_49633, class_9304.field_49385);
		}
		List<class_6880<class_1887>> holders = new ArrayList<>();
		for (class_6880<class_1887> holder : stored.method_57534()) {
			if (stored.method_57536(holder) > 0) {
				holders.add(holder);
			}
		}
		return holders;
	}

	/** The level {@code book} stores for {@code holder} (0 if none). */
	public static int levelOf(class_1799 book, class_6880<class_1887> holder) {
		class_9304 stored = book.method_58695(class_9334.field_49643, class_9304.field_49385);
		if (stored.method_57543()) {
			stored = book.method_58695(class_9334.field_49633, class_9304.field_49385);
		}
		return stored.method_57536(holder);
	}

	/** The {@code index}-th enchantment of {@code book} (clamped), as an entry; invalid if none. */
	public static EnchantmentEntry selectFromBook(class_1799 book, int index) {
		if (book.method_7960()) {
			return EnchantmentEntry.invalid();
		}
		List<class_6880<class_1887>> holders = enchantmentsOf(book);
		if (holders.isEmpty()) {
			return EnchantmentEntry.invalid();
		}
		int pick = Math.max(0, Math.min(index, holders.size() - 1));
		class_6880<class_1887> chosen = holders.get(pick);
		return EnchantmentEntry.of(chosen, levelOf(book, chosen));
	}

	// ---- Validation ----

	/**
	 * Returns the enchantment that can validly be applied from {@code guide} onto {@code target},
	 * or an invalid entry if none. Checks: the guide carries an enchantment, the target supports
	 * it (or is a book), the target doesn't already have it at >= the same level, and the
	 * enchantment is compatible with the target's existing enchantments.
	 */
	public static EnchantmentEntry getValidEnchantment(class_1799 target, class_1799 guide, boolean hyper) {
		EnchantmentEntry entry = getTargetEnchantment(guide);
		if (!entry.valid()) {
			return EnchantmentEntry.invalid();
		}
		class_6880<class_1887> enchantment = entry.enchantment();

		boolean isBook = target.method_31574(class_1802.field_8529) || target.method_31574(class_1802.field_8598);
		// The enchantment must be applicable to the ITEM TYPE (books accept anything). This is the
		// only "fits the item" rule we keep: Protection can go on armor, Sharpness cannot.
		if (!isBook && !enchantment.comp_349().method_60046(target)) {
			return EnchantmentEntry.invalid();
		}

		class_9304 current = target.method_57826(class_9334.field_49643)
			? target.method_58695(class_9334.field_49643, class_9304.field_49385)
			: target.method_58695(class_9334.field_49633, class_9304.field_49385);

		// Already has this exact enchantment at >= the target level -> nothing to do.
		int existing = current.method_57536(enchantment);
		if (existing >= entry.level()) {
			return EnchantmentEntry.invalid();
		}

		// NOTE: we deliberately do NOT enforce vanilla's mutual-exclusivity between enchantments.
		// The Blaze Enchanter is allowed to stack normally-incompatible enchantments (e.g. adding
		// Fire Protection to armor that already has Protection), as long as the item type supports
		// the enchantment. Only the item-type support and the upgrade-only checks above apply.
		return entry;
	}

	// ---- Application ----

	/** Applies the entry's enchantment to the item, writing back to the correct component. */
	public static void enchantItem(class_1799 target, EnchantmentEntry entry) {
		boolean isStored = target.method_31574(class_1802.field_8598) || target.method_57826(class_9334.field_49643);
		class_9304 current = isStored
			? target.method_58695(class_9334.field_49643, class_9304.field_49385)
			: target.method_58695(class_9334.field_49633, class_9304.field_49385);

		class_9304.class_9305 builder = new class_9304.class_9305(current);
		builder.method_57547(entry.enchantment(), entry.level());
		class_9304 result = builder.method_57549();

		if (isStored) {
			target.method_57379(class_9334.field_49643, result);
		} else {
			target.method_57379(class_9334.field_49633, result);
		}
	}

	// ---- Cost ----

	/**
	 * Experience consumption (in fluid units) to apply the given enchantment at the given level.
	 * Mirrors the original: based on the enchantment's minimum cost at that level, scaled by the
	 * unit-per-mB ratio. A minimum of 1 mB is always charged.
	 */
	/**
	 * The Liquid-Experience cost (in units) to apply {@code enchantment} at {@code level}, faithful
	 * to the original CEI: {@code expPointForNextLevel(minCost + rarityLevel * level)} experience
	 * points, converted to fluid units. Because it uses each enchantment's own minimum cost and its
	 * rarity, every enchantment costs a different amount (rarer / higher-level = more).
	 */
	public static int getExperienceConsumption(class_6880<class_1887> enchantment, int level) {
		int minCost = enchantment.comp_349().method_8182(level);
		int points = expPointForNextLevel(minCost + rarityLevel(enchantment) * level);
		return Math.max(1, points) * EnchantmentIndustry.UNIT_PER_MB;
	}

	/**
	 * A 1..4 "rarity weight" for an enchantment, replacing the pre-1.21 Rarity enum (removed in
	 * 1.21+). Derived from the enchantment's selection weight: common enchantments (high weight)
	 * cost more per level, very rare ones (low weight) cost less - matching the original mapping
	 * COMMON=4, UNCOMMON=3, RARE=2, VERY_RARE=1.
	 */
	public static int rarityLevel(class_6880<class_1887> enchantment) {
		int weight = enchantment.comp_349().method_58445();
		if (weight >= 10) return 4; // COMMON  (e.g. Protection, Sharpness, Efficiency)
		if (weight >= 5)  return 3; // UNCOMMON
		if (weight >= 2)  return 2; // RARE
		return 1;                   // VERY_RARE (e.g. Silk Touch, Thorns, Mending-tier)
	}
}
