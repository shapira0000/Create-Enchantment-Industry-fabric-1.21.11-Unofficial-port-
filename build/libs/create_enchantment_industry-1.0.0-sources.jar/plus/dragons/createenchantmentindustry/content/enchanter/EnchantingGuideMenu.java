package plus.dragons.createenchantmentindustry.content.enchanter;

import com.google.common.collect.ImmutableList;
import com.zurrtum.create.foundation.gui.menu.GhostItemMenu;
import com.zurrtum.create.foundation.gui.menu.MenuType;
import com.zurrtum.create.infrastructure.items.ItemStackHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2561;
import net.minecraft.class_6880;
import plus.dragons.createenchantmentindustry.registry.CeiMenuTypes;

/**
 * Container menu for the Enchanting Guide. Holds a single ghost slot for an enchanted book; when a
 * book is present, the book's enchantments are read into {@link #enchantments} and the player picks
 * one by {@code index}. The chosen enchantment is written back onto the guide on close/save.
 *
 * <p>Mirrors the original CEI {@code EnchantingGuideMenu}, adapted to Create Fly's
 * {@link GhostItemMenu} and the 1.21.11 enchantment-component API.</p>
 */
public class EnchantingGuideMenu extends GhostItemMenu<class_1799> {

	public static final class_2561 NO_ENCHANTMENT =
		class_2561.method_43471("create_enchantment_industry.gui.enchanting_guide.no_enchantment");

	public ImmutableList<class_2561> previousEnchantments;
	public ImmutableList<class_2561> enchantments;
	public int index;
	// When opened from a placed Blaze Enchanter, the block's position (else null = held guide).
	public net.minecraft.class_2338 blockPos;

	public EnchantingGuideMenu(int id, class_1661 inv, class_1799 guide) {
		super(CeiMenuTypes.ENCHANTING_GUIDE, id, inv, guide);
	}

	@Override
	protected ItemStackHandler createGhostInventory() {
		return new ItemStackHandler(1);
	}

	@Override
	protected boolean allowRepeats() {
		return false;
	}

	@Override
	protected void initAndReadInventory(class_1799 contentHolder) {
		super.initAndReadInventory(contentHolder);
		// If the guide was already loaded, it stores the WHOLE book it was made from (TARGET) plus
		// the chosen INDEX. Put that exact book back in the ghost slot and restore the selection,
		// so reopening shows precisely what was picked - same ItemStack, same ordering.
		if (contentHolder.method_57826(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.TARGET)) {
			class_1799 book = contentHolder.method_58694(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.TARGET).method_7972();
			ghostInventory.method_5447(0, book);
			index = contentHolder.method_58695(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.INDEX, 0);
		}
		updateEnchantments(ghostInventory.method_5438(0));
	}

	/** The enchanted book currently in the ghost slot (client + server). */
	public class_1799 getGhostBook() {
		return ghostInventory.method_5438(0);
	}

	public void setIndex(int index) {
		this.index = index;
	}

	/** Reads every enchantment on the held book into the display list (names with level). */


	public void updateEnchantments(class_1799 book) {
		previousEnchantments = enchantments;
		ImmutableList.Builder<class_2561> builder = ImmutableList.builder();
		for (class_6880<class_1887> holder : Enchanting.enchantmentsOf(book)) {
			builder.add(class_1887.method_8179(holder, Enchanting.levelOf(book, holder)));
		}
		ImmutableList<class_2561> list = builder.build();
		enchantments = list.isEmpty() ? ImmutableList.of(NO_ENCHANTMENT) : list;
	}

	@Override
	protected void addSlots() {
		addPlayerSlots(8, 72);
		method_7621(new EnchantedBookSlot(ghostInventory, 0, 16, 22));
	}

	@Override
	protected void saveData(class_1799 guide) {
		// Intentionally empty: the chosen enchantment is committed by EnchantingGuideEditPacket,
		// which the screen sends once on close (carrying the index AND the ghost book). Writing
		// anything here would race with that packet using a stale index, so we do nothing.
	}

	@Override
	public boolean method_7597(class_1657 player) {
		return true;
	}

	@Override
	public void method_7593(int slotId, int dragType, class_1713 clickType, class_1657 player) {
		super.method_7593(slotId, dragType, clickType, player);
		// Re-read enchantments after ANY slot interaction (the ghost book may have changed).
		updateEnchantments(ghostInventory.method_5438(0));
	}

	@Override
	public class_1799 method_7601(class_1657 player, int index) {
		class_1799 result = super.method_7601(player, index);
		// Shift-click goes through here (not clicked), so refresh the list too.
		updateEnchantments(ghostInventory.method_5438(0));
		return result;
	}

	/** A ghost slot that only accepts enchanted books. */
	public static class EnchantedBookSlot extends class_1735 {
		public EnchantedBookSlot(net.minecraft.class_1263 container, int index, int x, int y) {
			super(container, index, x, y);
		}

		@Override
		public boolean method_7680(class_1799 stack) {
			return stack.method_31574(net.minecraft.class_1802.field_8598);
		}

		@Override
		public int method_7675() {
			return 1;
		}
	}
}
