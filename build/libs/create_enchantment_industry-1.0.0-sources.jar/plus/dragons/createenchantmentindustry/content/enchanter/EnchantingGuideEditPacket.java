package plus.dragons.createenchantmentindustry.content.enchanter;

import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;

/**
 * Client -> server, sent once when the Enchanting Guide screen closes. Carries the chosen
 * enchantment {@code index}, the book that was in the ghost slot, and (optionally) the position
 * of a Blaze Enchanter if the screen was opened from a placed block (else null = held guide).
 *
 * <p>This mirrors the original CEI design: the choice is committed on close in a single packet
 * that includes the book itself, so the server doesn't depend on ghost-inventory syncing.</p>
 */
public record EnchantingGuideEditPacket(int index, class_1799 book, class_2338 blockPos) implements class_8710 {

	public static final class_9154<EnchantingGuideEditPacket> TYPE =
		new class_9154<>(EnchantmentIndustry.genRL("enchanting_guide_edit"));

	public static final class_9139<class_9129, EnchantingGuideEditPacket> STREAM_CODEC =
		class_9139.method_56436(
			class_9135.field_48550, EnchantingGuideEditPacket::index,
			class_1799.field_49268, EnchantingGuideEditPacket::book,
			class_9135.method_56382(class_2338.field_48404).method_56432(
				opt -> opt.orElse(null),
				pos -> java.util.Optional.ofNullable(pos)
			), EnchantingGuideEditPacket::blockPos,
			EnchantingGuideEditPacket::new
		);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TYPE;
	}
}
