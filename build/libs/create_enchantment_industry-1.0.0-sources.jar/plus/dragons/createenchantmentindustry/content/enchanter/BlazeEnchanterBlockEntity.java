package plus.dragons.createenchantmentindustry.content.enchanter;

import com.zurrtum.create.api.behaviour.BlockEntityBehaviour;
import com.zurrtum.create.catnip.animation.LerpedFloat;
import com.zurrtum.create.catnip.math.AngleHelper;
import com.zurrtum.create.catnip.data.Iterate;
import com.zurrtum.create.catnip.math.VecHelper;
import com.zurrtum.create.content.kinetics.belt.behaviour.DirectBeltInputBehaviour;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.foundation.blockEntity.SmartBlockEntity;
import com.zurrtum.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.zurrtum.create.foundation.utility.BlockHelper;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1264;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.class_746;
import net.minecraft.class_9129;
import plus.dragons.createenchantmentindustry.registry.CeiConfig;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;
import com.zurrtum.create.foundation.gui.menu.MenuProvider;
import com.zurrtum.create.foundation.gui.menu.MenuBase;


/**
 * The Blaze Enchanter's block entity.
 *
 * <p>Stage 1: mirrors the Disenchanter's proven belt-processing + tank structure. Where the
 * Disenchanter strips enchantments into fluid, the Blaze Enchanter will consume Liquid Experience
 * to ADD an enchantment (driven by an Enchanting Guide). Stage 1 wires the item transport, tank,
 * and processing skeleton; the actual enchant application and GUI come in later stages.</p>
 */
public class BlazeEnchanterBlockEntity extends SmartBlockEntity implements MenuProvider {
	public static final int ENCHANTING_TIME = 200;
	private static final int ENCHANT_PARTICLE_COUNT = 10;

	public SmartFluidTankBehaviour internalTank;
	public TransportedItemStack heldItem;
	public class_1799 targetItem = class_1799.field_8037;
	public int processingTicks;
	/** True when an item is parked at the centre because there isn't enough experience yet. */
	public boolean waitingForXp;
	public Map<class_2350, BlazeEnchanterItemHandler> itemHandlers = new IdentityHashMap<>();
	// Animations for the rendered blaze head (mirrors the Blaze Burner).
	public LerpedFloat headAngle = LerpedFloat.angular();
	public LerpedFloat headAnimation = LerpedFloat.linear();

	public BlazeEnchanterBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		for (class_2350 d : Iterate.horizontalDirections) {
			itemHandlers.put(d, new BlazeEnchanterItemHandler(this, d));
		}
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour<?>> behaviours) {
		behaviours.add(new DirectBeltInputBehaviour(this).allowingBeltFunnels().setInsertionHandler(this::tryInsertingFromSide));
		int capacity = CeiConfig.blazeEnchanterTankCapacityUnits();
		// Only Liquid/Hyper Experience can be inserted (we forbid generic insertion and only
		// allow it ourselves during processing checks - same approach as the Disenchanter).
		behaviours.add(this.internalTank = SmartFluidTankBehaviour.single(this, capacity).forbidExtraction());
	}

	/** True if the tank currently holds Hyper Experience (enables hyper-enchanting later). */
	public boolean hyper() {
		FluidStack fluid = internalTank.getPrimaryHandler().getFluid();
		return fluid.getFluid() == CeiFluids.HYPER_EXPERIENCE.still;
	}

	public void setTargetItem(class_1799 stack) {
		this.targetItem = stack;
	}

	/** Opens the Enchanting Guide screen to edit the guide stored in this enchanter. */
	public void openGuideScreen(class_3222 player) {
		MenuProvider.openHandledScreen(player, this);
	}

	@Override
	public MenuBase<?> createMenu(int id, class_1661 inv, class_1657 player, class_9129 extraData) {
		class_1799 guide = targetItem.method_7972();
		class_1799.field_48349.encode(extraData, guide);
		extraData.method_52964(true);
		extraData.method_10807(field_11867);
		EnchantingGuideMenu menu = new EnchantingGuideMenu(id, inv, guide);
		menu.blockPos = field_11867;
		return menu;
	}

	private class_1799 tryInsertingFromSide(TransportedItemStack transportedStack, class_2350 side, boolean simulate) {
		class_1799 inserted = transportedStack.stack;
		class_1799 returned = class_1799.field_8037;
		if (!getHeldItemStack().method_7960()) {
			return inserted;
		}
		// Stage 1: accept any item onto the belt; the enchant check happens mid-belt in
		// continueProcessing once the enchant logic is added.
		if (inserted.method_7947() > 1) {
			returned = inserted.method_46651(inserted.method_7947() - 1);
			inserted = inserted.method_46651(1);
		}
		if (simulate) {
			return returned;
		}
		transportedStack = transportedStack.copy();
		transportedStack.stack = inserted.method_7972();
		transportedStack.beltPosition = side.method_10166().method_10178() ? 0.5F : 0.0F;
		transportedStack.prevSideOffset = transportedStack.sideOffset;
		transportedStack.prevBeltPosition = transportedStack.beltPosition;
		setHeldItem(transportedStack, side);
		method_5431();
		sendData();
		return returned;
	}

	public class_1799 getHeldItemStack() {
		return heldItem == null ? class_1799.field_8037 : heldItem.stack;
	}


	@Override
	public void tick() {
		super.tick();
		if (field_11863 != null && field_11863.method_8608()) {
			tickAnimation();
		}
		if (heldItem == null) {
			processingTicks = 0;
			waitingForXp = false;
			return;
		}
		boolean onClient = field_11863.method_8608() && !isVirtual();

		// PARKED, waiting for experience: the item sits at the centre and spins in place forever
		// until enough experience is available, at which point we kick off the enchant animation.
		if (waitingForXp) {
			heldItem.prevBeltPosition = 0.5F;
			heldItem.beltPosition = 0.5F;
			if (!onClient) {
				EnchantmentEntry entry = targetItem.method_7960()
					? EnchantmentEntry.invalid()
					: Enchanting.getValidEnchantment(heldItem.stack, targetItem, hyper());
				if (!entry.valid()) {
					// Guide changed / item no longer valid: stop waiting and let it move on out.
					waitingForXp = false;
					notifyUpdate();
					return;
				}
				int cost = Enchanting.getExperienceConsumption(entry.enchantment(), entry.level());
				if (internalTank.getPrimaryHandler().getFluid().getAmount() >= cost) {
					// Enough experience now - begin the enchant animation.
					waitingForXp = false;
					processingTicks = ENCHANTING_TIME;
					notifyUpdate();
				}
			}
			return;
		}

		if (processingTicks > 0) {
			heldItem.prevBeltPosition = 0.5F;
			boolean wasAtBeginning = processingTicks == ENCHANTING_TIME;
			if (!onClient || processingTicks < ENCHANTING_TIME) {
				processingTicks--;
			}
			if (!continueProcessing()) {
				processingTicks = 0;
				notifyUpdate();
			} else if (wasAtBeginning != (processingTicks == ENCHANTING_TIME)) {
				sendData();
			}
			return;
		}

		heldItem.prevBeltPosition = heldItem.beltPosition;
		heldItem.prevSideOffset = heldItem.sideOffset;
		heldItem.beltPosition += itemMovementPerTick();

		if (heldItem.beltPosition > 1.0F) {
			heldItem.beltPosition = 1.0F;
			if (!onClient) {
				exportItem();
			}
		} else if (heldItem.prevBeltPosition < 0.5F && heldItem.beltPosition >= 0.5F) {
			// At the mid-point: only stop here if there's a valid enchantment for this item. If
			// not (no guide, wrong item type, already has it) we DON'T stop - the item keeps moving
			// and is exported out the far side, a passthrough.
			if (onClient) {
				return;
			}
			EnchantmentEntry entry = targetItem.method_7960()
				? EnchantmentEntry.invalid()
				: Enchanting.getValidEnchantment(heldItem.stack, targetItem, hyper());
			if (!entry.valid()) {
				return; // let it slide on to the export side untouched
			}
			heldItem.beltPosition = 0.5F;
			// Check experience up front: if we have enough, run the enchant animation now;
			// otherwise PARK and wait (spinning in place) until experience is supplied.
			int cost = Enchanting.getExperienceConsumption(entry.enchantment(), entry.level());
			if (internalTank.getPrimaryHandler().getFluid().getAmount() >= cost) {
				processingTicks = ENCHANTING_TIME;
			} else {
				waitingForXp = true;
			}
			sendData();
		}
	}

	private void exportItem() {
		class_2350 side = heldItem.insertedFrom;
		class_1799 tryExport = getBehaviour(DirectBeltInputBehaviour.TYPE)
			.tryExportingToBeltFunnel(heldItem.stack, side.method_10153(), false);
		if (tryExport != null) {
			if (tryExport.method_7947() != heldItem.stack.method_7947()) {
				if (tryExport.method_7960()) {
					heldItem = null;
				} else {
					heldItem.stack = tryExport;
				}
				notifyUpdate();
				return;
			}
			if (!tryExport.method_7960()) {
				return;
			}
		}

		class_2338 nextPosition = field_11867.method_10093(side);
		DirectBeltInputBehaviour next = BlockEntityBehaviour.get(field_11863, nextPosition, DirectBeltInputBehaviour.TYPE);
		if (next == null) {
			if (!BlockHelper.hasBlockSolidSide(field_11863.method_8320(nextPosition), field_11863, nextPosition, side.method_10153())) {
				class_1799 ejected = heldItem.stack;
				class_243 outPos = VecHelper.getCenterOf(field_11867).method_1019(class_243.method_24954(side.method_62675()).method_1021(0.75));
				float speed = itemMovementPerTick();
				class_243 outMotion = class_243.method_24954(side.method_62675()).method_1021(speed).method_1031(0.0, 0.125, 0.0);
				outPos.method_1019(outMotion.method_1029());
				class_1542 entity = new class_1542(field_11863, outPos.field_1352, outPos.field_1351 + 0.375, outPos.field_1350, ejected);
				entity.method_18799(outMotion);
				entity.method_6988();
				field_11863.method_8649(entity);
				heldItem = null;
				waitingForXp = false;
				notifyUpdate();
			}
		} else if (next.canInsertFromSide(side)) {
			class_1799 returned = next.handleInsertion(heldItem.copy(), side, false);
			if (returned.method_7960()) {
				heldItem = null;
				waitingForXp = false;
				notifyUpdate();
			} else if (returned.method_7947() != heldItem.stack.method_7947()) {
				heldItem.stack = returned;
				notifyUpdate();
			}
		}
	}

	/**
	 * Performs the enchant mid-belt: reads the desired enchantment from {@link #targetItem} (the
	 * guide / enchanted book), validates it against the held item, drains the required Liquid
	 * Experience, and writes the enchantment onto the item.
	 */
	protected boolean continueProcessing() {
		if (field_11863.method_8608() && !isVirtual()) {
			return true;
		}
		if (processingTicks < 5) {
			return true;
		}
		if (heldItem == null || heldItem.stack.method_7960()) {
			return false;
		}
		if (targetItem.method_7960()) {
			return false; // no guide set - nothing to apply
		}

		EnchantmentEntry entry = Enchanting.getValidEnchantment(heldItem.stack, targetItem, hyper());
		if (!entry.valid()) {
			return false;
		}

		if (processingTicks > 5) {
			// Still animating; nothing to commit yet.
			return true;
		}

		// processingTicks == 5: commit. Experience was already verified before the animation
		// started (the item parks and waits if it's short), but re-check defensively in case the
		// tank was drained meanwhile - if so, fall back to waiting rather than enchanting for free.
		int cost = Enchanting.getExperienceConsumption(entry.enchantment(), entry.level());
		FluidStack stored = internalTank.getPrimaryHandler().getFluid();
		if (stored.getAmount() < cost) {
			processingTicks = 0;
			waitingForXp = true;
			notifyUpdate();
			return true;
		}

		class_1799 single = heldItem.stack.method_46651(1);
		Enchanting.enchantItem(single, entry);
		single.method_7939(heldItem.stack.method_7947());
		heldItem.stack = single;

		// Drain the cost from the tank by writing back a reduced fluid stack.
		FluidStack remaining = stored.copyWithAmount(stored.getAmount() - cost);
		internalTank.getPrimaryHandler().setFluid(remaining);
		playEnchantSound();
		spawnEnchantParticles();
		notifyUpdate();
		return true;
	}


	/** The enchanting-table chime, played periodically while an item is being enchanted. */
	private void playEnchantSound() {
		if (field_11863 == null) {
			return;
		}
		field_11863.method_8396(null, field_11867, net.minecraft.class_3417.field_15119,
			net.minecraft.class_3419.field_15245, 1.0F, field_11863.method_8409().method_43057() * 0.1F + 0.9F);
	}

	/** The burst of enchant glyph particles, emitted when the enchant is committed. */
	private void spawnEnchantParticles() {
		if (field_11863 instanceof net.minecraft.class_3218 serverLevel) {
			net.minecraft.class_243 c = VecHelper.getCenterOf(field_11867).method_1031(0.0, 1.1, 0.0);
			serverLevel.method_65096(net.minecraft.class_2398.field_11215,
				c.field_1352, c.field_1351, c.field_1350, ENCHANT_PARTICLE_COUNT, 0.4, 0.4, 0.4, 0.2);
		}
	}

	private void tickAnimation() {
		boolean active = !internalTank.getPrimaryHandler().getFluid().isEmpty();

		// Make the blaze head look toward the player when idle, exactly like the Blaze Burner.
		float target = 0.0F;
		class_746 player = class_310.method_1551().field_1724;
		if (player != null && !player.method_5767()) {
			double x = player.method_23317();
			double z = player.method_23321();
			double dx = x - (field_11867.method_10263() + 0.5);
			double dz = z - (field_11867.method_10260() + 0.5);
			target = AngleHelper.deg(-class_3532.method_15349(dz, dx)) - 90.0F;
		}
		target = headAngle.getValue() + AngleHelper.getShortestAngleDiff(headAngle.getValue(), target);
		headAngle.chase(target, 0.25, LerpedFloat.Chaser.exp(5.0));
		headAngle.tickChaser();

		headAnimation.chase(active ? 1.0 : 0.0, 0.25, LerpedFloat.Chaser.exp(0.25));
		headAnimation.tickChaser();

		spawnParticles(active);
	}

	/**
	 * Emits the same particles as the Blaze Burner: a wisp of smoke always (like a smouldering
	 * burner) for the cold enchanter, and smoke + flame when heated (like a kindled burner).
	 */
	private void spawnParticles(boolean active) {
		if (field_11863 == null) {
			return;
		}
		// Verbatim copy of the Blaze Burner's spawnParticles (same amount/frequency). Smoke for
		// the cold/smouldering enchanter; smoke + flame when heated.
		class_5819 r = field_11863.method_8409();
		class_243 c = VecHelper.getCenterOf(field_11867);
		class_243 v = c.method_1019(VecHelper.offsetRandomly(class_243.field_1353, r, 0.125F).method_18805(1.0, 0.0, 1.0));
		if (r.method_43048(4) == 0) {
			boolean empty = field_11863.method_8320(field_11867.method_10084())
				.method_26220(field_11863, field_11867.method_10084()).method_1110();
			if (empty || r.method_43048(8) == 0) {
				field_11863.method_8406(class_2398.field_11251, v.field_1352, v.field_1351, v.field_1350, 0.0, 0.0, 0.0);
			}
			double yMotion = empty ? 0.0625 : r.method_43058() * 0.0125F;
			class_243 v2 = c.method_1019(
					VecHelper.offsetRandomly(class_243.field_1353, r, 0.5F)
						.method_18805(1.0, 0.25, 1.0)
						.method_1029()
						.method_1021((empty ? 0.25 : 0.5) + r.method_43058() * 0.125)
				)
				.method_1031(0.0, 0.5, 0.0);
			if (active) {
				field_11863.method_8406(class_2398.field_11240, v2.field_1352, v2.field_1351, v2.field_1350, 0.0, yMotion, 0.0);
			}
		}
	}

	private float itemMovementPerTick() {
		return 0.125F;
	}

	public SmartFluidTankBehaviour getInternalTank() {
		return internalTank;
	}

	public void setHeldItem(TransportedItemStack heldItem, class_2350 insertedFrom) {
		this.heldItem = heldItem;
		this.heldItem.insertedFrom = insertedFrom;
	}

	@Override
	public void destroy() {
		super.destroy();
		class_1799 heldItemStack = getHeldItemStack();
		if (!heldItemStack.method_7960()) {
			class_1264.method_5449(field_11863, field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(), heldItemStack);
		}
		if (!targetItem.method_7960() && field_11863 instanceof class_3218) {
			class_1264.method_5449(field_11863, field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(), targetItem);
		}
	}

	@Override
	public void write(class_11372 view, boolean clientPacket) {
		view.method_71465("ProcessingTicks", processingTicks);
		view.method_71472("WaitingForXp", waitingForXp);
		if (heldItem != null) {
			view.method_71468("HeldItem", TransportedItemStack.CODEC, heldItem);
		}
		if (!targetItem.method_7960()) {
			view.method_71468("TargetItem", class_1799.field_24671, targetItem);
		}
		super.write(view, clientPacket);
	}

	@Override
	protected void read(class_11368 view, boolean clientPacket) {
		processingTicks = view.method_71424("ProcessingTicks", 0);
		waitingForXp = view.method_71433("WaitingForXp", false);
		heldItem = view.method_71426("HeldItem", TransportedItemStack.CODEC).orElse(null);
		targetItem = view.method_71426("TargetItem", class_1799.field_24671).orElse(class_1799.field_8037);
		super.read(view, clientPacket);
	}
}
