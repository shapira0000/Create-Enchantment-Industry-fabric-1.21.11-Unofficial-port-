package plus.dragons.createenchantmentindustry.content.enchanter;

import com.zurrtum.create.AllShapes;
import com.zurrtum.create.content.equipment.wrench.IWrenchable;
import com.zurrtum.create.foundation.block.IBE;
import com.zurrtum.create.foundation.blockEntity.ComparatorUtil;
import com.zurrtum.create.infrastructure.fluids.FluidInventory;
import com.zurrtum.create.infrastructure.fluids.FluidInventoryProvider;
import com.zurrtum.create.infrastructure.items.ItemInventoryProvider;
import net.minecraft.class_10;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import com.mojang.serialization.MapCodec;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.AllBlocks;
import plus.dragons.createenchantmentindustry.registry.CeiBlockEntities;

/**
 * The Blaze Enchanter block. Stage 1: a functional Create-integrated block (belts + fluid pipes)
 * built on the same foundation as the Disenchanter. Heat levels, the floating book renderer, and
 * the Enchanting Guide GUI are layered on in later stages.
 *
 * <p>Kept as a plain {@link class_2248} for now (no directional state) to keep stage 1 simple; the
 * original is a HorizontalDirectionalBlock, which we can switch to when the renderer needs facing.</p>
 */
public class BlazeEnchanterBlock extends class_2383
	implements IWrenchable,
	IBE<BlazeEnchanterBlockEntity>,
	ItemInventoryProvider<BlazeEnchanterBlockEntity>,
	FluidInventoryProvider<BlazeEnchanterBlockEntity> {

	public static final MapCodec<BlazeEnchanterBlock> CODEC = method_54094(BlazeEnchanterBlock::new);

	public BlazeEnchanterBlock(class_2251 properties) {
		super(properties);
		method_9590(method_9564().method_11657(field_11177, class_2350.field_11035));
	}

	@Override
	protected MapCodec<? extends class_2383> method_53969() {
		return field_46280;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(field_11177);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		return method_9564().method_11657(field_11177, context.method_8042().method_10153());
	}

	@Override
	public class_1263 getInventory(class_1936 world, class_2338 pos, class_2680 state, BlazeEnchanterBlockEntity be, class_2350 context) {
		return context != null && context.method_10166().method_10179() ? be.itemHandlers.get(context) : null;
	}

	@Override
	public FluidInventory getFluidInventory(class_1936 world, class_2338 pos, class_2680 state, BlazeEnchanterBlockEntity be, class_2350 context) {
		return be.internalTank.getCapability();
	}

	@Override
	protected class_1269 method_55765(
		class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult
	) {
		if (hand == class_1268.field_5810) {
			return class_1269.field_5811;
		}
		// Shift + right-click with an empty hand opens the guide screen so you can change the
		// enchantment. (Shift + wrench reverts to a Blaze Burner - see onSneakWrenched.)
		if (player.method_5715() && stack.method_7960()) {
			return onBlockEntityUseItemOn(level, pos, be -> {
				if (be.targetItem.method_7960()) {
					return class_1269.field_5811;
				}
				if (!level.method_8608() && player instanceof class_3222 serverPlayer) {
					be.openGuideScreen(serverPlayer);
				}
				return class_1269.field_5812;
			});
		}
		// Plain right-click with an item: insert ONE into the enchanter so it processes with the
		// over-the-block animation (taken from your hand). UNLIKE belt input, a hand-inserted item
		// must actually be enchantable with the current guide - if it can't be enchanted (wrong
		// type, already has it, no guide) we reject the click entirely so it's never taken in and
		// spat back out. (Passthrough only happens for items arriving on a belt.)
		if (!stack.method_7960() && !player.method_5715()) {
			if (hitResult.method_17780() != class_2350.field_11036) {
				return class_1269.field_5811;
			}
			return onBlockEntityUseItemOn(level, pos, be -> {
				if (be.targetItem.method_7960()) {
					return class_1269.field_5811;
				}
				if (!be.getHeldItemStack().method_7960()) {
					return class_1269.field_5811; // already holding something
				}
				// Only take the item if it can actually be enchanted.
				if (!Enchanting.getValidEnchantment(stack, be.targetItem, be.hyper()).valid()) {
					return class_1269.field_5811;
				}
				if (!level.method_8608()) {
					class_1799 insert = stack.method_7972();
					insert.method_7939(1);
					be.heldItem = new TransportedItemStack(insert);
					be.notifyUpdate();
					stack.method_7934(1);
				}
				return class_1269.field_5812;
			});
		}
		// Empty-handed plain right-click: retrieve whatever is currently held/processing.
		if (stack.method_7960() && !player.method_5715()) {
			return onBlockEntityUseItemOn(level, pos, be -> {
				if (be.getHeldItemStack().method_7960()) {
					return class_1269.field_5811;
				}
				if (!level.method_8608()) {
					player.method_6122(hand, be.getHeldItemStack());
					be.heldItem = null;
					be.notifyUpdate();
				}
				return class_1269.field_5812;
			});
		}
		return class_1269.field_5811;
	}

	@Override
	public class_1269 onSneakWrenched(class_2680 state, class_1838 context) {
		class_1937 level = context.method_8045();
		class_2338 pos = context.method_8037();
		if (!level.method_8608()) {
			class_2586 be = level.method_8321(pos);
			class_1799 guide = class_1799.field_8037;
			if (be instanceof BlazeEnchanterBlockEntity bee) {
				guide = bee.targetItem;
				bee.setTargetItem(class_1799.field_8037);
			}
			// Revert to a normal Blaze Burner that still holds its blaze (SMOULDERING heat), facing
			// the same way - NOT the empty one and NOT the flaming LIT block.
			class_2350 facing = state.method_28498(field_11177) ? state.method_11654(field_11177) : class_2350.field_11035;
			class_2680 burner = AllBlocks.BLAZE_BURNER.method_9564()
				.method_11657(com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HEAT_LEVEL,
					com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HeatLevel.SMOULDERING)
				.method_11657(class_2383.field_11177, facing);
			level.method_8501(pos, burner);
			// Drop the guide back to the player (or the world).
			if (!guide.method_7960()) {
				if (context.method_8036() != null) {
					context.method_8036().method_31548().method_7398(guide);
				} else {
					class_1264.method_5449(level, pos.method_10263(), pos.method_10264(), pos.method_10260(), guide);
				}
			}
			IWrenchable.playRemoveSound(level, pos);
		}
		return class_1269.field_5812;
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
		return AllShapes.CASING_13PX.get(class_2350.field_11036);
	}

	@Override
	public Class<BlazeEnchanterBlockEntity> getBlockEntityClass() {
		return BlazeEnchanterBlockEntity.class;
	}

	@Override
	public class_2591<? extends BlazeEnchanterBlockEntity> getBlockEntityType() {
		return CeiBlockEntities.BLAZE_ENCHANTER;
	}

	@Override
	public boolean method_9498(class_2680 state) {
		return true;
	}

	@Override
	public int method_9572(class_2680 state, class_1937 level, class_2338 pos, class_2350 direction) {
		return ComparatorUtil.levelOfSmartFluidTank(level, pos);
	}

	@Override
	protected boolean method_9516(class_2680 state, class_10 type) {
		return false;
	}
}
