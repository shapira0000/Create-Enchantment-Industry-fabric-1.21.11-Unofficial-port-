package plus.dragons.createenchantmentindustry.content.enchanter;

import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.infrastructure.items.ItemInventory;
import net.minecraft.class_1799;
import net.minecraft.class_2350;

/**
 * The item-insertion face of the Blaze Enchanter, one per horizontal side.
 * Mirrors {@code DisenchanterItemHandler}: a single-slot inventory that hands the inserted
 * item to the block entity as a {@link TransportedItemStack} to run across the internal belt.
 */
public class BlazeEnchanterItemHandler implements ItemInventory {
	private final BlazeEnchanterBlockEntity blockEntity;
	private final class_2350 side;

	public BlazeEnchanterItemHandler(BlazeEnchanterBlockEntity be, class_2350 side) {
		this.blockEntity = be;
		this.side = side.method_10153();
	}

	@Override
	public int method_5439() {
		return 1;
	}

	@Override
	public int method_58350(class_1799 stack) {
		return stack.method_7914();
	}

	@Override
	public boolean method_5437(int slot, class_1799 stack) {
		return blockEntity.getHeldItemStack().method_7960();
	}

	@Override
	public class_1799 method_5438(int slot) {
		return slot > 1 ? class_1799.field_8037 : blockEntity.getHeldItemStack();
	}

	@Override
	public void method_5447(int slot, class_1799 stack) {
		if (slot <= 1) {
			if (stack.method_7960()) {
				blockEntity.heldItem = null;
			} else {
				TransportedItemStack heldItem = new TransportedItemStack(stack);
				heldItem.prevBeltPosition = 0.0F;
				blockEntity.setHeldItem(heldItem, side);
			}
		}
	}

	@Override
	public void method_5431() {
		blockEntity.notifyUpdate();
	}
}
