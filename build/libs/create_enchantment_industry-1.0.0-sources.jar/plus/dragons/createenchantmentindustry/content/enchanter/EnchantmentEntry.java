package plus.dragons.createenchantmentindustry.content.enchanter;

import net.minecraft.class_1887;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

/**
 * A simple (enchantment, level) pair describing what the Blaze Enchanter should apply.
 * Mirrors the original CEI's EnchantmentEntry: {@link #valid()} is true only when both the
 * enchantment holder and a positive level are present.
 */
public record EnchantmentEntry(@Nullable class_6880<class_1887> enchantment, int level) {

	public static EnchantmentEntry of(@Nullable class_6880<class_1887> enchantment, int level) {
		return new EnchantmentEntry(enchantment, level);
	}

	public static EnchantmentEntry invalid() {
		return new EnchantmentEntry(null, 0);
	}

	public boolean valid() {
		return enchantment != null && level > 0;
	}
}
