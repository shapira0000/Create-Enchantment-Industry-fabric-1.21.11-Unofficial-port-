package plus.dragons.createenchantmentindustry.content.fluids.experience;

import com.zurrtum.create.infrastructure.fluids.FluidEntry;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_3532;

/**
 * Liquid Hyper Experience.
 *
 * <p>Higher density than normal experience (xpRatio 10) and grants Night Vision + Speed
 * when awarded, matching the original CEI behaviour. The original spawned a custom
 * {@code HyperExperienceOrb} entity; until that entity is ported, this scales a normal
 * orb by the ratio, which is functionally equivalent for XP value.</p>
 */
public class HyperExperienceFluid extends ExperienceFluid {
	public HyperExperienceFluid(FluidEntry entry) {
		super(entry, 10);
	}

	@Override
	public class_1303 convertToOrb(class_1937 level, double x, double y, double z, int amount) {
		return new class_1303(level, x, y, z, amount * xpRatio);
	}

	@Override
	public void applyAdditionalEffects(class_1309 entity, int expAmount) {
		int duration = 200 * class_3532.method_15384((double) expAmount);
		entity.method_6092(new class_1293(class_1294.field_5925, duration));
		entity.method_6092(new class_1293(class_1294.field_5904, duration));
	}
}
