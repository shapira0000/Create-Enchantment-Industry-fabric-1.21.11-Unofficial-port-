package plus.dragons.createenchantmentindustry.content.fluids.experience;

import com.zurrtum.create.infrastructure.fluids.FlowableFluid;
import com.zurrtum.create.infrastructure.fluids.FluidEntry;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;

/**
 * Liquid Experience.
 *
 * <p>In the original CEI this extended Create's {@code VirtualFluid}. Create Fly has no
 * VirtualFluid concept, so this extends {@link FlowableFluid.Still} and carries the
 * XP-conversion logic CEI relies on.</p>
 */
public class ExperienceFluid extends FlowableFluid.Still {
	protected final int xpRatio;

	public ExperienceFluid(FluidEntry entry, int xpRatio) {
		super(entry);
		this.xpRatio = xpRatio;
	}

	public ExperienceFluid(FluidEntry entry) {
		this(entry, 1);
	}

	public int getXpRatio() {
		return xpRatio;
	}

	/** Create an XP orb of the given size at a position. Overridden by hyper experience. */
	public class_1303 convertToOrb(class_1937 level, double x, double y, double z, int amount) {
		return new class_1303(level, x, y, z, amount);
	}

	/** Spill the given amount of raw fluid as XP orbs into the world (open pipe behaviour). */
	public void drop(class_3218 level, class_243 pos, int realFluidAmount) {
		int amount = realFluidAmount / EnchantmentIndustry.UNIT_PER_MB;
		while (amount > 0) {
			int orbSize = class_1303.method_5918(amount);
			amount -= orbSize;
			if (!class_1303.method_31496(level, pos, orbSize)) {
				level.method_8649(convertToOrb(level, pos.field_1352, pos.field_1351, pos.field_1350, orbSize));
			}
		}
	}

	/** Award the fluid to a player (repairing mending gear first), or drop it if no player. */
	public void awardOrDrop(@Nullable class_1657 player, class_3218 level, class_243 pos, class_243 speed, int realAmount) {
		int amount = realAmount / EnchantmentIndustry.UNIT_PER_MB;
		class_1303 orb = convertToOrb(level, pos.field_1352, pos.field_1351, pos.field_1350, amount);
		if (player == null) {
			if (!class_1303.method_31496(level, pos, amount)) {
				orb.method_18799(speed);
				level.method_8649(orb);
			}
		} else if (player instanceof class_3222 serverPlayer) {
			// repairPlayerItems is an INSTANCE method on the orb (matches original CEI behaviour).
			int left = orb.method_35051(serverPlayer, amount);
			if (left > 0) {
				player.method_7255(left);
				applyAdditionalEffects(player, left);
			}
		}
	}

	/** Hook for hyper experience to add potion effects. No-op for normal experience. */
	public void applyAdditionalEffects(class_1309 entity, int expAmount) {
	}
}
