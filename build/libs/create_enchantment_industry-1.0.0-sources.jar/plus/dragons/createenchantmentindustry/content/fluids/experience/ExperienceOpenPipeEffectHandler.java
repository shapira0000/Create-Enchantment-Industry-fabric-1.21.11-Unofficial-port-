package plus.dragons.createenchantmentindustry.content.fluids.experience;

import com.zurrtum.create.api.effect.OpenPipeEffectHandler;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * Converts Liquid/Hyper Experience back into experience when it pours out of an open-ended pipe.
 *
 * <p>Faithful to the original CEI: if players stand in the pour area, the experience is split
 * between them (mending their gear first, then topping up their bar); otherwise it drops as
 * experience orbs into the world. The fluid amount is in millibuckets — {@link ExperienceFluid}'s
 * {@code drop}/{@code awardOrDrop} divide by the unit-per-mB ratio internally, so we pass the raw
 * amount straight through. This is what makes the tank drain at the correct rate and actually
 * grant levels, instead of vanishing.</p>
 */
public class ExperienceOpenPipeEffectHandler implements OpenPipeEffectHandler {

	public static void register() {
		// Register the handler for all four fluids. The REGISTRY is keyed by Fluid, so we pass
		// the still/flowing fields directly - only the "still" forms are ExperienceFluid; the
		// "flowing" forms are FlowableFluid.Flowing, so we must NOT cast them.
		ExperienceOpenPipeEffectHandler handler = new ExperienceOpenPipeEffectHandler();
		OpenPipeEffectHandler.REGISTRY.register(CeiFluids.EXPERIENCE.still, handler);
		OpenPipeEffectHandler.REGISTRY.register(CeiFluids.EXPERIENCE.flowing, handler);
		OpenPipeEffectHandler.REGISTRY.register(CeiFluids.HYPER_EXPERIENCE.still, handler);
		OpenPipeEffectHandler.REGISTRY.register(CeiFluids.HYPER_EXPERIENCE.flowing, handler);
	}

	@Override
	public void apply(class_1937 level, class_238 area, FluidStack fluid) {
		if (!(level instanceof class_3218 serverLevel)) {
			return;
		}
		if (!(fluid.getFluid() instanceof ExperienceFluid expFluid)) {
			return;
		}
		int amount = fluid.getAmount();
		if (amount <= 0) {
			return;
		}

		List<class_1657> players = serverLevel.method_8390(class_1657.class, area, class_1309::method_5805);
		class_243 center = area.method_1005();

		if (players.isEmpty()) {
			// No one nearby: spill the experience into the world as orbs.
			expFluid.drop(serverLevel, center, amount);
			return;
		}

		// Split the experience between the players standing in the pour area.
		int size = players.size();
		int per = amount / size;
		int remainder = amount % size;
		for (int i = 0; i < size; i++) {
			class_1657 player = players.get(i);
			int give = per + (i < remainder ? 1 : 0);
			if (give > 0) {
				expFluid.awardOrDrop(player, serverLevel, center, class_243.field_1353, give);
			}
		}
	}
}
