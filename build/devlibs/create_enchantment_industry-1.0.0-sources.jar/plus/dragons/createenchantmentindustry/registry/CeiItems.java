package plus.dragons.createenchantmentindustry.registry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideItem;

/** Item registration for Create: Enchantment Industry. */
public class CeiItems {
	public static final EnchantingGuideItem ENCHANTING_GUIDE = registerEnchantingGuide();
	public static final net.minecraft.world.item.BucketItem INK_BUCKET = registerInkBucket();

	private static EnchantingGuideItem registerEnchantingGuide() {
		Identifier id = EnchantmentIndustry.genRL("enchanting_guide");
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
		Item.Properties props = new Item.Properties().stacksTo(1).setId(key);
		EnchantingGuideItem item = new EnchantingGuideItem(props);
		Registry.register(BuiltInRegistries.ITEM, key, item);
		return item;
	}

	private static net.minecraft.world.item.BucketItem registerInkBucket() {
		// A standard filled bucket for Ink: holds the still Ink fluid, stacks to 1, and leaves an
		// empty bucket behind when used. Wired into the FluidEntry so Create's fluid handling knows
		// the bucket form (lets you bucket Ink in/out of tanks and shows it in JEI / creative).
		Identifier id = EnchantmentIndustry.genRL("ink_bucket");
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
		Item.Properties props = new Item.Properties()
			.craftRemainder(net.minecraft.world.item.Items.BUCKET)
			.stacksTo(1)
			.setId(key);
		net.minecraft.world.item.BucketItem bucket =
			new net.minecraft.world.item.BucketItem(CeiFluids.INK.still, props);
		Registry.register(BuiltInRegistries.ITEM, key, bucket);
		CeiFluids.INK.bucket = bucket;
		return bucket;
	}

	public static void register() {
		// Class-load triggers the static initializer above.
	}
}
