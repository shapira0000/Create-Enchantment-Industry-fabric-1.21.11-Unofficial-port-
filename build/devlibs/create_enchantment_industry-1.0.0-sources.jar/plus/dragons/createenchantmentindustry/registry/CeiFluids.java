package plus.dragons.createenchantmentindustry.registry;

import com.zurrtum.create.infrastructure.fluids.FlowableFluid;
import com.zurrtum.create.infrastructure.fluids.FluidEntry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.material.Fluid;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.fluids.experience.ExperienceFluid;
import plus.dragons.createenchantmentindustry.content.fluids.experience.HyperExperienceFluid;

/**
 * Fluid registration, mirroring Create Fly's {@code com.zurrtum.create.AllFluids}:
 * each fluid is backed by a {@link FluidEntry} holding a still + flowing instance,
 * both registered into the vanilla fluid registry.
 */
public class CeiFluids {
	public static final FluidEntry EXPERIENCE = registerExperience();
	public static final FluidEntry HYPER_EXPERIENCE = registerHyperExperience();
	public static final FluidEntry INK = registerInk();

	private static FluidEntry registerInk() {
		// Ink is a plain Create fluid (like Create Fly's MILK / HONEY): a still + flowing pair
		// registered into the vanilla fluid registry. Because it uses the same FlowableFluid base
		// as every other Create fluid, it works in all Create tanks, pipes and pumps automatically.
		Identifier id = EnchantmentIndustry.genRL("ink");
		Identifier flowingId = EnchantmentIndustry.genRL("flowing_ink");
		ResourceKey<Fluid> stillKey = ResourceKey.create(Registries.FLUID, id);
		ResourceKey<Fluid> flowingKey = ResourceKey.create(Registries.FLUID, flowingId);
		FluidEntry entry = new FluidEntry();
		entry.still = new FlowableFluid.Still(entry);
		entry.flowing = new FlowableFluid.Flowing(entry);
		Registry.register(BuiltInRegistries.FLUID, stillKey, entry.still);
		Registry.register(BuiltInRegistries.FLUID, flowingKey, entry.flowing);

		// The placed liquid block. A FluidBlock is what a bucket actually places in the world, and
		// what FlowableFluid.getBlockState() resolves to - without it, the Ink Bucket can't place
		// anything. Mirrors Create Fly's Honey / Chocolate fluid blocks (water-like properties).
		Identifier blockId = EnchantmentIndustry.genRL("ink");
		ResourceKey<net.minecraft.world.level.block.Block> blockKey =
			ResourceKey.create(Registries.BLOCK, blockId);
		net.minecraft.world.level.block.state.BlockBehaviour.Properties blockProps =
			net.minecraft.world.level.block.state.BlockBehaviour.Properties
				.ofFullCopy(net.minecraft.world.level.block.Blocks.WATER)
				.mapColor(net.minecraft.world.level.material.MapColor.COLOR_BLACK)
				.setId(blockKey);
		com.zurrtum.create.infrastructure.fluids.FluidBlock inkBlock =
			new com.zurrtum.create.infrastructure.fluids.FluidBlock(entry.still, blockProps);
		Registry.register(BuiltInRegistries.BLOCK, blockKey, inkBlock);
		entry.block = inkBlock;

		return entry;
	}

	private static FluidEntry registerExperience() {
		Identifier id = EnchantmentIndustry.genRL("experience");
		Identifier flowingId = EnchantmentIndustry.genRL("flowing_experience");
		ResourceKey<Fluid> stillKey = ResourceKey.create(Registries.FLUID, id);
		ResourceKey<Fluid> flowingKey = ResourceKey.create(Registries.FLUID, flowingId);
		FluidEntry entry = new FluidEntry();
		entry.still = new ExperienceFluid(entry, 1);
		entry.flowing = new FlowableFluid.Flowing(entry);
		Registry.register(BuiltInRegistries.FLUID, stillKey, entry.still);
		Registry.register(BuiltInRegistries.FLUID, flowingKey, entry.flowing);
		return entry;
	}

	private static FluidEntry registerHyperExperience() {
		Identifier id = EnchantmentIndustry.genRL("hyper_experience");
		Identifier flowingId = EnchantmentIndustry.genRL("flowing_hyper_experience");
		ResourceKey<Fluid> stillKey = ResourceKey.create(Registries.FLUID, id);
		ResourceKey<Fluid> flowingKey = ResourceKey.create(Registries.FLUID, flowingId);
		FluidEntry entry = new FluidEntry();
		entry.still = new HyperExperienceFluid(entry);
		entry.flowing = new FlowableFluid.Flowing(entry);
		Registry.register(BuiltInRegistries.FLUID, stillKey, entry.still);
		Registry.register(BuiltInRegistries.FLUID, flowingKey, entry.flowing);
		return entry;
	}

	public static void register() {
		// Class-load triggers the static field initializers above.
	}
}
