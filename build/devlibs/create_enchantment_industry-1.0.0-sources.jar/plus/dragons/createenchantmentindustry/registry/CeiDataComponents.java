package plus.dragons.createenchantmentindustry.registry;

import com.mojang.serialization.Codec;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.world.item.ItemStack;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;

import java.util.function.UnaryOperator;

/**
 * Custom data components stored on an Enchanting Guide.
 *
 * <p>The guide remembers the WHOLE book it was loaded from ({@link #TARGET}) plus the index of
 * the chosen enchantment within that book ({@link #INDEX}). The chosen enchantment is always
 * resolved by reading the index against the enchantments of that stored book - the same
 * ItemStack on every side - so the choice can never drift out of sync regardless of how an
 * enchantment map happens to iterate. This mirrors the original CEI design (NBT "target" + "index").</p>
 */
public class CeiDataComponents {

	/** The book (an enchanted book / any item carrying enchantments) the guide was loaded from. */
	public static final DataComponentType<ItemStack> TARGET = register(
		"target",
		builder -> builder.persistent(ItemStack.CODEC).networkSynchronized(ItemStack.OPTIONAL_STREAM_CODEC)
	);

	/** The index of the selected enchantment within {@link #TARGET}'s enchantment list. */
	public static final DataComponentType<Integer> INDEX = register(
		"index",
		builder -> builder.persistent(Codec.INT).networkSynchronized(ByteBufCodecs.VAR_INT)
	);

	private static <T> DataComponentType<T> register(String id, UnaryOperator<DataComponentType.Builder<T>> op) {
		return Registry.register(
			BuiltInRegistries.DATA_COMPONENT_TYPE,
			EnchantmentIndustry.genRL(id),
			op.apply(DataComponentType.builder()).build()
		);
	}

	/** Force class-load so the static fields register. Call from the main initializer. */
	public static void register() {
	}
}
