package plus.dragons.createenchantmentindustry.registry;

import com.zurrtum.create.api.registry.CreateRegistries;
import com.zurrtum.create.foundation.gui.menu.MenuType;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideMenu;

/**
 * Menu-type registration. Uses Create Fly's own menu system ({@link CreateRegistries#MENU_TYPE}),
 * the same registry Create itself registers its menus into, so the menu opens through Create's
 * {@code OpenScreenPacket} pipeline.
 */
public class CeiMenuTypes {

	public static final MenuType<ItemStack> ENCHANTING_GUIDE =
		register("enchanting_guide", EnchantingGuideMenu::new);

	private static <T> MenuType<T> register(String name, MenuType<T> type) {
		Identifier rl = EnchantmentIndustry.genRL(name);
		return Registry.register(CreateRegistries.MENU_TYPE, rl, type);
	}

	/** Called from the mod initializer to force class-load (registration happens in field init). */
	public static void register() {
	}
}
