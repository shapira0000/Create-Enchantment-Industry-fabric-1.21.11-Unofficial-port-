package plus.dragons.createenchantmentindustry.registry;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.disenchanter.DisenchanterBlock;
import plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlock;

/**
 * Block (and block-item) registration, following Create Fly's {@code AllBlocks}/{@code AllItems}
 * pattern: build a {@link ResourceKey}, attach it to the block {@link BlockBehaviour.Properties}
 * via {@code setId}, register the block, then register a matching {@link BlockItem}.
 */
public class CeiBlocks {
	public static final DisenchanterBlock DISENCHANTER = registerDisenchanter();
	public static final BlazeEnchanterBlock BLAZE_ENCHANTER = registerBlazeEnchanter();

	private static DisenchanterBlock registerDisenchanter() {
		Identifier id = EnchantmentIndustry.genRL("disenchanter");
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
		// Andesite-casing-like stone properties (explicit, to avoid base-block ambiguity).
		BlockBehaviour.Properties props = BlockBehaviour.Properties.of()
			.mapColor(MapColor.STONE)
			.strength(1.5F, 6.0F)
			.sound(SoundType.STONE)
			.noOcclusion()
			.setId(blockKey);
		DisenchanterBlock block = new DisenchanterBlock(props);
		Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

		// Matching block item.
		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
		Item.Properties itemProps = new Item.Properties().useBlockDescriptionPrefix().setId(itemKey);
		Registry.register(BuiltInRegistries.ITEM, itemKey, new BlockItem(block, itemProps));

		return block;
	}

	private static BlazeEnchanterBlock registerBlazeEnchanter() {
		Identifier id = EnchantmentIndustry.genRL("blaze_enchanter");
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
		BlockBehaviour.Properties props = BlockBehaviour.Properties.of()
			.mapColor(MapColor.STONE)
			.strength(1.5F, 6.0F)
			.sound(SoundType.STONE)
			.lightLevel(s -> 0)
			.noOcclusion()
			.setId(blockKey);
		BlazeEnchanterBlock block = new BlazeEnchanterBlock(props);
		Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
		// No BlockItem: the Blaze Enchanter cannot be obtained or placed directly.
		// It only exists by right-clicking a Blaze Burner with an Enchanting Guide,
		// and reverts to a Blaze Burner when broken (see its loot table).
		return block;
	}

	public static void register() {
		// Class-load triggers the static initializers above.
	}
}
