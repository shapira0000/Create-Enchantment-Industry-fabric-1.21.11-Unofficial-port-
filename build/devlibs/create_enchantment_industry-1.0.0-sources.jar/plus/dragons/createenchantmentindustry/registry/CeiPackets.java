package plus.dragons.createenchantmentindustry.registry;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlockEntity;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideEditPacket;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideItem;

/**
 * Networking. The Enchanting Guide screen sends one edit packet on close, carrying the chosen
 * index and the book that was in the ghost slot. The server stores BOTH the book and the index
 * on the guide (as {@link CeiDataComponents#TARGET} / {@link CeiDataComponents#INDEX}); the actual
 * enchantment is always resolved later from that stored book, so client and server never disagree.
 */
public class CeiPackets {

	public static void registerCommon() {
		PayloadTypeRegistry.playC2S().register(EnchantingGuideEditPacket.TYPE, EnchantingGuideEditPacket.STREAM_CODEC);
	}

	public static void registerServerReceivers() {
		ServerPlayNetworking.registerGlobalReceiver(EnchantingGuideEditPacket.TYPE, (payload, context) -> {
			ItemStack book = payload.book();
			int index = payload.index();

			if (payload.blockPos() != null) {
				// Opened from a placed Blaze Enchanter: store onto the block's guide.
				BlockEntity be = context.player().level().getBlockEntity(payload.blockPos());
				if (be instanceof BlazeEnchanterBlockEntity bee && !bee.targetItem.isEmpty()) {
					ItemStack guide = bee.targetItem.copy();
					EnchantingGuideItem.store(guide, book, index);
					bee.setTargetItem(guide);
					bee.notifyUpdate();
				}
			} else {
				// Held guide.
				ItemStack guide = context.player().getMainHandItem();
				if (guide.getItem() instanceof EnchantingGuideItem) {
					EnchantingGuideItem.store(guide, book, index);
				}
			}
		});
	}
}
