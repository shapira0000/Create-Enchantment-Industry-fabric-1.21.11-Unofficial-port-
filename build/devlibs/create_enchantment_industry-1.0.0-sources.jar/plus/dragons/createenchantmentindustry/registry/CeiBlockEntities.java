package plus.dragons.createenchantmentindustry.registry;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.BlockEntityType;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.content.disenchanter.DisenchanterBlockEntity;
import plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlockEntity;

/**
 * Block-entity-type registration.
 *
 * <p>Uses Fabric API's public {@link FabricBlockEntityTypeBuilder}, the intended way for
 * add-ons to create block-entity types without touching vanilla's package-private
 * {@code BlockEntityType} constructor. No access widener needed for this.</p>
 */
public class CeiBlockEntities {
	public static final BlockEntityType<DisenchanterBlockEntity> DISENCHANTER = register("disenchanter");
	public static final BlockEntityType<BlazeEnchanterBlockEntity> BLAZE_ENCHANTER = registerBlazeEnchanter();

	private static BlockEntityType<DisenchanterBlockEntity> register(String id) {
		Identifier rl = EnchantmentIndustry.genRL(id);
		// The lambda is only invoked later (when a block entity is created in-world), by which
		// point DISENCHANTER is fully assigned, so referencing it here is safe.
		BlockEntityType<DisenchanterBlockEntity> type = FabricBlockEntityTypeBuilder
			.create((pos, state) -> new DisenchanterBlockEntity(CeiBlockEntities.DISENCHANTER, pos, state), CeiBlocks.DISENCHANTER)
			.build();
		return Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, rl, type);
	}

	private static BlockEntityType<BlazeEnchanterBlockEntity> registerBlazeEnchanter() {
		Identifier rl = EnchantmentIndustry.genRL("blaze_enchanter");
		BlockEntityType<BlazeEnchanterBlockEntity> type = FabricBlockEntityTypeBuilder
			.create((pos, state) -> new BlazeEnchanterBlockEntity(CeiBlockEntities.BLAZE_ENCHANTER, pos, state), CeiBlocks.BLAZE_ENCHANTER)
			.build();
		return Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, rl, type);
	}

	public static void register() {
		// Class-load triggers the static initializer above.
	}
}
