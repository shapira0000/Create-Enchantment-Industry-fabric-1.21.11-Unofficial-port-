package plus.dragons.createenchantmentindustry;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import plus.dragons.createenchantmentindustry.registry.CeiBlockEntities;
import plus.dragons.createenchantmentindustry.registry.CeiBlocks;
import plus.dragons.createenchantmentindustry.registry.CeiItems;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;

public class EnchantmentIndustry implements ModInitializer {
	public static final String ID = "create_enchantment_industry";
	public static final Logger LOGGER = LoggerFactory.getLogger("Create Enchantment Industry");

	/** Create's experience fluid uses 81 units (1 mB) granularity, matching Create Fly's fluid amounts. */
	public static final int UNIT_PER_MB = 81;

	public static Identifier genRL(String name) {
		return Identifier.fromNamespaceAndPath(ID, name);
	}

	@Override
	public void onInitialize() {
		LOGGER.info("Create: Enchantment Industry initializing (1.21.11 / Create Fly)");
		CeiFluids.register();
		CeiBlocks.register();          // blocks first
		CeiItems.register();
		plus.dragons.createenchantmentindustry.registry.CeiDataComponents.register();
		CeiBlockEntities.register();   // block-entity types reference the blocks
		plus.dragons.createenchantmentindustry.registry.CeiMenuTypes.register();
		plus.dragons.createenchantmentindustry.registry.CeiPackets.registerCommon();
		plus.dragons.createenchantmentindustry.registry.CeiPackets.registerServerReceivers();
		plus.dragons.createenchantmentindustry.content.fluids.experience.ExperienceOpenPipeEffectHandler.register();
		LOGGER.info("Create: Enchantment Industry initialized.");
	}
}
