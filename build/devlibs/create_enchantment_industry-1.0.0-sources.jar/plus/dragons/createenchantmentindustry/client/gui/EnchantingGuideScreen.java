package plus.dragons.createenchantmentindustry.client.gui;

import com.zurrtum.create.client.catnip.gui.element.GuiGameElement;
import com.zurrtum.create.client.catnip.gui.element.RenderElement;
import com.zurrtum.create.client.foundation.gui.AllGuiTextures;
import com.zurrtum.create.client.foundation.gui.menu.AbstractSimiContainerScreen;
import com.zurrtum.create.client.foundation.gui.widget.Label;
import com.zurrtum.create.client.foundation.gui.widget.SelectionScrollInput;
import com.zurrtum.create.foundation.gui.menu.MenuType;
import java.util.Collections;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideEditPacket;
import plus.dragons.createenchantmentindustry.content.enchanter.EnchantingGuideMenu;

/**
 * Client screen for the Enchanting Guide: shows the ghost book slot, a scroll selector to choose
 * which of the book's enchantments to apply, and a label with the chosen enchantment's name.
 * Each pick sends an {@link EnchantingGuideEditPacket} so the server records the choice and writes
 * it onto the guide when the screen closes.
 */
@Environment(EnvType.CLIENT)
public class EnchantingGuideScreen extends AbstractSimiContainerScreen<EnchantingGuideMenu> {

	private static final Identifier BACKGROUND =
		Identifier.fromNamespaceAndPath("create_enchantment_industry", "textures/gui/enchanting_guide.png");
	private static final int PANEL_WIDTH = 185;
	private static final int PANEL_HEIGHT = 48;

	private List<Rect2i> extraAreas = Collections.emptyList();
	private SelectionScrollInput scrollInput;
	private Label scrollInputLabel;
	private int index;
	private java.util.List<net.minecraft.network.chat.Component> lastShown;

	public EnchantingGuideScreen(EnchantingGuideMenu menu, Inventory inv, Component title) {
		super(menu, inv, title);
		this.index = menu.index;
	}

	public static EnchantingGuideScreen create(
		Minecraft mc, MenuType<ItemStack> type, int syncId, Inventory inventory, Component title, RegistryFriendlyByteBuf extraData
	) {
		ItemStack guide = getStack(extraData);
		boolean hasBlock = extraData.readBoolean();
		net.minecraft.core.BlockPos blockPos = hasBlock ? extraData.readBlockPos() : null;
		EnchantingGuideScreen screen = type.create(EnchantingGuideScreen::new, syncId, inventory, title, guide);
		if (screen != null) {
			screen.menu.blockPos = blockPos;
		}
		return screen;
	}

	@Override
	protected void init() {
		setWindowSize(AllGuiTextures.PLAYER_INVENTORY.getWidth(), PANEL_HEIGHT + 6 + AllGuiTextures.PLAYER_INVENTORY.getHeight());
		super.init();

		int x = leftPos;
		int y = topPos;

		// Guard against a null/empty list so the scroll widget never indexes out of bounds.
		java.util.List<net.minecraft.network.chat.Component> options =
			(menu.enchantments == null || menu.enchantments.isEmpty())
				? java.util.List.of(EnchantingGuideMenu.NO_ENCHANTMENT)
				: menu.enchantments;
		int startIndex = Math.max(0, Math.min(index, options.size() - 1));

		scrollInputLabel = new Label(x + 50, y + 27, Component.empty()).withShadow();
		scrollInput = (SelectionScrollInput) new SelectionScrollInput(x + 43, y + 22, 116, 18)
			.forOptions(options)
			.writingTo(scrollInputLabel)
			.titled(Component.translatable("create_enchantment_industry.gui.enchanting_guide.search").copy())
			.calling(i -> index = i)
			.setState(startIndex);
		scrollInput.onChanged();

		addRenderableWidget(scrollInput);
		addRenderableWidget(scrollInputLabel);

		extraAreas = Collections.singletonList(new Rect2i(x + imageWidth, y, 56, 56));
	}

	@Override
	protected void renderBg(GuiGraphics graphics, float partialTicks, int mouseX, int mouseY) {
		int x = leftPos;
		int y = topPos;

		// The enchanting-guide panel (top), then the player inventory (below).
		graphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, BACKGROUND,
			x, y, 0.0F, 0.0F, PANEL_WIDTH, PANEL_HEIGHT, 256, 256);
		renderPlayerInventory(graphics, x, y + PANEL_HEIGHT + 6);

		graphics.drawString(font, title, x + 15, y + 4, 0x592424, false);

		ItemStack guide = menu.contentHolder;
		RenderElement element = GuiGameElement.of(guide)
			.scale(3.0F)
			.at((float) (x + imageWidth + 6), (float) (y + 20), -200.0F);
		element.render(graphics);
	}

	@Override
	public void removed() {
		// Commit on close in a single packet that includes the chosen index AND the book in the
		// ghost slot (so the server doesn't depend on ghost-inventory syncing). Mirrors the
		// original CEI's removed() behaviour.
		if (scrollInput != null) {
			int chosen = scrollInput.getState();
			ItemStack book = menu.getGhostBook();
			ClientPlayNetworking.send(new EnchantingGuideEditPacket(chosen, book.copy(), menu.blockPos));
		}
		super.removed();
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		// Vanilla container screens don't forward scroll to child widgets; do it manually so the
		// enchantment selector scrolls when the cursor is over it.
		return getChildAt(mouseX, mouseY)
			.filter(child -> child.mouseScrolled(mouseX, mouseY, scrollX, scrollY))
			.isPresent()
			|| super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	@Override
	public List<Rect2i> getExtraAreas() {
		return extraAreas;
	}

	@Override
	protected void containerTick() {
		super.containerTick();
		// Rebuild from the current book in the ghost slot (client-side). Only refresh the scroll
		// options when the CONTENT actually changed (compare by value, not by reference - the
		// list is a fresh object each tick), and never call onChanged() here (that would re-fire
		// the scroll callback and re-send the packet, causing an off-by-one feedback loop).
		menu.updateEnchantments(menu.getGhostBook());
		if (menu.enchantments != null && !menu.enchantments.equals(lastShown)) {
			lastShown = menu.enchantments;
			int keep = Math.max(0, Math.min(scrollInput.getState(), menu.enchantments.size() - 1));
			scrollInput.forOptions(menu.enchantments);
			scrollInput.setState(keep);
		}
		// Keep our tracked index in sync with the widget (the widget is the source of truth).
		index = scrollInput.getState();
	}
}
