package plus.dragons.createenchantmentindustry.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.resources.Identifier;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.registry.CeiBlockEntities;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;
import plus.dragons.createenchantmentindustry.registry.CeiBlocks;

/**
 * Client setup: fluid textures + block-entity renderers.
 */
public class EnchantmentIndustryClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		registerFluidTexture(CeiFluids.EXPERIENCE, "experience", 0x4CFF45);
		registerFluidTexture(CeiFluids.HYPER_EXPERIENCE, "hyper_experience", 0xFF45D9);
		registerFluidTexture(CeiFluids.INK, "ink", 0xFFFFFF);

		BlockEntityRenderers.register(CeiBlockEntities.DISENCHANTER, DisenchanterRenderer::new);
		BlockEntityRenderers.register(CeiBlockEntities.BLAZE_ENCHANTER, BlazeEnchanterRenderer::new);

		// Enchanting Guide screen (opens via Create's OpenScreenPacket -> AllMenuScreens.ALL).
		com.zurrtum.create.client.AllMenuScreens.register(
			plus.dragons.createenchantmentindustry.registry.CeiMenuTypes.ENCHANTING_GUIDE,
			plus.dragons.createenchantmentindustry.client.gui.EnchantingGuideScreen::create);

		// In 1.21.11 the model's render_type field isn't honored on Fabric; the block's
		// transparent (cutout) top must be registered explicitly so the hole renders through.
		BlockRenderLayerMap.putBlock(CeiBlocks.DISENCHANTER, ChunkSectionLayer.CUTOUT);
	}

	private static void registerFluidTexture(
		com.zurrtum.create.infrastructure.fluids.FluidEntry entry,
		String name,
		int tint
	) {
		Identifier still = EnchantmentIndustry.genRL("fluid/" + name + "_still");
		Identifier flow = EnchantmentIndustry.genRL("fluid/" + name + "_flow");
		SimpleFluidRenderHandler handler = new SimpleFluidRenderHandler(still, flow, tint);
		FluidRenderHandlerRegistry.INSTANCE.register(entry.still, entry.flowing, handler);
	}
}
