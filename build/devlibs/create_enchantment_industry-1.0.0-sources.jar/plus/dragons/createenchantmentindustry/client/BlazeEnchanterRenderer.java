package plus.dragons.createenchantmentindustry.client;

import com.zurrtum.create.catnip.math.AngleHelper;
import com.zurrtum.create.client.AllPartialModels;
import com.zurrtum.create.client.catnip.animation.AnimationTickHolder;
import com.zurrtum.create.client.catnip.render.CachedBuffers;
import com.zurrtum.create.client.catnip.render.SuperByteBuffer;
import com.zurrtum.create.client.flywheel.lib.model.baked.PartialModel;
import com.zurrtum.create.client.foundation.blockEntity.renderer.SmartBlockEntityRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.object.book.BookModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import org.jetbrains.annotations.Nullable;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlockEntity;

/**
 * Renders the Blaze Enchanter: the blaze cage + blaze head (reusing Create's Blaze Burner partial
 * models), plus the real vanilla BookModel floating above the cage, textured with the special
 * blaze_enchanter_book texture, with page-flip animation. The head looks toward the player and the
 * book rotates with it, matching the original 1-to-1.
 */
@Environment(EnvType.CLIENT)
public class BlazeEnchanterRenderer
	extends SmartBlockEntityRenderer<BlazeEnchanterBlockEntity, BlazeEnchanterRenderer.BlazeEnchanterRenderState> {

	// The special book texture (full path under textures/).
	public static final Identifier BOOK_TEXTURE =
		Identifier.fromNamespaceAndPath("create_enchantment_industry", "textures/block/blaze_enchanter_book.png");
	// Render layer bound to that texture (entitySolid is what the vanilla BookModel uses).
	public static final RenderType BOOK_LAYER = RenderTypes.entitySolid(BOOK_TEXTURE);

	private final BookModel bookModel;

	public BlazeEnchanterRenderer(BlockEntityRendererProvider.Context context) {
		super(context);
		// Bake the book layer ourselves from BookModel.createBodyLayer() - no ModelLayers lookup needed.
		ModelPart root = BookModel.createBodyLayer().bakeRoot();
		this.bookModel = new BookModel(root);
	}

	@Override
	public BlazeEnchanterRenderState createRenderState() {
		return new BlazeEnchanterRenderState();
	}

	@Override
	public void extractRenderState(
		BlazeEnchanterBlockEntity be, BlazeEnchanterRenderState state, float partialTicks, Vec3 cameraPos,
		@Nullable ModelFeatureRenderer.CrumblingOverlay crumblingOverlay
	) {
		super.extractRenderState(be, state, partialTicks, cameraPos, crumblingOverlay);

		BlockState blockState = be.getBlockState();
		float animation = be.headAnimation.getValue(partialTicks) * 0.175F;
		float time = AnimationTickHolder.getRenderTime(be.getLevel());
		float headAngleRad = AngleHelper.rad(be.headAngle.getValue(partialTicks));

		boolean active = !be.getInternalTank().getPrimaryHandler().getFluid().isEmpty();

		// SLOW bob when heated (divide by 64 like the Blaze Burner), normal (16) when not.
		float renderTick = time / 16.0F + (be.hashCode() % 13);
		float offsetMult = active ? 64.0F : 16.0F;
		float offset = Mth.sin(renderTick % ((float) Math.PI * 2.0F)) / offsetMult;
		float offset1 = Mth.sin((renderTick + (float) Math.PI) % ((float) Math.PI * 2.0F)) / offsetMult;
		float offset2 = Mth.sin((renderTick + (float) (Math.PI / 2.0)) % ((float) Math.PI * 2.0F)) / offsetMult;

		// Head lift (heated a touch higher). The rods use their OWN smaller lift so the arms
		// sit half-in / half-out of the block like the original (not flying above it).
		float HEAD_LIFT = active ? 0.25F : 0.25F;

		// The head - SAME working setup that shows the eyes (translucentMovingBlock).
		PartialModel blazeModel = active ? AllPartialModels.BLAZE_IDLE : AllPartialModels.BLAZE_INERT;
		BlazeRenderState blaze = new BlazeRenderState();
		blaze.layer = RenderTypes.translucentMovingBlock();
		blaze.buffer = CachedBuffers.partial(blazeModel, blockState);
		blaze.translateY = HEAD_LIFT + offset - animation * -0.80F;
		blaze.angle = headAngleRad;
		state.blaze = blaze;

		// Cage uses cutoutMovingBlock so the book stays visible through the sides.
		BlazeRenderState cage = new BlazeRenderState();
		cage.layer = RenderTypes.cutoutMovingBlock();
		cage.buffer = CachedBuffers.partial(AllPartialModels.BLAZE_CAGE, blockState);
		cage.translateY = 0.0F;
		cage.angle = 0.0F;
		state.cage = cage;

		// Heated: add the two rod rings (the "arms"), each its own state, same render path as
		// the head. Slow movement (offsets already divided by 64).
		if (active) {
			BlazeRenderState rods = new BlazeRenderState();
			rods.layer = RenderTypes.translucentMovingBlock();
			rods.buffer = CachedBuffers.partial(AllPartialModels.BLAZE_BURNER_RODS, blockState);
			rods.translateY = HEAD_LIFT + offset1 + animation + 0.125F;
			rods.angle = 0.0F;
			state.rods = rods;

			BlazeRenderState rods2 = new BlazeRenderState();
			rods2.layer = RenderTypes.translucentMovingBlock();
			rods2.buffer = CachedBuffers.partial(AllPartialModels.BLAZE_BURNER_RODS_2, blockState);
			rods2.translateY = HEAD_LIFT + offset2 + animation - 0.1875F;
			rods2.angle = 0.0F;
			state.rods2 = rods2;
		}


		// The floating open book. Rotates with the head; bobs on a sine wave; pages flutter.
		BookRenderState book = new BookRenderState();
		book.model = this.bookModel;
		book.layer = BOOK_LAYER;
		book.angle = headAngleRad;
		book.bob = 0.9F + offset;
		book.light = state.lightCoords;
		book.animationPos = time;
		book.pageFlip1 = (Mth.sin(time * 0.1F) + 1.0F) * 0.5F;
		book.pageFlip2 = (Mth.cos(time * 0.1F) + 1.0F) * 0.5F;
		book.open = 1.0F;
		state.book = book;

		// The item being enchanted, riding up over the block and spinning while processed.
		updateHeldItemRenderState(be, state, partialTicks);
	}

	private void updateHeldItemRenderState(BlazeEnchanterBlockEntity be, BlazeEnchanterRenderState state, float partialTicks) {
		TransportedItemStack transported = be.heldItem;
		if (transported == null) {
			return;
		}
		HeldItemRenderState item = state.item = new HeldItemRenderState();

		float beltPos = Mth.lerp(partialTicks, transported.prevBeltPosition, transported.beltPosition);

		// Vertical bob: rises toward the middle (peak at 0.5) plus a gentle idle wobble.
		float time = AnimationTickHolder.getRenderTime(be.getLevel());
		float renderTick = time / 16.0F + (be.hashCode() % 13);
		boolean active = !be.getInternalTank().getPrimaryHandler().getFluid().isEmpty();
		float offsetMult = active ? 64.0F : 16.0F;
		float sineOffset = Mth.sin(renderTick % ((float) Math.PI * 2.0F)) / offsetMult;
		float lift = Mth.sin((0.5F - Math.abs(0.5F - beltPos)) * (float) Math.PI / 2.0F);
		item.bob = lift * 0.75F + sineOffset * 0.75F;

		Direction insertedFrom = transported.insertedFrom;
		boolean horizontal = insertedFrom.getAxis().isHorizontal();
		Vec3 along = Vec3.atLowerCornerOf(insertedFrom.getOpposite().getUnitVec3i()).scale(0.5F - beltPos);
		item.travel = horizontal ? along : Vec3.ZERO;

		float twoPi = (float) Math.PI * 2.0F;
		boolean enchanting = be.processingTicks > 0;

		if (be.waitingForXp) {
			// PARKED, waiting for experience: sit in place and spin around the X axis (rolling
			// over and over on itself), indefinitely, until experience arrives. No tumble, no
			// travel - it just stays put and rotates on X.
			float spin = (renderTick / 16.0F) % twoPi;
			item.angleX = spin;
			item.angleY = 0.0F;
			item.angleZ = 0.0F;
		} else if (enchanting) {
			// ENCHANTING: a real multi-axis tumble. Which side-axis it rolls on depends on the
			// insertion direction (matches the original), and it always also turns on Y, so the
			// item visibly moves through several orientations rather than flipping on one spot.
			// getClockWise() is only valid for horizontal directions; a hand-inserted item comes
			// from UP, so default it to rolling on the X axis.
			float spin = ((be.processingTicks - partialTicks) / 16.0F) % twoPi;
			boolean rollX = !insertedFrom.getAxis().isHorizontal()
				|| insertedFrom.getClockWise().getAxis() == Direction.Axis.X;
			item.angleX = rollX ? spin : 0.0F;
			item.angleZ = rollX ? 0.0F : spin;
			item.angleY = spin * 0.5F + (transported.angle % 360) / 360.0F * (float) Math.PI;
		} else {
			// Passthrough (riding across, not enchantable): a gentle idle spin on Y.
			float spin = (renderTick / 16.0F) % twoPi;
			item.angleX = 0.0F;
			item.angleY = spin;
			item.angleZ = 0.0F;
		}

		ItemStack itemStack = transported.stack;
		ItemStackRenderState renderState = item.state = new ItemStackRenderState();
		this.itemModelManager.updateForTopItem(renderState, itemStack, ItemDisplayContext.FIXED, be.getLevel(), null, 0);
	}

	@Override
	public void submit(
		BlazeEnchanterRenderState state, PoseStack matrices, SubmitNodeCollector queue, CameraRenderState cameraState
	) {
		super.submit(state, matrices, queue, cameraState);
		// Book first, then the blaze head, then the cage.
		if (state.book != null) {
			queue.submitCustomGeometry(matrices, state.book.layer, state.book);
		}
		if (state.item != null) {
			state.item.render(matrices, queue, state.lightCoords);
		}
		if (state.blaze != null) {
			queue.submitCustomGeometry(matrices, state.blaze.layer, state.blaze);
		}
		if (state.rods != null) {
			queue.submitCustomGeometry(matrices, state.rods.layer, state.rods);
		}
		if (state.rods2 != null) {
			queue.submitCustomGeometry(matrices, state.rods2.layer, state.rods2);
		}
		if (state.cage != null) {
			queue.submitCustomGeometry(matrices, state.cage.layer, state.cage);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class BlazeEnchanterRenderState extends SmartRenderState {
		public BlazeRenderState blaze;
		public BlazeRenderState cage;
		public BlazeRenderState rods;
		public BlazeRenderState rods2;
		public BookRenderState book;
		public HeldItemRenderState item;
	}

	@Environment(EnvType.CLIENT)
	public static class BlazeRenderState implements SubmitNodeCollector.CustomGeometryRenderer {
		public RenderType layer;
		public SuperByteBuffer buffer;
		public float translateY;
		public float angle;

		@Override
		public void render(PoseStack.Pose matricesEntry, VertexConsumer vertexConsumer) {
			buffer.translate(0.0F, translateY, 0.0F);
			buffer.rotateCentered(angle, Direction.UP);
			buffer.light(15728880);
			buffer.renderInto(matricesEntry, vertexConsumer);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class BookRenderState implements SubmitNodeCollector.CustomGeometryRenderer {
		public BookModel model;
		public RenderType layer;
		public float angle;
		public float bob;
		public int light;
		public float animationPos;
		public float pageFlip1;
		public float pageFlip2;
		public float open;

		@Override
		public void render(PoseStack.Pose matricesEntry, VertexConsumer vertexConsumer) {
			// Reconstruct a PoseStack carrying the supplied pose so the entity model can render.
			PoseStack ms = new PoseStack();
			ms.last().pose().set(matricesEntry.pose());
			ms.last().normal().set(matricesEntry.normal());

			// XP(90) lays it flat; the extra YP(90) turns the spine so BOTH covers open UPWARD
			// into a proper open-book V (without it, one cover goes up and the other down).
			// Face the player (track the head), then orient as an open book tilted like an
			// enchanting-table lectern (not flat): a partial backward tilt instead of full 90.
			ms.translate(0.5F, 0.4F, 0.5F);
			ms.mulPose(Axis.YP.rotation(angle));
			ms.mulPose(Axis.XP.rotationDegrees(75.0F));
			ms.mulPose(Axis.YP.rotationDegrees(90.0F));
			ms.scale(1.0F, 1.0F, 1.0F);

			model.setupAnim(new BookModel.State(animationPos, pageFlip1, pageFlip2, open));
			model.renderToBuffer(ms, vertexConsumer, light, OverlayTexture.NO_OVERLAY);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class HeldItemRenderState {
		public ItemStackRenderState state;
		public Vec3 travel;
		public float bob;
		public float angleX;
		public float angleY;
		public float angleZ;

		public void render(PoseStack matrices, SubmitNodeCollector queue, int light) {
			matrices.pushPose();
			matrices.translate(0.5F, 1.05F + bob, 0.5F);
			matrices.translate(travel.x, travel.y, travel.z);
			// Apply the tumble. Y is the upright spin; X/Z roll it over while enchanting.
			matrices.mulPose(Axis.YP.rotation(angleY));
			matrices.mulPose(Axis.XP.rotation(angleX));
			matrices.mulPose(Axis.ZP.rotation(angleZ));
			matrices.scale(0.5F, 0.5F, 0.5F);
			state.submit(matrices, queue, light, OverlayTexture.NO_OVERLAY, 0);
			matrices.popPose();
		}
	}

}
