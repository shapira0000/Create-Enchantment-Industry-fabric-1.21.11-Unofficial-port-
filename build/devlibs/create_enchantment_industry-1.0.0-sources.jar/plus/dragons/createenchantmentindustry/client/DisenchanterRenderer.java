package plus.dragons.createenchantmentindustry.client;

import com.zurrtum.create.catnip.math.VecHelper;
import com.zurrtum.create.client.catnip.render.FluidRenderHelper;
import com.zurrtum.create.client.flywheel.lib.transform.PoseTransformStack;
import com.zurrtum.create.client.flywheel.lib.transform.TransformStack;
import com.zurrtum.create.client.foundation.blockEntity.renderer.SmartBlockEntityRenderer;
import com.zurrtum.create.content.kinetics.belt.BeltHelper;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import plus.dragons.createenchantmentindustry.content.disenchanter.Disenchanting;
import plus.dragons.createenchantmentindustry.content.disenchanter.DisenchanterBlockEntity;

/**
 * Renders the Disenchanter, faithfully reproducing the original 1.20.1 visuals on the new
 * 1.21.11 render-state pipeline. Extends Create Fly's {@link SmartBlockEntityRenderer} (so the
 * base render-state extraction, goggle/link overlays, etc. are handled), and adds: a fluid level
 * inside the casing, the held item moving across an internal belt and spinning while processed,
 * and a swelling experience box around the item during processing. Mirrors Create Fly's own
 * {@code ItemDrainRenderer}.
 */
@Environment(EnvType.CLIENT)
public class DisenchanterRenderer
	extends SmartBlockEntityRenderer<DisenchanterBlockEntity, DisenchanterRenderer.DisenchanterRenderState> {

	public DisenchanterRenderer(BlockEntityRendererProvider.Context context) {
		super(context);
	}

	@Override
	public DisenchanterRenderState createRenderState() {
		return new DisenchanterRenderState();
	}

	@Override
	public void extractRenderState(DisenchanterBlockEntity be, DisenchanterRenderState state, float partialTicks, Vec3 cameraPos, @Nullable ModelFeatureRenderer.CrumblingOverlay crumblingOverlay) {
		super.extractRenderState(be, state, partialTicks, cameraPos, crumblingOverlay);
		updateFluidRenderState(be, state, partialTicks);
		updateItemRenderState(be, state, partialTicks);
	}

	@Override
	public void submit(DisenchanterRenderState state, PoseStack matrices, SubmitNodeCollector queue, CameraRenderState cameraState) {
		super.submit(state, matrices, queue, cameraState);
		if (state.process != null) {
			queue.submitCustomGeometry(matrices, state.process.layer, state.process);
		}
		if (state.item != null) {
			state.item.render(matrices, queue, state.lightCoords);
		}
		if (state.fluid != null) {
			matrices.translate(0.0F, state.fluid.offset, 0.0F);
			queue.submitCustomGeometry(matrices, state.fluid.layer, state.fluid);
		}
	}

	private void updateFluidRenderState(DisenchanterBlockEntity be, DisenchanterRenderState state, float partialTicks) {
		SmartFluidTankBehaviour tank = be.internalTank;
		if (tank == null) {
			return;
		}
		SmartFluidTankBehaviour.TankSegment primaryTank = tank.getPrimaryTank();
		FluidStack fluidStack = primaryTank.getRenderedFluid();
		if (!fluidStack.isEmpty()) {
			float level = primaryTank.getFluidLevel().getValue(partialTicks);
			if (level != 0.0F) {
				float yMax = 0.3125F;
				float min = 0.125F;
				float max = min + 0.75F;
				float yOffset = 0.4375F * level;
				float yMin = yMax - yOffset;
				state.fluid = new FluidRenderState(
					RenderTypes.translucentMovingBlock(), fluidStack.getFluid(), fluidStack.getComponentChanges(),
					min, max, yMin, yMax, yOffset, state.lightCoords
				);
			}
		}

		ItemStack heldItemStack = be.getHeldItemStack();
		if (!heldItemStack.isEmpty() && be.processingTicks != 0) {
			Disenchanting.Result result = Disenchanting.disenchantResult(heldItemStack, be.getLevel());
			if (result != null && !result.experience().isEmpty()) {
				FluidStack xp = result.experience();
				float processingPT = (float) be.processingTicks - partialTicks;
				float processingProgress = Mth.clamp(1.0F - (processingPT - 5.0F) / 10.0F, 0.0F, 1.0F);
				float radius = (float) (Math.pow(2.0F * processingProgress - 1.0F, 2.0) - 1.0);
				AABB box = new AABB(0.5, 1.0, 0.5, 0.5, 0.25, 0.5).inflate(radius / 32.0F);
				state.process = new ProcessRenderState(
					RenderTypes.translucentMovingBlock(), xp.getFluid(), xp.getComponentChanges(), box, state.lightCoords
				);
			}
		}
	}

	private void updateItemRenderState(DisenchanterBlockEntity be, DisenchanterRenderState state, float partialTicks) {
		TransportedItemStack transported = be.heldItem;
		if (transported == null) {
			return;
		}
		Direction insertedFrom = transported.insertedFrom;
		HeldItemRenderState item = state.item = new HeldItemRenderState();
		item.itemPosition = VecHelper.getCenterOf(state.blockPos);
		boolean horizontal = insertedFrom.getAxis().isHorizontal();
		float offset = horizontal ? Mth.lerp(partialTicks, transported.prevBeltPosition, transported.beltPosition) : 0.5F;
		item.offsetVec = Vec3.atLowerCornerOf(insertedFrom.getOpposite().getUnitVec3i()).scale(0.5F - offset);
		if (horizontal) {
			float sideOffset = Mth.lerp(partialTicks, transported.prevSideOffset, transported.sideOffset);
			boolean alongX = insertedFrom.getClockWise().getAxis() == Direction.Axis.X;
			if (!alongX) {
				sideOffset *= -1.0F;
			}
			item.translate = item.offsetVec.add(alongX ? sideOffset : 0.0, 0.0, alongX ? 0.0 : sideOffset);
		} else {
			// Vertical (right-click) insertion: keep the item centered, no side shift.
			item.translate = item.offsetVec;
		}
		ItemStack itemStack = transported.stack;
		item.count = Mth.ceil(itemStack.getCount()) / 2;
		item.upright = BeltHelper.isItemUpright(itemStack);
		item.axis = insertedFrom.getAxis();
		int positive = insertedFrom.getAxisDirection().getStep();
		item.verticalAngle = (float) positive * offset * 360.0F;

		float processingProgress = switch (be.processingTicks) {
			case 0, 10 -> 0.0F;
			default -> Mth.clamp(((float) be.processingTicks - partialTicks) / 10.0F, 0.0F, 1.0F);
		};
		item.spin = processingProgress * 360.0F;

		ItemStackRenderState renderState = item.state = new ItemStackRenderState();
		this.itemModelManager.updateForTopItem(renderState, itemStack, ItemDisplayContext.FIXED, be.getLevel(), null, 0);
	}

	@Environment(EnvType.CLIENT)
	public static class DisenchanterRenderState extends SmartBlockEntityRenderer.SmartRenderState {
		public FluidRenderState fluid;
		public ProcessRenderState process;
		public HeldItemRenderState item;
	}

	@Environment(EnvType.CLIENT)
	public record FluidRenderState(
		RenderType layer, Fluid fluid, DataComponentPatch changes,
		float min, float max, float yMin, float yMax, float offset, int light
	) implements SubmitNodeCollector.CustomGeometryRenderer {
		@Override
		public void render(PoseStack.Pose matricesEntry, VertexConsumer vertexConsumer) {
			FluidRenderHelper.renderFluidBox(
				fluid, changes, min, yMin, min, max, yMax, max, vertexConsumer, matricesEntry, light, false, false
			);
		}
	}

	@Environment(EnvType.CLIENT)
	public record ProcessRenderState(RenderType layer, Fluid fluid, DataComponentPatch changes, AABB box, int light)
		implements SubmitNodeCollector.CustomGeometryRenderer {
		@Override
		public void render(PoseStack.Pose matricesEntry, VertexConsumer vertexConsumer) {
			FluidRenderHelper.renderFluidBox(
				fluid, changes,
				(float) box.minX, (float) box.minY, (float) box.minZ,
				(float) box.maxX, (float) box.maxY, (float) box.maxZ,
				vertexConsumer, matricesEntry, light, true, false
			);
		}
	}

	@Environment(EnvType.CLIENT)
	public static class HeldItemRenderState {
		public ItemStackRenderState state;
		public Vec3 itemPosition;
		public Vec3 translate;
		public Vec3 offsetVec;
		public int count;
		public boolean upright;
		public Direction.Axis axis;
		public float verticalAngle;
		public float spin;

		public void render(PoseStack matrices, SubmitNodeCollector queue, int light) {
			PoseTransformStack msr = TransformStack.of(matrices);
			matrices.pushPose();
			matrices.translate(0.5F, 0.8125F, 0.5F);
			msr.nudge(0);
			matrices.translate(translate);

			if (axis != Direction.Axis.X) {
				msr.rotateXDegrees(verticalAngle);
			}
			if (axis != Direction.Axis.Z) {
				msr.rotateZDegrees(-verticalAngle);
			}
			msr.rotateYDegrees(spin);

			Random r = new Random(0L);
			boolean blockItem = state.usesBlockLight();

			for (int i = 0; i <= count; i++) {
				matrices.pushPose();
				if (blockItem) {
					matrices.translate(r.nextFloat() * 0.0625F * i, 0.0F, r.nextFloat() * 0.0625F * i);
				}
				matrices.scale(0.5F, 0.5F, 0.5F);
				if (!blockItem) {
					msr.rotateXDegrees(90.0F);
				}
				state.submit(matrices, queue, light, OverlayTexture.NO_OVERLAY, 0);
				matrices.popPose();
				if (!blockItem) {
					msr.rotateYDegrees(10.0F);
				}
				matrices.translate(0.0, blockItem ? 0.015625 : 0.0625, 0.0);
			}
			matrices.popPose();
		}
	}
}
