package plus.dragons.createenchantmentindustry.content.disenchanter;

import com.zurrtum.create.AllShapes;
import com.zurrtum.create.content.equipment.wrench.IWrenchable;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.foundation.block.IBE;
import com.zurrtum.create.foundation.blockEntity.ComparatorUtil;
import com.zurrtum.create.infrastructure.fluids.FluidInventory;
import com.zurrtum.create.infrastructure.fluids.FluidInventoryProvider;
import com.zurrtum.create.infrastructure.items.ItemInventoryProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import plus.dragons.createenchantmentindustry.registry.CeiBlockEntities;

/**
 * The Disenchanter block. Built on Create Fly's {@code ItemDrainBlock}: {@link IWrenchable}
 * for wrench pickup, {@link IBE} binding to {@link DisenchanterBlockEntity}, and the
 * inventory provider hooks so Create's belts and fluid pipes can interact with it.
 */
public class DisenchanterBlock extends Block
	implements IWrenchable,
	IBE<DisenchanterBlockEntity>,
	ItemInventoryProvider<DisenchanterBlockEntity>,
	FluidInventoryProvider<DisenchanterBlockEntity> {

	public DisenchanterBlock(Properties properties) {
		super(properties);
	}

	@Override
	public Container getInventory(LevelAccessor world, BlockPos pos, BlockState state, DisenchanterBlockEntity be, Direction context) {
		return context != null && context.getAxis().isHorizontal() ? be.itemHandlers.get(context) : null;
	}

	@Override
	public FluidInventory getFluidInventory(LevelAccessor world, BlockPos pos, BlockState state, DisenchanterBlockEntity be, Direction context) {
		return be.internalTank.getCapability();
	}

	@Override
	protected InteractionResult useItemOn(
		ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult
	) {
		if (hand == InteractionHand.OFF_HAND) {
			return InteractionResult.PASS;
		}
		if (stack.isEmpty()) {
			return onBlockEntityUseItemOn(level, pos, be -> {
				if (be.getHeldItemStack().isEmpty()) {
					return InteractionResult.PASS;
				}
				if (!level.isClientSide()) {
					player.setItemInHand(hand, be.heldItem.stack);
					be.heldItem = null;
					be.notifyUpdate();
				}
				return InteractionResult.SUCCESS;
			});
		}
		if (hitResult.getDirection() != Direction.UP) {
			return InteractionResult.PASS;
		}
		return onBlockEntityUseItemOn(level, pos, be -> {
			if (!be.getHeldItemStack().isEmpty()) {
				return InteractionResult.PASS;
			}
			ItemStack insert = stack.copy();
			insert.setCount(1);
			// Experience Nugget / Block convert instantly and only via belt insertion -
			// they must not be insertable by hand (matches the original CEI).
			if (Disenchanting.instantConversionUnitsPerItem(insert) > 0) {
				return InteractionResult.PASS;
			}
			if (Disenchanting.disenchantResult(insert, level) == null) {
				return InteractionResult.PASS;
			}
			if (!level.isClientSide()) {
				be.heldItem = new TransportedItemStack(insert);
				be.notifyUpdate();
				stack.shrink(1);
			}
			return InteractionResult.SUCCESS;
		});
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
		return AllShapes.CASING_13PX.get(Direction.UP);
	}

	@Override
	public Class<DisenchanterBlockEntity> getBlockEntityClass() {
		return DisenchanterBlockEntity.class;
	}

	@Override
	public BlockEntityType<? extends DisenchanterBlockEntity> getBlockEntityType() {
		return CeiBlockEntities.DISENCHANTER;
	}

	@Override
	public boolean hasAnalogOutputSignal(BlockState state) {
		return true;
	}

	@Override
	public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos, Direction direction) {
		return ComparatorUtil.levelOfSmartFluidTank(level, pos);
	}

	@Override
	protected boolean isPathfindable(BlockState state, PathComputationType type) {
		return false;
	}
}
