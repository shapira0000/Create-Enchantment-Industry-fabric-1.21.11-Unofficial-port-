package plus.dragons.createenchantmentindustry.content.disenchanter;

import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.infrastructure.items.ItemInventory;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;

/**
 * The item-insertion face of the Disenchanter, one per horizontal side.
 *
 * <p>Modelled on Create Fly's {@code ItemDrainItemHandler}: it implements the simple
 * {@link ItemInventory} interface (a single-slot inventory) rather than the heavier
 * transfer-API plumbing the original 1.20.1 mod used. Inserting an item hands it to the
 * block entity as a {@link TransportedItemStack}; the block entity then runs it across
 * its internal "belt" and disenchants it at the halfway point.</p>
 */
public class DisenchanterItemHandler implements ItemInventory {
	private final DisenchanterBlockEntity blockEntity;
	private final Direction side;

	public DisenchanterItemHandler(DisenchanterBlockEntity be, Direction side) {
		this.blockEntity = be;
		this.side = side.getOpposite();
	}

	@Override
	public int getContainerSize() {
		return 1;
	}

	@Override
	public int getMaxStackSize(ItemStack stack) {
		return stack.getMaxStackSize();
	}

	@Override
	public boolean canPlaceItem(int slot, ItemStack stack) {
		return blockEntity.getHeldItemStack().isEmpty();
	}

	@Override
	public ItemStack getItem(int slot) {
		return slot > 1 ? ItemStack.EMPTY : blockEntity.getHeldItemStack();
	}

	@Override
	public void setItem(int slot, ItemStack stack) {
		if (slot <= 1) {
			if (stack.isEmpty()) {
				blockEntity.heldItem = null;
			} else {
				TransportedItemStack heldItem = new TransportedItemStack(stack);
				heldItem.prevBeltPosition = 0.0F;
				blockEntity.setHeldItem(heldItem, side);
			}
		}
	}

	@Override
	public void setChanged() {
		blockEntity.notifyUpdate();
	}
}
