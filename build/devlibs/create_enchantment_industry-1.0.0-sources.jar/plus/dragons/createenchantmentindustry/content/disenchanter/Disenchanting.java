package plus.dragons.createenchantmentindustry.content.disenchanter;

import com.zurrtum.create.AllItems;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;

/**
 * Core disenchanting logic: turning an enchanted item into Liquid Experience and a
 * cleaned-up item, ported to the 1.21.11 enchantment API.
 *
 * <h2>What changed from the original 1.20.1 implementation</h2>
 * The original CEI stored enchantments as NBT tags and used now-removed APIs
 * ({@code EnchantmentHelper.getEnchantments} returning a {@code Map}, {@code Enchantment#isCurse}).
 * In 1.21.11 enchantments live in {@link DataComponents#ENCHANTMENTS} /
 * {@link DataComponents#STORED_ENCHANTMENTS} as an {@link ItemEnchantments} component whose
 * keys are {@link Holder}&lt;{@link Enchantment}&gt;, and "curse" is the tag
 * {@link EnchantmentTags#CURSE} rather than a method. This class is rewritten around that.
 *
 * <h2>Fluid amounts</h2>
 * Amounts are in Create Fly fluid units; {@link EnchantmentIndustry#UNIT_PER_MB} (81) units
 * equal one experience point, matching the original ratio.
 */
public class Disenchanting {

	/**
	 * Compute the result of disenchanting an item, or {@code null} if it can't be disenchanted.
	 *
	 * @return a pair of (experience fluid produced, resulting cleaned item), or {@code null}
	 */
	@Nullable
	public static Result disenchantResult(ItemStack itemStack, Level level) {
		// Special "experience" inputs that the original CEI handles via disenchanting recipes.
		// Amounts mirror the original recipe JSONs (in mB; multiplied by UNIT_PER_MB for fluid units).
		Result special = specialDisenchantResult(itemStack);
		if (special != null) {
			return special;
		}

		ItemEnchantments enchantments = getEnchantments(itemStack);
		// Only proceed if the item carries at least one non-curse enchantment.
		boolean hasRemovable = enchantments.keySet().stream().anyMatch(holder -> !isCurse(holder));
		if (!hasRemovable) {
			return null;
		}
		int experience = getDisenchantExperience(itemStack);
		ItemStack result = disenchant(itemStack);
		FluidStack xp = new FluidStack(CeiFluids.EXPERIENCE.still, experience);
		return new Result(xp, result);
	}

	/**
	 * Handles the fixed "experience" inputs the original CEI disenchants directly into fluid:
	 * the Experience Nugget (3 mB), Experience Block (27 mB), and Enchanted Golden Apple
	 * (a Golden Apple back + 100 mB). Returns null for anything else.
	 */
	/**
	 * For "experience" items that convert instantly with no leftover (Experience Nugget,
	 * Experience Block): returns the per-item fluid amount in units. Returns 0 otherwise.
	 * The Enchanted Golden Apple is NOT included here because it leaves a Golden Apple behind,
	 * so it goes through the normal animated belt flow.
	 */
	public static int instantConversionUnitsPerItem(ItemStack itemStack) {
		if (itemStack.is(AllItems.EXP_NUGGET)) {
			return 3 * EnchantmentIndustry.UNIT_PER_MB;
		} else if (itemStack.is(AllItems.EXPERIENCE_BLOCK)) {
			return 27 * EnchantmentIndustry.UNIT_PER_MB;
		}
		return 0;
	}

	@Nullable
	private static Result specialDisenchantResult(ItemStack itemStack) {
		int mb = 0;
		ItemStack leftover = ItemStack.EMPTY;
		if (itemStack.is(AllItems.EXP_NUGGET)) {
			mb = 3;
		} else if (itemStack.is(AllItems.EXPERIENCE_BLOCK)) {
			mb = 27;
		} else if (itemStack.is(Items.ENCHANTED_GOLDEN_APPLE)) {
			mb = 100;
			leftover = new ItemStack(Items.GOLDEN_APPLE);
		} else {
			return null;
		}
		FluidStack xp = new FluidStack(CeiFluids.EXPERIENCE.still, mb * EnchantmentIndustry.UNIT_PER_MB);
		return new Result(xp, leftover);
	}

	/**
	 * Produce a copy of the item with all non-curse enchantments stripped.
	 * Curses are deliberately preserved (you can't cleanse a curse by disenchanting).
	 * An enchanted book that ends up with no enchantments becomes a plain book.
	 */
	public static ItemStack disenchant(ItemStack itemStack) {
		ItemStack result = itemStack.copy();

		boolean isStored = result.has(DataComponents.STORED_ENCHANTMENTS);
		ItemEnchantments current = getEnchantments(result);

		// Keep only curses.
		ItemEnchantments.Mutable builder = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
		boolean keptAny = false;
		for (Holder<Enchantment> holder : current.keySet()) {
			if (isCurse(holder)) {
				builder.set(holder, current.getLevel(holder));
				keptAny = true;
			}
		}
		ItemEnchantments remaining = builder.toImmutable();

		// An enchanted book with nothing left becomes a normal book.
		if (result.is(Items.ENCHANTED_BOOK) && !keptAny) {
			ItemStack book = new ItemStack(Items.BOOK);
			book.setCount(result.getCount());
			return book;
		}

		if (isStored) {
			result.set(DataComponents.STORED_ENCHANTMENTS, remaining);
		} else {
			result.set(DataComponents.ENCHANTMENTS, remaining);
		}
		// Reset the prior-work penalty so the cleaned item is cheap to use again.
		result.remove(DataComponents.REPAIR_COST);
		return result;
	}

	/**
	 * The experience (in fluid units) yielded by an item's non-curse enchantments.
	 * Mirrors the original formula: sum of each enchantment's minimum cost at its level,
	 * times 0.75 (rounded up), converted to fluid units.
	 */
	public static int getDisenchantExperience(ItemStack itemStack) {
		ItemEnchantments enchantments = getEnchantments(itemStack);
		int xp = 0;
		for (Holder<Enchantment> holder : enchantments.keySet()) {
			if (isCurse(holder)) {
				continue;
			}
			int level = enchantments.getLevel(holder);
			xp += holder.value().getMinCost(level);
		}
		if (xp == 0) {
			return 0;
		}
		return Mth.ceil(xp * 0.75) * EnchantmentIndustry.UNIT_PER_MB;
	}

	/** Read whichever enchantment component the item uses (stored for books, normal otherwise). */
	private static ItemEnchantments getEnchantments(ItemStack stack) {
		if (stack.has(DataComponents.STORED_ENCHANTMENTS)) {
			return stack.get(DataComponents.STORED_ENCHANTMENTS);
		}
		return EnchantmentHelper.getEnchantmentsForCrafting(stack);
	}

	/** A curse in 1.21.11 is any enchantment tagged {@link EnchantmentTags#CURSE}. */
	private static boolean isCurse(Holder<Enchantment> holder) {
		return holder.is(EnchantmentTags.CURSE);
	}

	/** Result of a disenchant operation: the experience fluid and the cleaned item. */
	public record Result(FluidStack experience, ItemStack item) {
	}
}
