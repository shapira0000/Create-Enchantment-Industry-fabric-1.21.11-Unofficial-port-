package plus.dragons.createenchantmentindustry.content.disenchanter;

import com.zurrtum.create.api.behaviour.BlockEntityBehaviour;
import com.zurrtum.create.catnip.data.Iterate;
import com.zurrtum.create.catnip.math.VecHelper;
import com.zurrtum.create.content.kinetics.belt.behaviour.DirectBeltInputBehaviour;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.foundation.blockEntity.SmartBlockEntity;
import com.zurrtum.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.zurrtum.create.foundation.utility.BlockHelper;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import plus.dragons.createenchantmentindustry.content.fluids.experience.ExperienceFluid;
import plus.dragons.createenchantmentindustry.registry.CeiConfig;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;

/**
 * The Disenchanter's block entity.
 *
 * <p>Structurally modelled on Create Fly's {@code ItemDrainBlockEntity}: an item is inserted,
 * carried across an internal "belt", and processed at the halfway point. Where Item Drain
 * empties a fluid item into its tank, the Disenchanter strips an item's enchantments (see
 * {@link Disenchanting}) and fills its internal tank with the resulting Liquid Experience.</p>
 *
 * <p>Clean core. Deferred for later: absorbing XP from nearby players, advancements, goggle info.</p>
 */
public class DisenchanterBlockEntity extends SmartBlockEntity {
	public static final int DISENCHANTER_TIME = 10;

	public SmartFluidTankBehaviour internalTank;
	public TransportedItemStack heldItem;
	public int processingTicks;
	protected AABB absorbArea;
	public Map<Direction, DisenchanterItemHandler> itemHandlers = new IdentityHashMap<>();

	public DisenchanterBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		super(type, pos, state);
		for (Direction d : Iterate.horizontalDirections) {
			itemHandlers.put(d, new DisenchanterItemHandler(this, d));
		}
		this.absorbArea = new AABB(pos.above());
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour<?>> behaviours) {
		behaviours.add(new DirectBeltInputBehaviour(this).allowingBeltFunnels().setInsertionHandler(this::tryInsertingFromSide));
		int capacity = CeiConfig.disenchanterTankCapacityUnits();
		behaviours.add(
			this.internalTank = SmartFluidTankBehaviour.single(this, capacity).allowExtraction().forbidInsertion()
		);
	}

	@Override
	public void destroy() {
		super.destroy();
		ItemStack heldItemStack = getHeldItemStack();
		if (!heldItemStack.isEmpty()) {
			Containers.dropItemStack(level, worldPosition.getX(), worldPosition.getY(), worldPosition.getZ(), heldItemStack);
		}
		// Spill any stored experience back into the world as orbs.
		if (level instanceof ServerLevel serverLevel) {
			FluidStack fluid = internalTank.getPrimaryHandler().getFluid();
			if (fluid.getFluid() instanceof ExperienceFluid expFluid && !fluid.isEmpty()) {
				expFluid.drop(serverLevel, VecHelper.getCenterOf(worldPosition), fluid.getAmount());
			}
		}
	}

	private ItemStack tryInsertingFromSide(TransportedItemStack transportedStack, Direction side, boolean simulate) {
		ItemStack inserted = transportedStack.stack;
		ItemStack returned = ItemStack.EMPTY;
		if (!getHeldItemStack().isEmpty()) {
			return inserted;
		}

		// Instant-conversion items (Experience Nugget / Block): convert the WHOLE stack to fluid
		// immediately, with no held-item animation. Faithful to the original CEI behaviour.
		int unitsPerItem = Disenchanting.instantConversionUnitsPerItem(inserted);
		if (unitsPerItem > 0) {
			if (level.isClientSide()) {
				return ItemStack.EMPTY;
			}
			int count = inserted.getCount();
			int total = unitsPerItem * count;
			FluidStack xp = new FluidStack(CeiFluids.EXPERIENCE.still, total);
			internalTank.allowInsertion();
			int room = internalTank.getPrimaryHandler().countSpace(xp);
			int acceptCount = unitsPerItem > 0 ? Math.min(count, room / unitsPerItem) : 0;
			if (acceptCount <= 0) {
				internalTank.forbidInsertion();
				return inserted; // tank full - reject so the belt holds the item
			}
			if (simulate) {
				internalTank.forbidInsertion();
				return inserted.copyWithCount(count - acceptCount);
			}
			internalTank.getPrimaryHandler().insert(new FluidStack(CeiFluids.EXPERIENCE.still, unitsPerItem * acceptCount));
			internalTank.forbidInsertion();
			level.levelEvent(1042, worldPosition, 0);
			setChanged();
			sendData();
			return inserted.copyWithCount(count - acceptCount);
		}

		if (Disenchanting.disenchantResult(inserted, level) == null) {
			return inserted;
		}
		if (inserted.getCount() > 1) {
			returned = inserted.copyWithCount(inserted.getCount() - 1);
			inserted = inserted.copyWithCount(1);
		}
		if (simulate) {
			return returned;
		}
		transportedStack = transportedStack.copy();
		transportedStack.stack = inserted.copy();
		transportedStack.beltPosition = side.getAxis().isVertical() ? 0.5F : 0.0F;
		transportedStack.prevSideOffset = transportedStack.sideOffset;
		transportedStack.prevBeltPosition = transportedStack.beltPosition;
		setHeldItem(transportedStack, side);
		setChanged();
		sendData();
		return returned;
	}

	public ItemStack getHeldItemStack() {
		return heldItem == null ? ItemStack.EMPTY : heldItem.stack;
	}

	@Override
	public void tick() {
		super.tick();
		if (level instanceof ServerLevel serverLevel && level.getGameTime() % 10L == 0L) {
			absorbExperienceFromWorld(serverLevel);
		}
		if (heldItem == null) {
			processingTicks = 0;
			return;
		}
		boolean onClient = level.isClientSide() && !isVirtual();
		if (processingTicks > 0) {
			heldItem.prevBeltPosition = 0.5F;
			boolean wasAtBeginning = processingTicks == DISENCHANTER_TIME;
			if (!onClient || processingTicks < DISENCHANTER_TIME) {
				processingTicks--;
			}
			if (!continueProcessing()) {
				processingTicks = 0;
				notifyUpdate();
			} else if (wasAtBeginning != (processingTicks == DISENCHANTER_TIME)) {
				sendData();
			}
			return;
		}

		heldItem.prevBeltPosition = heldItem.beltPosition;
		heldItem.prevSideOffset = heldItem.sideOffset;
		heldItem.beltPosition += itemMovementPerTick();

		if (heldItem.beltPosition > 1.0F) {
			heldItem.beltPosition = 1.0F;
			if (!onClient) {
				exportItem();
			}
		} else if (heldItem.prevBeltPosition < 0.5F && heldItem.beltPosition >= 0.5F) {
			if (Disenchanting.disenchantResult(heldItem.stack.copy(), level) == null) {
				return;
			}
			heldItem.beltPosition = 0.5F;
			if (onClient) {
				return;
			}
			processingTicks = DISENCHANTER_TIME;
			sendData();
		}
	}

	/** Push the finished item out to the far side, or eject it into the world. */
	private void exportItem() {
		Direction side = heldItem.insertedFrom;
		ItemStack tryExport = getBehaviour(DirectBeltInputBehaviour.TYPE)
			.tryExportingToBeltFunnel(heldItem.stack, side.getOpposite(), false);
		if (tryExport != null) {
			if (tryExport.getCount() != heldItem.stack.getCount()) {
				if (tryExport.isEmpty()) {
					heldItem = null;
				} else {
					heldItem.stack = tryExport;
				}
				notifyUpdate();
				return;
			}
			if (!tryExport.isEmpty()) {
				return;
			}
		}

		BlockPos nextPosition = worldPosition.relative(side);
		DirectBeltInputBehaviour next = BlockEntityBehaviour.get(level, nextPosition, DirectBeltInputBehaviour.TYPE);
		if (next == null) {
			if (!BlockHelper.hasBlockSolidSide(level.getBlockState(nextPosition), level, nextPosition, side.getOpposite())) {
				ItemStack ejected = heldItem.stack;
				Vec3 outPos = VecHelper.getCenterOf(worldPosition).add(Vec3.atLowerCornerOf(side.getUnitVec3i()).scale(0.75));
				float speed = itemMovementPerTick();
				Vec3 outMotion = Vec3.atLowerCornerOf(side.getUnitVec3i()).scale(speed).add(0.0, 0.125, 0.0);
				outPos.add(outMotion.normalize());
				ItemEntity entity = new ItemEntity(level, outPos.x, outPos.y + 0.375, outPos.z, ejected);
				entity.setDeltaMovement(outMotion);
				entity.setDefaultPickUpDelay();
				level.addFreshEntity(entity);
				heldItem = null;
				notifyUpdate();
			}
		} else if (next.canInsertFromSide(side)) {
			ItemStack returned = next.handleInsertion(heldItem.copy(), side, false);
			if (returned.isEmpty()) {
				heldItem = null;
				notifyUpdate();
			} else if (returned.getCount() != heldItem.stack.getCount()) {
				heldItem.stack = returned;
				notifyUpdate();
			}
		}
	}

	/** Perform the disenchant mid-belt, filling the internal tank. */
	protected boolean continueProcessing() {
		if (level.isClientSide() && !isVirtual()) {
			return true;
		}
		if (processingTicks < 5) {
			return true;
		}
		if (heldItem.stack.getCount() <= 0) {
			return false;
		}
		Disenchanting.Result result = Disenchanting.disenchantResult(heldItem.stack, level);
		if (result == null) {
			return false;
		}

		int perItem = result.experience().getAmount();
		int total = perItem * heldItem.stack.getCount();
		FluidStack xp = new FluidStack(result.experience().getFluid(), total);

		if (processingTicks > 5) {
			internalTank.allowInsertion();
			boolean noRoom = internalTank.getPrimaryHandler().countSpace(xp) != total;
			internalTank.forbidInsertion();
			if (noRoom) {
				processingTicks = DISENCHANTER_TIME;
			}
			return true;
		}

		ItemStack resultItem = result.item();
		internalTank.allowInsertion();
		internalTank.getPrimaryHandler().insert(xp);
		internalTank.forbidInsertion();
		level.levelEvent(1042, worldPosition, 0);
		if (resultItem.isEmpty()) {
			// The input was fully consumed (e.g. an experience nugget/block) - nothing to export.
			heldItem = null;
		} else {
			resultItem.setCount(heldItem.stack.getCount());
			heldItem.stack = resultItem;
		}
		notifyUpdate();
		return true;
	}

	/**
	 * Pull experience from the player(s) standing on top of the block, and from any
	 * experience orbs in the space above it, converting it into stored Liquid Experience.
	 * Faithful to the original CEI behaviour, using the simpler Create Fly fluid insert API
	 * and the 1.21.11 ExperienceOrb getValue/setValue accessors.
	 */
	protected void absorbExperienceFromWorld(ServerLevel serverLevel) {
		ExperienceFluid expFluid = (ExperienceFluid) plus.dragons.createenchantmentindustry.registry.CeiFluids.EXPERIENCE.still;

		// --- Players standing on top ---
		List<Player> players = serverLevel.getEntitiesOfClass(Player.class, absorbArea, LivingEntity::isAlive);
		if (!players.isEmpty()) {
			int sum = 0;
			for (Player player : players) {
				int xp = getPlayerExperience(player);
				if (xp >= 100) {
					sum += 100;
				} else if (xp != 0) {
					sum += xp;
				}
			}
			if (sum != 0) {
				FluidStack fluidStack = new FluidStack(expFluid, sum * plus.dragons.createenchantmentindustry.EnchantmentIndustry.UNIT_PER_MB);
				internalTank.allowInsertion();
				int insertedUnits = internalTank.getPrimaryHandler().insert(fluidStack);
				internalTank.forbidInsertion();
				int inserted = insertedUnits / plus.dragons.createenchantmentindustry.EnchantmentIndustry.UNIT_PER_MB;
				if (inserted != 0) {
					for (Player player : players) {
						if (inserted <= 0) {
							break;
						}
						int total = getPlayerExperience(player);
						int take = Math.min(total, Math.min(inserted, 100));
						if (take > 0) {
							player.giveExperiencePoints(-take);
							inserted -= take;
						}
					}
				}
			}
		}

		// --- Loose experience orbs above the block ---
		List<ExperienceOrb> orbs = serverLevel.getEntitiesOfClass(ExperienceOrb.class, absorbArea);
		for (ExperienceOrb orb : orbs) {
			int amount = orb.getValue();
			if (amount <= 0) {
				continue;
			}
			FluidStack fluidStack = new FluidStack(expFluid, amount * plus.dragons.createenchantmentindustry.EnchantmentIndustry.UNIT_PER_MB);
			internalTank.allowInsertion();
			int insertedUnits = internalTank.getPrimaryHandler().insert(fluidStack);
			internalTank.forbidInsertion();
			int inserted = insertedUnits / plus.dragons.createenchantmentindustry.EnchantmentIndustry.UNIT_PER_MB;
			if (inserted >= amount) {
				orb.discard();
			} else if (inserted > 0) {
				// Partially absorbed: replace the orb with one holding the remaining value
				// (avoids ExperienceOrb.setValue, which is private).
				double ox = orb.getX();
				double oy = orb.getY();
				double oz = orb.getZ();
				orb.discard();
				serverLevel.addFreshEntity(new ExperienceOrb(serverLevel, ox, oy, oz, amount - inserted));
				break; // tank full after this
			} else {
				break; // tank full
			}
		}
	}

	/** Total experience points a player currently holds (levels + progress bar). */
	private int getPlayerExperience(Player player) {
		int level = player.experienceLevel;
		if (player.experienceLevel == 0 && player.experienceProgress == 0.0F) {
			return 0;
		}
		int total = plus.dragons.createenchantmentindustry.content.enchanter.Enchanting.expPointFromLevel(level);
		int bar = (int) (total + player.experienceProgress * player.getXpNeededForNextLevel());
		return Math.max(bar, 1);
	}

		private float itemMovementPerTick() {
		return 0.125F;
	}

	public SmartFluidTankBehaviour getInternalTank() {
		return internalTank;
	}

	public void setHeldItem(TransportedItemStack heldItem, Direction insertedFrom) {
		this.heldItem = heldItem;
		this.heldItem.insertedFrom = insertedFrom;
	}

	@Override
	public void write(ValueOutput view, boolean clientPacket) {
		view.putInt("ProcessingTicks", processingTicks);
		if (heldItem != null) {
			view.store("HeldItem", TransportedItemStack.CODEC, heldItem);
		}
		super.write(view, clientPacket);
	}

	@Override
	protected void read(ValueInput view, boolean clientPacket) {
		heldItem = null;
		processingTicks = view.getIntOr("ProcessingTicks", 0);
		heldItem = view.read("HeldItem", TransportedItemStack.CODEC).orElse(null);
		super.read(view, clientPacket);
	}
}
