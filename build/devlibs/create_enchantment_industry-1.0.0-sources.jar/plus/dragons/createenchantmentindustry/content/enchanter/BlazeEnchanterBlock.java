package plus.dragons.createenchantmentindustry.content.enchanter;

import com.zurrtum.create.AllShapes;
import com.zurrtum.create.content.equipment.wrench.IWrenchable;
import com.zurrtum.create.foundation.block.IBE;
import com.zurrtum.create.foundation.blockEntity.ComparatorUtil;
import com.zurrtum.create.infrastructure.fluids.FluidInventory;
import com.zurrtum.create.infrastructure.fluids.FluidInventoryProvider;
import com.zurrtum.create.infrastructure.items.ItemInventoryProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.Container;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import com.mojang.serialization.MapCodec;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.AllBlocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;

import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import plus.dragons.createenchantmentindustry.registry.CeiBlockEntities;

/**
 * The Blaze Enchanter block. Stage 1: a functional Create-integrated block (belts + fluid pipes)
 * built on the same foundation as the Disenchanter. Heat levels, the floating book renderer, and
 * the Enchanting Guide GUI are layered on in later stages.
 *
 * <p>Kept as a plain {@link Block} for now (no directional state) to keep stage 1 simple; the
 * original is a HorizontalDirectionalBlock, which we can switch to when the renderer needs facing.</p>
 */
public class BlazeEnchanterBlock extends HorizontalDirectionalBlock
	implements IWrenchable,
	IBE<BlazeEnchanterBlockEntity>,
	ItemInventoryProvider<BlazeEnchanterBlockEntity>,
	FluidInventoryProvider<BlazeEnchanterBlockEntity> {

	public static final MapCodec<BlazeEnchanterBlock> CODEC = simpleCodec(BlazeEnchanterBlock::new);

	public BlazeEnchanterBlock(Properties properties) {
		super(properties);
		registerDefaultState(defaultBlockState().setValue(FACING, Direction.SOUTH));
	}

	@Override
	protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
		return CODEC;
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	@Override
	public Container getInventory(LevelAccessor world, BlockPos pos, BlockState state, BlazeEnchanterBlockEntity be, Direction context) {
		return context != null && context.getAxis().isHorizontal() ? be.itemHandlers.get(context) : null;
	}

	@Override
	public FluidInventory getFluidInventory(LevelAccessor world, BlockPos pos, BlockState state, BlazeEnchanterBlockEntity be, Direction context) {
		return be.internalTank.getCapability();
	}

	@Override
	protected InteractionResult useItemOn(
		ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult
	) {
		if (hand == InteractionHand.OFF_HAND) {
			return InteractionResult.PASS;
		}
		// Shift + right-click with an empty hand opens the guide screen so you can change the
		// enchantment. (Shift + wrench reverts to a Blaze Burner - see onSneakWrenched.)
		if (player.isShiftKeyDown() && stack.isEmpty()) {
			return onBlockEntityUseItemOn(level, pos, be -> {
				if (be.targetItem.isEmpty()) {
					return InteractionResult.PASS;
				}
				if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
					be.openGuideScreen(serverPlayer);
				}
				return InteractionResult.SUCCESS;
			});
		}
		// Plain right-click with an item: insert ONE into the enchanter so it processes with the
		// over-the-block animation (taken from your hand). UNLIKE belt input, a hand-inserted item
		// must actually be enchantable with the current guide - if it can't be enchanted (wrong
		// type, already has it, no guide) we reject the click entirely so it's never taken in and
		// spat back out. (Passthrough only happens for items arriving on a belt.)
		if (!stack.isEmpty() && !player.isShiftKeyDown()) {
			if (hitResult.getDirection() != Direction.UP) {
				return InteractionResult.PASS;
			}
			return onBlockEntityUseItemOn(level, pos, be -> {
				if (be.targetItem.isEmpty()) {
					return InteractionResult.PASS;
				}
				if (!be.getHeldItemStack().isEmpty()) {
					return InteractionResult.PASS; // already holding something
				}
				// Only take the item if it can actually be enchanted.
				if (!Enchanting.getValidEnchantment(stack, be.targetItem, be.hyper()).valid()) {
					return InteractionResult.PASS;
				}
				if (!level.isClientSide()) {
					ItemStack insert = stack.copy();
					insert.setCount(1);
					be.heldItem = new TransportedItemStack(insert);
					be.notifyUpdate();
					stack.shrink(1);
				}
				return InteractionResult.SUCCESS;
			});
		}
		// Empty-handed plain right-click: retrieve whatever is currently held/processing.
		if (stack.isEmpty() && !player.isShiftKeyDown()) {
			return onBlockEntityUseItemOn(level, pos, be -> {
				if (be.getHeldItemStack().isEmpty()) {
					return InteractionResult.PASS;
				}
				if (!level.isClientSide()) {
					player.setItemInHand(hand, be.getHeldItemStack());
					be.heldItem = null;
					be.notifyUpdate();
				}
				return InteractionResult.SUCCESS;
			});
		}
		return InteractionResult.PASS;
	}

	@Override
	public InteractionResult onSneakWrenched(BlockState state, UseOnContext context) {
		Level level = context.getLevel();
		BlockPos pos = context.getClickedPos();
		if (!level.isClientSide()) {
			BlockEntity be = level.getBlockEntity(pos);
			ItemStack guide = ItemStack.EMPTY;
			if (be instanceof BlazeEnchanterBlockEntity bee) {
				guide = bee.targetItem;
				bee.setTargetItem(ItemStack.EMPTY);
			}
			// Revert to a normal Blaze Burner that still holds its blaze (SMOULDERING heat), facing
			// the same way - NOT the empty one and NOT the flaming LIT block.
			Direction facing = state.hasProperty(FACING) ? state.getValue(FACING) : Direction.SOUTH;
			BlockState burner = AllBlocks.BLAZE_BURNER.defaultBlockState()
				.setValue(com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HEAT_LEVEL,
					com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HeatLevel.SMOULDERING)
				.setValue(HorizontalDirectionalBlock.FACING, facing);
			level.setBlockAndUpdate(pos, burner);
			// Drop the guide back to the player (or the world).
			if (!guide.isEmpty()) {
				if (context.getPlayer() != null) {
					context.getPlayer().getInventory().placeItemBackInInventory(guide);
				} else {
					Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), guide);
				}
			}
			IWrenchable.playRemoveSound(level, pos);
		}
		return InteractionResult.SUCCESS;
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
		return AllShapes.CASING_13PX.get(Direction.UP);
	}

	@Override
	public Class<BlazeEnchanterBlockEntity> getBlockEntityClass() {
		return BlazeEnchanterBlockEntity.class;
	}

	@Override
	public BlockEntityType<? extends BlazeEnchanterBlockEntity> getBlockEntityType() {
		return CeiBlockEntities.BLAZE_ENCHANTER;
	}

	@Override
	public boolean hasAnalogOutputSignal(BlockState state) {
		return true;
	}

	@Override
	public int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos, Direction direction) {
		return ComparatorUtil.levelOfSmartFluidTank(level, pos);
	}

	@Override
	protected boolean isPathfindable(BlockState state, PathComputationType type) {
		return false;
	}
}
