package plus.dragons.createenchantmentindustry.content.enchanter;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import com.zurrtum.create.AllBlocks;
import plus.dragons.createenchantmentindustry.registry.CeiBlocks;
import com.zurrtum.create.foundation.gui.menu.MenuProvider;
import com.zurrtum.create.foundation.gui.menu.MenuBase;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.RegistryFriendlyByteBuf;


/**
 * The Enchanting Guide. Stage 1 (no GUI yet): right-click an enchanted book in your hand to
 * "load" it into the guide (stored in the {@link DataComponents#STORED_ENCHANTMENTS} component
 * of the guide itself), then set the guide as the Blaze Enchanter's target via right-click.
 * A later stage adds the screen to pick a specific enchantment + index.
 *
 * <p>Because the guide stores its enchantment in the standard STORED_ENCHANTMENTS component,
 * {@link Enchanting#getTargetEnchantment(ItemStack)} reads it the same way it reads a plain book.</p>
 */
public class EnchantingGuideItem extends Item implements MenuProvider {

	public EnchantingGuideItem(Properties properties) {
		super(properties);
	}

	/** Returns the enchantment currently stored in this guide (or invalid if none). */

	/**
	 * Store the chosen book + index on a guide. The enchantment itself is resolved later from the
	 * stored book (see {@link Enchanting#getTargetEnchantment}), so it can never drift out of sync.
	 * If the book carries no enchantment, the guide is cleared back to blank.
	 */
	public static void store(ItemStack guide, ItemStack book, int index) {
		java.util.List<net.minecraft.core.Holder<net.minecraft.world.item.enchantment.Enchantment>> holders =
			Enchanting.enchantmentsOf(book);
		if (book.isEmpty() || holders.isEmpty()) {
			guide.remove(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.TARGET);
			guide.remove(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.INDEX);
			return;
		}
		int clamped = Math.max(0, Math.min(index, holders.size() - 1));
		ItemStack stored = book.copy();
		stored.setCount(1);
		guide.set(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.TARGET, stored);
		guide.set(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.INDEX, clamped);
	}

	public static EnchantmentEntry getEnchantment(ItemStack guide) {
		return Enchanting.getTargetEnchantment(guide);
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		Level level = context.getLevel();
		BlockPos pos = context.getClickedPos();
		BlockState clicked = level.getBlockState(pos);
		ItemStack guide = context.getItemInHand();

		// Shift + right-click a Blaze Burner that HAS a blaze (lit, or actively burning) with a
		// loaded guide -> convert it to a Blaze Enchanter. An empty burner is ignored.
		boolean litBurner = clicked.getBlock() == AllBlocks.LIT_BLAZE_BURNER;
		boolean burningBurner = clicked.getBlock() == AllBlocks.BLAZE_BURNER
			&& clicked.hasProperty(com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HEAT_LEVEL)
			&& clicked.getValue(com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HEAT_LEVEL)
				!= com.zurrtum.create.content.processing.burner.BlazeBurnerBlock.HeatLevel.NONE;
		if (litBurner || burningBurner) {
			if (context.getPlayer() != null && !context.getPlayer().isShiftKeyDown()) {
				return InteractionResult.PASS;
			}
			if (!getEnchantment(guide).valid()) {
				return InteractionResult.PASS; // guide must carry an enchantment first
			}
			if (!level.isClientSide()) {
				// The lit burner has no facing; face the enchanter toward the player.
				Direction facing = context.getPlayer() != null
					? context.getPlayer().getDirection().getOpposite()
					: Direction.SOUTH;
				BlockState enchanter = CeiBlocks.BLAZE_ENCHANTER.defaultBlockState()
					.setValue(plus.dragons.createenchantmentindustry.content.enchanter.BlazeEnchanterBlock.FACING, facing);
				level.setBlockAndUpdate(pos, enchanter);
				BlockEntity be = level.getBlockEntity(pos);
				if (be instanceof BlazeEnchanterBlockEntity bee) {
					ItemStack stored = guide.copy();
					stored.setCount(1);
					bee.setTargetItem(stored);
					bee.notifyUpdate();
				}
				guide.shrink(1);
			}
			return InteractionResult.SUCCESS;
		}
		return InteractionResult.PASS;
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		// Plain right-click (no shift) in the main hand opens the Enchanting Guide screen, where
		// the player drops in an enchanted book and picks the enchantment to apply.
		if (!player.isShiftKeyDown() && hand == InteractionHand.MAIN_HAND) {
			if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
				openHandledScreen(serverPlayer);
			}
			return InteractionResult.SUCCESS;
		}
		return InteractionResult.PASS;
	}

	@Override
	public MenuBase<?> createMenu(int id, Inventory inv, Player player, RegistryFriendlyByteBuf extraData) {
		ItemStack held = player.getMainHandItem();
		ItemStack.STREAM_CODEC.encode(extraData, held);
		extraData.writeBoolean(false);
		return new EnchantingGuideMenu(id, inv, held);
	}

	@Override
	public boolean isFoil(ItemStack stack) {
		return getEnchantment(stack).valid();
	}

	@Override
	public void appendHoverText(
		ItemStack stack,
		net.minecraft.world.item.Item.TooltipContext context,
		net.minecraft.world.item.component.TooltipDisplay tooltipDisplay,
		java.util.function.Consumer<Component> tooltip,
		net.minecraft.world.item.TooltipFlag flag
	) {
		super.appendHoverText(stack, context, tooltipDisplay, tooltip, flag);
		EnchantmentEntry entry = getEnchantment(stack);
		if (entry.valid()) {
			// Show the currently selected enchantment (name + level), resolved from the stored book.
			tooltip.accept(Component.translatable("create_enchantment_industry.gui.enchanting_guide.selected")
				.withStyle(net.minecraft.ChatFormatting.GRAY));
			tooltip.accept(Component.literal(" ")
				.append(Enchantment.getFullname(entry.enchantment(), entry.level())));
		} else {
			tooltip.accept(Component.translatable("create_enchantment_industry.gui.enchanting_guide.empty")
				.withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
		}
	}
}
