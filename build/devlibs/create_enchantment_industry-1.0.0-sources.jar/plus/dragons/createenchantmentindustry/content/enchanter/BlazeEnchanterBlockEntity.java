package plus.dragons.createenchantmentindustry.content.enchanter;

import com.zurrtum.create.api.behaviour.BlockEntityBehaviour;
import com.zurrtum.create.catnip.animation.LerpedFloat;
import com.zurrtum.create.catnip.math.AngleHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import com.zurrtum.create.catnip.data.Iterate;
import com.zurrtum.create.catnip.math.VecHelper;
import com.zurrtum.create.content.kinetics.belt.behaviour.DirectBeltInputBehaviour;
import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.foundation.blockEntity.SmartBlockEntity;
import com.zurrtum.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.zurrtum.create.foundation.utility.BlockHelper;
import com.zurrtum.create.infrastructure.fluids.FluidStack;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import plus.dragons.createenchantmentindustry.registry.CeiConfig;
import plus.dragons.createenchantmentindustry.registry.CeiFluids;
import com.zurrtum.create.foundation.gui.menu.MenuProvider;
import com.zurrtum.create.foundation.gui.menu.MenuBase;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.RegistryFriendlyByteBuf;


/**
 * The Blaze Enchanter's block entity.
 *
 * <p>Stage 1: mirrors the Disenchanter's proven belt-processing + tank structure. Where the
 * Disenchanter strips enchantments into fluid, the Blaze Enchanter will consume Liquid Experience
 * to ADD an enchantment (driven by an Enchanting Guide). Stage 1 wires the item transport, tank,
 * and processing skeleton; the actual enchant application and GUI come in later stages.</p>
 */
public class BlazeEnchanterBlockEntity extends SmartBlockEntity implements MenuProvider {
	public static final int ENCHANTING_TIME = 200;
	private static final int ENCHANT_PARTICLE_COUNT = 10;

	public SmartFluidTankBehaviour internalTank;
	public TransportedItemStack heldItem;
	public ItemStack targetItem = ItemStack.EMPTY;
	public int processingTicks;
	/** True when an item is parked at the centre because there isn't enough experience yet. */
	public boolean waitingForXp;
	public Map<Direction, BlazeEnchanterItemHandler> itemHandlers = new IdentityHashMap<>();
	// Animations for the rendered blaze head (mirrors the Blaze Burner).
	public LerpedFloat headAngle = LerpedFloat.angular();
	public LerpedFloat headAnimation = LerpedFloat.linear();

	public BlazeEnchanterBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		super(type, pos, state);
		for (Direction d : Iterate.horizontalDirections) {
			itemHandlers.put(d, new BlazeEnchanterItemHandler(this, d));
		}
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour<?>> behaviours) {
		behaviours.add(new DirectBeltInputBehaviour(this).allowingBeltFunnels().setInsertionHandler(this::tryInsertingFromSide));
		int capacity = CeiConfig.blazeEnchanterTankCapacityUnits();
		// Only Liquid/Hyper Experience can be inserted (we forbid generic insertion and only
		// allow it ourselves during processing checks - same approach as the Disenchanter).
		behaviours.add(this.internalTank = SmartFluidTankBehaviour.single(this, capacity).forbidExtraction());
	}

	/** True if the tank currently holds Hyper Experience (enables hyper-enchanting later). */
	public boolean hyper() {
		FluidStack fluid = internalTank.getPrimaryHandler().getFluid();
		return fluid.getFluid() == CeiFluids.HYPER_EXPERIENCE.still;
	}

	public void setTargetItem(ItemStack stack) {
		this.targetItem = stack;
	}

	/** Opens the Enchanting Guide screen to edit the guide stored in this enchanter. */
	public void openGuideScreen(ServerPlayer player) {
		MenuProvider.openHandledScreen(player, this);
	}

	@Override
	public MenuBase<?> createMenu(int id, Inventory inv, Player player, RegistryFriendlyByteBuf extraData) {
		ItemStack guide = targetItem.copy();
		ItemStack.STREAM_CODEC.encode(extraData, guide);
		extraData.writeBoolean(true);
		extraData.writeBlockPos(worldPosition);
		EnchantingGuideMenu menu = new EnchantingGuideMenu(id, inv, guide);
		menu.blockPos = worldPosition;
		return menu;
	}

	private ItemStack tryInsertingFromSide(TransportedItemStack transportedStack, Direction side, boolean simulate) {
		ItemStack inserted = transportedStack.stack;
		ItemStack returned = ItemStack.EMPTY;
		if (!getHeldItemStack().isEmpty()) {
			return inserted;
		}
		// Stage 1: accept any item onto the belt; the enchant check happens mid-belt in
		// continueProcessing once the enchant logic is added.
		if (inserted.getCount() > 1) {
			returned = inserted.copyWithCount(inserted.getCount() - 1);
			inserted = inserted.copyWithCount(1);
		}
		if (simulate) {
			return returned;
		}
		transportedStack = transportedStack.copy();
		transportedStack.stack = inserted.copy();
		transportedStack.beltPosition = side.getAxis().isVertical() ? 0.5F : 0.0F;
		transportedStack.prevSideOffset = transportedStack.sideOffset;
		transportedStack.prevBeltPosition = transportedStack.beltPosition;
		setHeldItem(transportedStack, side);
		setChanged();
		sendData();
		return returned;
	}

	public ItemStack getHeldItemStack() {
		return heldItem == null ? ItemStack.EMPTY : heldItem.stack;
	}


	@Override
	public void tick() {
		super.tick();
		if (level != null && level.isClientSide()) {
			tickAnimation();
		}
		if (heldItem == null) {
			processingTicks = 0;
			waitingForXp = false;
			return;
		}
		boolean onClient = level.isClientSide() && !isVirtual();

		// PARKED, waiting for experience: the item sits at the centre and spins in place forever
		// until enough experience is available, at which point we kick off the enchant animation.
		if (waitingForXp) {
			heldItem.prevBeltPosition = 0.5F;
			heldItem.beltPosition = 0.5F;
			if (!onClient) {
				EnchantmentEntry entry = targetItem.isEmpty()
					? EnchantmentEntry.invalid()
					: Enchanting.getValidEnchantment(heldItem.stack, targetItem, hyper());
				if (!entry.valid()) {
					// Guide changed / item no longer valid: stop waiting and let it move on out.
					waitingForXp = false;
					notifyUpdate();
					return;
				}
				int cost = Enchanting.getExperienceConsumption(entry.enchantment(), entry.level());
				if (internalTank.getPrimaryHandler().getFluid().getAmount() >= cost) {
					// Enough experience now - begin the enchant animation.
					waitingForXp = false;
					processingTicks = ENCHANTING_TIME;
					notifyUpdate();
				}
			}
			return;
		}

		if (processingTicks > 0) {
			heldItem.prevBeltPosition = 0.5F;
			boolean wasAtBeginning = processingTicks == ENCHANTING_TIME;
			if (!onClient || processingTicks < ENCHANTING_TIME) {
				processingTicks--;
			}
			if (!continueProcessing()) {
				processingTicks = 0;
				notifyUpdate();
			} else if (wasAtBeginning != (processingTicks == ENCHANTING_TIME)) {
				sendData();
			}
			return;
		}

		heldItem.prevBeltPosition = heldItem.beltPosition;
		heldItem.prevSideOffset = heldItem.sideOffset;
		heldItem.beltPosition += itemMovementPerTick();

		if (heldItem.beltPosition > 1.0F) {
			heldItem.beltPosition = 1.0F;
			if (!onClient) {
				exportItem();
			}
		} else if (heldItem.prevBeltPosition < 0.5F && heldItem.beltPosition >= 0.5F) {
			// At the mid-point: only stop here if there's a valid enchantment for this item. If
			// not (no guide, wrong item type, already has it) we DON'T stop - the item keeps moving
			// and is exported out the far side, a passthrough.
			if (onClient) {
				return;
			}
			EnchantmentEntry entry = targetItem.isEmpty()
				? EnchantmentEntry.invalid()
				: Enchanting.getValidEnchantment(heldItem.stack, targetItem, hyper());
			if (!entry.valid()) {
				return; // let it slide on to the export side untouched
			}
			heldItem.beltPosition = 0.5F;
			// Check experience up front: if we have enough, run the enchant animation now;
			// otherwise PARK and wait (spinning in place) until experience is supplied.
			int cost = Enchanting.getExperienceConsumption(entry.enchantment(), entry.level());
			if (internalTank.getPrimaryHandler().getFluid().getAmount() >= cost) {
				processingTicks = ENCHANTING_TIME;
			} else {
				waitingForXp = true;
			}
			sendData();
		}
	}

	private void exportItem() {
		Direction side = heldItem.insertedFrom;
		ItemStack tryExport = getBehaviour(DirectBeltInputBehaviour.TYPE)
			.tryExportingToBeltFunnel(heldItem.stack, side.getOpposite(), false);
		if (tryExport != null) {
			if (tryExport.getCount() != heldItem.stack.getCount()) {
				if (tryExport.isEmpty()) {
					heldItem = null;
				} else {
					heldItem.stack = tryExport;
				}
				notifyUpdate();
				return;
			}
			if (!tryExport.isEmpty()) {
				return;
			}
		}

		BlockPos nextPosition = worldPosition.relative(side);
		DirectBeltInputBehaviour next = BlockEntityBehaviour.get(level, nextPosition, DirectBeltInputBehaviour.TYPE);
		if (next == null) {
			if (!BlockHelper.hasBlockSolidSide(level.getBlockState(nextPosition), level, nextPosition, side.getOpposite())) {
				ItemStack ejected = heldItem.stack;
				Vec3 outPos = VecHelper.getCenterOf(worldPosition).add(Vec3.atLowerCornerOf(side.getUnitVec3i()).scale(0.75));
				float speed = itemMovementPerTick();
				Vec3 outMotion = Vec3.atLowerCornerOf(side.getUnitVec3i()).scale(speed).add(0.0, 0.125, 0.0);
				outPos.add(outMotion.normalize());
				ItemEntity entity = new ItemEntity(level, outPos.x, outPos.y + 0.375, outPos.z, ejected);
				entity.setDeltaMovement(outMotion);
				entity.setDefaultPickUpDelay();
				level.addFreshEntity(entity);
				heldItem = null;
				waitingForXp = false;
				notifyUpdate();
			}
		} else if (next.canInsertFromSide(side)) {
			ItemStack returned = next.handleInsertion(heldItem.copy(), side, false);
			if (returned.isEmpty()) {
				heldItem = null;
				waitingForXp = false;
				notifyUpdate();
			} else if (returned.getCount() != heldItem.stack.getCount()) {
				heldItem.stack = returned;
				notifyUpdate();
			}
		}
	}

	/**
	 * Performs the enchant mid-belt: reads the desired enchantment from {@link #targetItem} (the
	 * guide / enchanted book), validates it against the held item, drains the required Liquid
	 * Experience, and writes the enchantment onto the item.
	 */
	protected boolean continueProcessing() {
		if (level.isClientSide() && !isVirtual()) {
			return true;
		}
		if (processingTicks < 5) {
			return true;
		}
		if (heldItem == null || heldItem.stack.isEmpty()) {
			return false;
		}
		if (targetItem.isEmpty()) {
			return false; // no guide set - nothing to apply
		}

		EnchantmentEntry entry = Enchanting.getValidEnchantment(heldItem.stack, targetItem, hyper());
		if (!entry.valid()) {
			return false;
		}

		if (processingTicks > 5) {
			// Still animating; nothing to commit yet.
			return true;
		}

		// processingTicks == 5: commit. Experience was already verified before the animation
		// started (the item parks and waits if it's short), but re-check defensively in case the
		// tank was drained meanwhile - if so, fall back to waiting rather than enchanting for free.
		int cost = Enchanting.getExperienceConsumption(entry.enchantment(), entry.level());
		FluidStack stored = internalTank.getPrimaryHandler().getFluid();
		if (stored.getAmount() < cost) {
			processingTicks = 0;
			waitingForXp = true;
			notifyUpdate();
			return true;
		}

		ItemStack single = heldItem.stack.copyWithCount(1);
		Enchanting.enchantItem(single, entry);
		single.setCount(heldItem.stack.getCount());
		heldItem.stack = single;

		// Drain the cost from the tank by writing back a reduced fluid stack.
		FluidStack remaining = stored.copyWithAmount(stored.getAmount() - cost);
		internalTank.getPrimaryHandler().setFluid(remaining);
		playEnchantSound();
		spawnEnchantParticles();
		notifyUpdate();
		return true;
	}


	/** The enchanting-table chime, played periodically while an item is being enchanted. */
	private void playEnchantSound() {
		if (level == null) {
			return;
		}
		level.playSound(null, worldPosition, net.minecraft.sounds.SoundEvents.ENCHANTMENT_TABLE_USE,
			net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, level.getRandom().nextFloat() * 0.1F + 0.9F);
	}

	/** The burst of enchant glyph particles, emitted when the enchant is committed. */
	private void spawnEnchantParticles() {
		if (level instanceof net.minecraft.server.level.ServerLevel serverLevel) {
			net.minecraft.world.phys.Vec3 c = VecHelper.getCenterOf(worldPosition).add(0.0, 1.1, 0.0);
			serverLevel.sendParticles(net.minecraft.core.particles.ParticleTypes.ENCHANT,
				c.x, c.y, c.z, ENCHANT_PARTICLE_COUNT, 0.4, 0.4, 0.4, 0.2);
		}
	}

	private void tickAnimation() {
		boolean active = !internalTank.getPrimaryHandler().getFluid().isEmpty();

		// Make the blaze head look toward the player when idle, exactly like the Blaze Burner.
		float target = 0.0F;
		LocalPlayer player = Minecraft.getInstance().player;
		if (player != null && !player.isInvisible()) {
			double x = player.getX();
			double z = player.getZ();
			double dx = x - (worldPosition.getX() + 0.5);
			double dz = z - (worldPosition.getZ() + 0.5);
			target = AngleHelper.deg(-Mth.atan2(dz, dx)) - 90.0F;
		}
		target = headAngle.getValue() + AngleHelper.getShortestAngleDiff(headAngle.getValue(), target);
		headAngle.chase(target, 0.25, LerpedFloat.Chaser.exp(5.0));
		headAngle.tickChaser();

		headAnimation.chase(active ? 1.0 : 0.0, 0.25, LerpedFloat.Chaser.exp(0.25));
		headAnimation.tickChaser();

		spawnParticles(active);
	}

	/**
	 * Emits the same particles as the Blaze Burner: a wisp of smoke always (like a smouldering
	 * burner) for the cold enchanter, and smoke + flame when heated (like a kindled burner).
	 */
	private void spawnParticles(boolean active) {
		if (level == null) {
			return;
		}
		// Verbatim copy of the Blaze Burner's spawnParticles (same amount/frequency). Smoke for
		// the cold/smouldering enchanter; smoke + flame when heated.
		RandomSource r = level.getRandom();
		Vec3 c = VecHelper.getCenterOf(worldPosition);
		Vec3 v = c.add(VecHelper.offsetRandomly(Vec3.ZERO, r, 0.125F).multiply(1.0, 0.0, 1.0));
		if (r.nextInt(4) == 0) {
			boolean empty = level.getBlockState(worldPosition.above())
				.getCollisionShape(level, worldPosition.above()).isEmpty();
			if (empty || r.nextInt(8) == 0) {
				level.addParticle(ParticleTypes.SMOKE, v.x, v.y, v.z, 0.0, 0.0, 0.0);
			}
			double yMotion = empty ? 0.0625 : r.nextDouble() * 0.0125F;
			Vec3 v2 = c.add(
					VecHelper.offsetRandomly(Vec3.ZERO, r, 0.5F)
						.multiply(1.0, 0.25, 1.0)
						.normalize()
						.scale((empty ? 0.25 : 0.5) + r.nextDouble() * 0.125)
				)
				.add(0.0, 0.5, 0.0);
			if (active) {
				level.addParticle(ParticleTypes.FLAME, v2.x, v2.y, v2.z, 0.0, yMotion, 0.0);
			}
		}
	}

	private float itemMovementPerTick() {
		return 0.125F;
	}

	public SmartFluidTankBehaviour getInternalTank() {
		return internalTank;
	}

	public void setHeldItem(TransportedItemStack heldItem, Direction insertedFrom) {
		this.heldItem = heldItem;
		this.heldItem.insertedFrom = insertedFrom;
	}

	@Override
	public void destroy() {
		super.destroy();
		ItemStack heldItemStack = getHeldItemStack();
		if (!heldItemStack.isEmpty()) {
			Containers.dropItemStack(level, worldPosition.getX(), worldPosition.getY(), worldPosition.getZ(), heldItemStack);
		}
		if (!targetItem.isEmpty() && level instanceof ServerLevel) {
			Containers.dropItemStack(level, worldPosition.getX(), worldPosition.getY(), worldPosition.getZ(), targetItem);
		}
	}

	@Override
	public void write(ValueOutput view, boolean clientPacket) {
		view.putInt("ProcessingTicks", processingTicks);
		view.putBoolean("WaitingForXp", waitingForXp);
		if (heldItem != null) {
			view.store("HeldItem", TransportedItemStack.CODEC, heldItem);
		}
		if (!targetItem.isEmpty()) {
			view.store("TargetItem", ItemStack.CODEC, targetItem);
		}
		super.write(view, clientPacket);
	}

	@Override
	protected void read(ValueInput view, boolean clientPacket) {
		processingTicks = view.getIntOr("ProcessingTicks", 0);
		waitingForXp = view.getBooleanOr("WaitingForXp", false);
		heldItem = view.read("HeldItem", TransportedItemStack.CODEC).orElse(null);
		targetItem = view.read("TargetItem", ItemStack.CODEC).orElse(ItemStack.EMPTY);
		super.read(view, clientPacket);
	}
}
