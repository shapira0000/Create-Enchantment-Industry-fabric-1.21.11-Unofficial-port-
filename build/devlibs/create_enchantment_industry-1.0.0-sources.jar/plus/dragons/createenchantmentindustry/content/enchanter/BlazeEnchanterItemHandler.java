package plus.dragons.createenchantmentindustry.content.enchanter;

import com.zurrtum.create.content.kinetics.belt.transport.TransportedItemStack;
import com.zurrtum.create.infrastructure.items.ItemInventory;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;

/**
 * The item-insertion face of the Blaze Enchanter, one per horizontal side.
 * Mirrors {@code DisenchanterItemHandler}: a single-slot inventory that hands the inserted
 * item to the block entity as a {@link TransportedItemStack} to run across the internal belt.
 */
public class BlazeEnchanterItemHandler implements ItemInventory {
	private final BlazeEnchanterBlockEntity blockEntity;
	private final Direction side;

	public BlazeEnchanterItemHandler(BlazeEnchanterBlockEntity be, Direction side) {
		this.blockEntity = be;
		this.side = side.getOpposite();
	}

	@Override
	public int getContainerSize() {
		return 1;
	}

	@Override
	public int getMaxStackSize(ItemStack stack) {
		return stack.getMaxStackSize();
	}

	@Override
	public boolean canPlaceItem(int slot, ItemStack stack) {
		return blockEntity.getHeldItemStack().isEmpty();
	}

	@Override
	public ItemStack getItem(int slot) {
		return slot > 1 ? ItemStack.EMPTY : blockEntity.getHeldItemStack();
	}

	@Override
	public void setItem(int slot, ItemStack stack) {
		if (slot <= 1) {
			if (stack.isEmpty()) {
				blockEntity.heldItem = null;
			} else {
				TransportedItemStack heldItem = new TransportedItemStack(stack);
				heldItem.prevBeltPosition = 0.0F;
				blockEntity.setHeldItem(heldItem, side);
			}
		}
	}

	@Override
	public void setChanged() {
		blockEntity.notifyUpdate();
	}
}
