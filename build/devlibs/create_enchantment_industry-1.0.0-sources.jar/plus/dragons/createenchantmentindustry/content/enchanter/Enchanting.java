package plus.dragons.createenchantmentindustry.content.enchanter;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;
import plus.dragons.createenchantmentindustry.registry.CeiDataComponents;

/**
 * Enchanting logic for the Blaze Enchanter, the mirror of {@code Disenchanting}.
 *
 * <p>Faithful to the original CEI but rewritten for the 1.21.11 enchantment API (enchantments are
 * {@code Holder<Enchantment>} stored in the {@link DataComponents#ENCHANTMENTS} /
 * {@link DataComponents#STORED_ENCHANTMENTS} components as {@link ItemEnchantments}).</p>
 *
 * <p>The target enchantment is taken from a "guide" — for now a plain enchanted book works as the
 * guide (its first enchantment is used), so the feature is testable before the dedicated
 * Enchanting Guide item + GUI is added.</p>
 */
public class Enchanting {

	// ---- XP / level math (unchanged, mirrors vanilla's curve) ----

	public static int expPointFromLevel(int level) {
		if (level > 31) {
			return (int) (4.5 * level * level - 162.5 * level + 2220.0);
		} else if (level > 16) {
			return (int) (2.5 * level * level - 40.5 * level + 360.0);
		} else {
			return level * level + 6 * level;
		}
	}

	public static int expPointForNextLevel(int level) {
		if (level > 30) {
			return 9 * level - 158;
		} else if (level > 15) {
			return 5 * level - 38;
		} else {
			return 2 * level + 7;
		}
	}

	// ---- Guide reading ----

	/**
	 * Reads the desired enchantment from the guide stack. For now the "guide" is simply an
	 * enchanted book (or any item carrying stored enchantments); its first stored enchantment
	 * is used. Returns an invalid entry if the guide carries no enchantment.
	 */
	public static EnchantmentEntry getTargetEnchantment(ItemStack guide) {
		// Preferred path: a loaded Enchanting Guide stores the WHOLE book it was made from
		// (TARGET) plus the chosen INDEX. We resolve the enchantment by indexing into that
		// stored book's own enchantment list - one ItemStack, one ordering, always consistent.
		if (guide.has(CeiDataComponents.TARGET)) {
			ItemStack book = guide.get(CeiDataComponents.TARGET);
			int index = guide.getOrDefault(CeiDataComponents.INDEX, 0);
			return selectFromBook(book, index);
		}
		// Fallback: a plain enchanted book used directly as a guide -> first stored enchantment.
		return selectFromBook(guide, 0);
	}

	/**
	 * The enchantments of {@code book} that have a positive level, in the book's own iteration
	 * order. Because this is always derived from a single ItemStack, the order is stable for the
	 * caller (the same list the player saw in the GUI when the guide was made from this book).
	 */
	public static List<Holder<Enchantment>> enchantmentsOf(ItemStack book) {
		ItemEnchantments stored = book.getOrDefault(DataComponents.STORED_ENCHANTMENTS, ItemEnchantments.EMPTY);
		if (stored.isEmpty()) {
			stored = book.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
		}
		List<Holder<Enchantment>> holders = new ArrayList<>();
		for (Holder<Enchantment> holder : stored.keySet()) {
			if (stored.getLevel(holder) > 0) {
				holders.add(holder);
			}
		}
		return holders;
	}

	/** The level {@code book} stores for {@code holder} (0 if none). */
	public static int levelOf(ItemStack book, Holder<Enchantment> holder) {
		ItemEnchantments stored = book.getOrDefault(DataComponents.STORED_ENCHANTMENTS, ItemEnchantments.EMPTY);
		if (stored.isEmpty()) {
			stored = book.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
		}
		return stored.getLevel(holder);
	}

	/** The {@code index}-th enchantment of {@code book} (clamped), as an entry; invalid if none. */
	public static EnchantmentEntry selectFromBook(ItemStack book, int index) {
		if (book.isEmpty()) {
			return EnchantmentEntry.invalid();
		}
		List<Holder<Enchantment>> holders = enchantmentsOf(book);
		if (holders.isEmpty()) {
			return EnchantmentEntry.invalid();
		}
		int pick = Math.max(0, Math.min(index, holders.size() - 1));
		Holder<Enchantment> chosen = holders.get(pick);
		return EnchantmentEntry.of(chosen, levelOf(book, chosen));
	}

	// ---- Validation ----

	/**
	 * Returns the enchantment that can validly be applied from {@code guide} onto {@code target},
	 * or an invalid entry if none. Checks: the guide carries an enchantment, the target supports
	 * it (or is a book), the target doesn't already have it at >= the same level, and the
	 * enchantment is compatible with the target's existing enchantments.
	 */
	public static EnchantmentEntry getValidEnchantment(ItemStack target, ItemStack guide, boolean hyper) {
		EnchantmentEntry entry = getTargetEnchantment(guide);
		if (!entry.valid()) {
			return EnchantmentEntry.invalid();
		}
		Holder<Enchantment> enchantment = entry.enchantment();

		boolean isBook = target.is(Items.BOOK) || target.is(Items.ENCHANTED_BOOK);
		// The enchantment must be applicable to the ITEM TYPE (books accept anything). This is the
		// only "fits the item" rule we keep: Protection can go on armor, Sharpness cannot.
		if (!isBook && !enchantment.value().isSupportedItem(target)) {
			return EnchantmentEntry.invalid();
		}

		ItemEnchantments current = target.has(DataComponents.STORED_ENCHANTMENTS)
			? target.getOrDefault(DataComponents.STORED_ENCHANTMENTS, ItemEnchantments.EMPTY)
			: target.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);

		// Already has this exact enchantment at >= the target level -> nothing to do.
		int existing = current.getLevel(enchantment);
		if (existing >= entry.level()) {
			return EnchantmentEntry.invalid();
		}

		// NOTE: we deliberately do NOT enforce vanilla's mutual-exclusivity between enchantments.
		// The Blaze Enchanter is allowed to stack normally-incompatible enchantments (e.g. adding
		// Fire Protection to armor that already has Protection), as long as the item type supports
		// the enchantment. Only the item-type support and the upgrade-only checks above apply.
		return entry;
	}

	// ---- Application ----

	/** Applies the entry's enchantment to the item, writing back to the correct component. */
	public static void enchantItem(ItemStack target, EnchantmentEntry entry) {
		boolean isStored = target.is(Items.ENCHANTED_BOOK) || target.has(DataComponents.STORED_ENCHANTMENTS);
		ItemEnchantments current = isStored
			? target.getOrDefault(DataComponents.STORED_ENCHANTMENTS, ItemEnchantments.EMPTY)
			: target.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);

		ItemEnchantments.Mutable builder = new ItemEnchantments.Mutable(current);
		builder.set(entry.enchantment(), entry.level());
		ItemEnchantments result = builder.toImmutable();

		if (isStored) {
			target.set(DataComponents.STORED_ENCHANTMENTS, result);
		} else {
			target.set(DataComponents.ENCHANTMENTS, result);
		}
	}

	// ---- Cost ----

	/**
	 * Experience consumption (in fluid units) to apply the given enchantment at the given level.
	 * Mirrors the original: based on the enchantment's minimum cost at that level, scaled by the
	 * unit-per-mB ratio. A minimum of 1 mB is always charged.
	 */
	/**
	 * The Liquid-Experience cost (in units) to apply {@code enchantment} at {@code level}, faithful
	 * to the original CEI: {@code expPointForNextLevel(minCost + rarityLevel * level)} experience
	 * points, converted to fluid units. Because it uses each enchantment's own minimum cost and its
	 * rarity, every enchantment costs a different amount (rarer / higher-level = more).
	 */
	public static int getExperienceConsumption(Holder<Enchantment> enchantment, int level) {
		int minCost = enchantment.value().getMinCost(level);
		int points = expPointForNextLevel(minCost + rarityLevel(enchantment) * level);
		return Math.max(1, points) * EnchantmentIndustry.UNIT_PER_MB;
	}

	/**
	 * A 1..4 "rarity weight" for an enchantment, replacing the pre-1.21 Rarity enum (removed in
	 * 1.21+). Derived from the enchantment's selection weight: common enchantments (high weight)
	 * cost more per level, very rare ones (low weight) cost less - matching the original mapping
	 * COMMON=4, UNCOMMON=3, RARE=2, VERY_RARE=1.
	 */
	public static int rarityLevel(Holder<Enchantment> enchantment) {
		int weight = enchantment.value().getWeight();
		if (weight >= 10) return 4; // COMMON  (e.g. Protection, Sharpness, Efficiency)
		if (weight >= 5)  return 3; // UNCOMMON
		if (weight >= 2)  return 2; // RARE
		return 1;                   // VERY_RARE (e.g. Silk Touch, Thorns, Mending-tier)
	}
}
