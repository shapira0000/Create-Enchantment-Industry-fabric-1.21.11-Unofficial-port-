package plus.dragons.createenchantmentindustry.content.enchanter;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.item.ItemStack;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;

/**
 * Client -> server, sent once when the Enchanting Guide screen closes. Carries the chosen
 * enchantment {@code index}, the book that was in the ghost slot, and (optionally) the position
 * of a Blaze Enchanter if the screen was opened from a placed block (else null = held guide).
 *
 * <p>This mirrors the original CEI design: the choice is committed on close in a single packet
 * that includes the book itself, so the server doesn't depend on ghost-inventory syncing.</p>
 */
public record EnchantingGuideEditPacket(int index, ItemStack book, BlockPos blockPos) implements CustomPacketPayload {

	public static final Type<EnchantingGuideEditPacket> TYPE =
		new Type<>(EnchantmentIndustry.genRL("enchanting_guide_edit"));

	public static final StreamCodec<RegistryFriendlyByteBuf, EnchantingGuideEditPacket> STREAM_CODEC =
		StreamCodec.composite(
			ByteBufCodecs.VAR_INT, EnchantingGuideEditPacket::index,
			ItemStack.OPTIONAL_STREAM_CODEC, EnchantingGuideEditPacket::book,
			ByteBufCodecs.optional(BlockPos.STREAM_CODEC).map(
				opt -> opt.orElse(null),
				pos -> java.util.Optional.ofNullable(pos)
			), EnchantingGuideEditPacket::blockPos,
			EnchantingGuideEditPacket::new
		);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
