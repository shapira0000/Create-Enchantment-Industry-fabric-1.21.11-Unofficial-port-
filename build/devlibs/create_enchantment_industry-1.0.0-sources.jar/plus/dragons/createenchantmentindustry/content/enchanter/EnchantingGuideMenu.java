package plus.dragons.createenchantmentindustry.content.enchanter;

import com.google.common.collect.ImmutableList;
import com.zurrtum.create.foundation.gui.menu.GhostItemMenu;
import com.zurrtum.create.foundation.gui.menu.MenuType;
import com.zurrtum.create.infrastructure.items.ItemStackHandler;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import plus.dragons.createenchantmentindustry.registry.CeiMenuTypes;

/**
 * Container menu for the Enchanting Guide. Holds a single ghost slot for an enchanted book; when a
 * book is present, the book's enchantments are read into {@link #enchantments} and the player picks
 * one by {@code index}. The chosen enchantment is written back onto the guide on close/save.
 *
 * <p>Mirrors the original CEI {@code EnchantingGuideMenu}, adapted to Create Fly's
 * {@link GhostItemMenu} and the 1.21.11 enchantment-component API.</p>
 */
public class EnchantingGuideMenu extends GhostItemMenu<ItemStack> {

	public static final Component NO_ENCHANTMENT =
		Component.translatable("create_enchantment_industry.gui.enchanting_guide.no_enchantment");

	public ImmutableList<Component> previousEnchantments;
	public ImmutableList<Component> enchantments;
	public int index;
	// When opened from a placed Blaze Enchanter, the block's position (else null = held guide).
	public net.minecraft.core.BlockPos blockPos;

	public EnchantingGuideMenu(int id, Inventory inv, ItemStack guide) {
		super(CeiMenuTypes.ENCHANTING_GUIDE, id, inv, guide);
	}

	@Override
	protected ItemStackHandler createGhostInventory() {
		return new ItemStackHandler(1);
	}

	@Override
	protected boolean allowRepeats() {
		return false;
	}

	@Override
	protected void initAndReadInventory(ItemStack contentHolder) {
		super.initAndReadInventory(contentHolder);
		// If the guide was already loaded, it stores the WHOLE book it was made from (TARGET) plus
		// the chosen INDEX. Put that exact book back in the ghost slot and restore the selection,
		// so reopening shows precisely what was picked - same ItemStack, same ordering.
		if (contentHolder.has(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.TARGET)) {
			ItemStack book = contentHolder.get(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.TARGET).copy();
			ghostInventory.setItem(0, book);
			index = contentHolder.getOrDefault(plus.dragons.createenchantmentindustry.registry.CeiDataComponents.INDEX, 0);
		}
		updateEnchantments(ghostInventory.getItem(0));
	}

	/** The enchanted book currently in the ghost slot (client + server). */
	public ItemStack getGhostBook() {
		return ghostInventory.getItem(0);
	}

	public void setIndex(int index) {
		this.index = index;
	}

	/** Reads every enchantment on the held book into the display list (names with level). */


	public void updateEnchantments(ItemStack book) {
		previousEnchantments = enchantments;
		ImmutableList.Builder<Component> builder = ImmutableList.builder();
		for (Holder<Enchantment> holder : Enchanting.enchantmentsOf(book)) {
			builder.add(Enchantment.getFullname(holder, Enchanting.levelOf(book, holder)));
		}
		ImmutableList<Component> list = builder.build();
		enchantments = list.isEmpty() ? ImmutableList.of(NO_ENCHANTMENT) : list;
	}

	@Override
	protected void addSlots() {
		addPlayerSlots(8, 72);
		addSlot(new EnchantedBookSlot(ghostInventory, 0, 16, 22));
	}

	@Override
	protected void saveData(ItemStack guide) {
		// Intentionally empty: the chosen enchantment is committed by EnchantingGuideEditPacket,
		// which the screen sends once on close (carrying the index AND the ghost book). Writing
		// anything here would race with that packet using a stale index, so we do nothing.
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}

	@Override
	public void clicked(int slotId, int dragType, ClickType clickType, Player player) {
		super.clicked(slotId, dragType, clickType, player);
		// Re-read enchantments after ANY slot interaction (the ghost book may have changed).
		updateEnchantments(ghostInventory.getItem(0));
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		ItemStack result = super.quickMoveStack(player, index);
		// Shift-click goes through here (not clicked), so refresh the list too.
		updateEnchantments(ghostInventory.getItem(0));
		return result;
	}

	/** A ghost slot that only accepts enchanted books. */
	public static class EnchantedBookSlot extends Slot {
		public EnchantedBookSlot(net.minecraft.world.Container container, int index, int x, int y) {
			super(container, index, x, y);
		}

		@Override
		public boolean mayPlace(ItemStack stack) {
			return stack.is(net.minecraft.world.item.Items.ENCHANTED_BOOK);
		}

		@Override
		public int getMaxStackSize() {
			return 1;
		}
	}
}
