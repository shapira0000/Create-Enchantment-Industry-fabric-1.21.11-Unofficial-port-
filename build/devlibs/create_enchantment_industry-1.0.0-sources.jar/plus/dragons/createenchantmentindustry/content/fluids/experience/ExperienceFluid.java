package plus.dragons.createenchantmentindustry.content.fluids.experience;

import com.zurrtum.create.infrastructure.fluids.FlowableFluid;
import com.zurrtum.create.infrastructure.fluids.FluidEntry;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import plus.dragons.createenchantmentindustry.EnchantmentIndustry;

/**
 * Liquid Experience.
 *
 * <p>In the original CEI this extended Create's {@code VirtualFluid}. Create Fly has no
 * VirtualFluid concept, so this extends {@link FlowableFluid.Still} and carries the
 * XP-conversion logic CEI relies on.</p>
 */
public class ExperienceFluid extends FlowableFluid.Still {
	protected final int xpRatio;

	public ExperienceFluid(FluidEntry entry, int xpRatio) {
		super(entry);
		this.xpRatio = xpRatio;
	}

	public ExperienceFluid(FluidEntry entry) {
		this(entry, 1);
	}

	public int getXpRatio() {
		return xpRatio;
	}

	/** Create an XP orb of the given size at a position. Overridden by hyper experience. */
	public ExperienceOrb convertToOrb(Level level, double x, double y, double z, int amount) {
		return new ExperienceOrb(level, x, y, z, amount);
	}

	/** Spill the given amount of raw fluid as XP orbs into the world (open pipe behaviour). */
	public void drop(ServerLevel level, Vec3 pos, int realFluidAmount) {
		int amount = realFluidAmount / EnchantmentIndustry.UNIT_PER_MB;
		while (amount > 0) {
			int orbSize = ExperienceOrb.getExperienceValue(amount);
			amount -= orbSize;
			if (!ExperienceOrb.tryMergeToExisting(level, pos, orbSize)) {
				level.addFreshEntity(convertToOrb(level, pos.x, pos.y, pos.z, orbSize));
			}
		}
	}

	/** Award the fluid to a player (repairing mending gear first), or drop it if no player. */
	public void awardOrDrop(@Nullable Player player, ServerLevel level, Vec3 pos, Vec3 speed, int realAmount) {
		int amount = realAmount / EnchantmentIndustry.UNIT_PER_MB;
		ExperienceOrb orb = convertToOrb(level, pos.x, pos.y, pos.z, amount);
		if (player == null) {
			if (!ExperienceOrb.tryMergeToExisting(level, pos, amount)) {
				orb.setDeltaMovement(speed);
				level.addFreshEntity(orb);
			}
		} else if (player instanceof ServerPlayer serverPlayer) {
			// repairPlayerItems is an INSTANCE method on the orb (matches original CEI behaviour).
			int left = orb.repairPlayerItems(serverPlayer, amount);
			if (left > 0) {
				player.giveExperiencePoints(left);
				applyAdditionalEffects(player, left);
			}
		}
	}

	/** Hook for hyper experience to add potion effects. No-op for normal experience. */
	public void applyAdditionalEffects(LivingEntity entity, int expAmount) {
	}
}
