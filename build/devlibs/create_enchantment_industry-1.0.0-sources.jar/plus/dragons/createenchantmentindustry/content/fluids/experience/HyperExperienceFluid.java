package plus.dragons.createenchantmentindustry.content.fluids.experience;

import com.zurrtum.create.infrastructure.fluids.FluidEntry;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * Liquid Hyper Experience.
 *
 * <p>Higher density than normal experience (xpRatio 10) and grants Night Vision + Speed
 * when awarded, matching the original CEI behaviour. The original spawned a custom
 * {@code HyperExperienceOrb} entity; until that entity is ported, this scales a normal
 * orb by the ratio, which is functionally equivalent for XP value.</p>
 */
public class HyperExperienceFluid extends ExperienceFluid {
	public HyperExperienceFluid(FluidEntry entry) {
		super(entry, 10);
	}

	@Override
	public ExperienceOrb convertToOrb(Level level, double x, double y, double z, int amount) {
		return new ExperienceOrb(level, x, y, z, amount * xpRatio);
	}

	@Override
	public void applyAdditionalEffects(LivingEntity entity, int expAmount) {
		int duration = 200 * Mth.ceil((double) expAmount);
		entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, duration));
		entity.addEffect(new MobEffectInstance(MobEffects.SPEED, duration));
	}
}
